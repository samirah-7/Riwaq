// Run from apps/riwaq: dart run tool/generate_hospital_model.dart [--check]
// Uses the SAME data as Flutter's 2D renderer; no parallel hand-built floor data.
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:riwaq/data/hospital_floor_plan_data.dart';
import 'package:riwaq/models/hospital_floor_plan.dart';

void main(List<String> args) {
  final positions = <double>[
    -.5,
    -.5,
    -.5,
    .5,
    -.5,
    -.5,
    .5,
    .5,
    -.5,
    -.5,
    .5,
    -.5,
    -.5,
    -.5,
    .5,
    .5,
    -.5,
    .5,
    .5,
    .5,
    .5,
    -.5,
    .5,
    .5,
  ];
  final indices = <int>[
    0,
    2,
    1,
    0,
    3,
    2,
    4,
    5,
    6,
    4,
    6,
    7,
    0,
    1,
    5,
    0,
    5,
    4,
    3,
    7,
    6,
    3,
    6,
    2,
    0,
    4,
    7,
    0,
    7,
    3,
    1,
    2,
    6,
    1,
    6,
    5,
  ];
  final bin = ByteData(positions.length * 4 + indices.length * 2);
  for (var i = 0; i < positions.length; i++) {
    bin.setFloat32(i * 4, positions[i], Endian.little);
  }
  for (var i = 0; i < indices.length; i++) {
    bin.setUint16(positions.length * 4 + i * 2, indices[i], Endian.little);
  }
  const palette = [
    [0.95, 0.97, 0.96, 1.0], // slab
    [0.92, 0.96, 0.95, 1.0], // wall
    [0.73, 0.90, 0.87, 1.0], // clinical
    [0.88, 0.92, 0.84, 1.0], // public
    [0.89, 0.86, 0.81, 1.0], // staff
    [0.82, 0.87, 0.94, 1.0], // services
    [0.47, 0.70, 0.54, 1.0], // garden
    [0.19, 0.59, 0.49, 1.0], // accent/furniture
  ];
  final nodes = <Map<String, dynamic>>[];
  void box(String name, double x, double y, double z, double w, double h,
      double d, int material, HospitalFloorPlan floor,
      {FloorPlanPlace? place, String kind = 'wall'}) {
    if (w <= 0 || h <= 0 || d <= 0) return;
    nodes.add({
      'name': name,
      'mesh': material,
      'translation': [x, y, z],
      'scale': [w, h, d],
      'extras': {
        'floorId': floor.id,
        'level': floor.level,
        'placeId': place?.id,
        'kind': kind
      },
    });
  }

  for (final floor in hospitalFloorPlans) {
    final base = floor.level * .72;
    const b = hospitalBuildingBounds;
    box('${floor.id}_SLAB', (b.centerX - .5) * 10, base, (b.centerY - .5) * 10,
        b.width * 10, .07, b.height * 10, 0, floor,
        kind: 'slab');
    for (final p in floor.selectablePlaces) {
      final r = p.bounds;
      if (r == null) continue;
      final material = switch (p.zone) {
        PlanZone.clinical => 2,
        PlanZone.public => 3,
        PlanZone.staff => 4,
        PlanZone.service => 5,
        PlanZone.outdoor => 6,
      };
      box(
          '${p.id}_FLOOR',
          (r.centerX - .5) * 10,
          base + .06,
          (r.centerY - .5) * 10,
          r.width * 10,
          .035,
          r.height * 10,
          material,
          floor,
          place: p,
          kind: 'room');
      if (p.zone == PlanZone.outdoor) continue;
      const thick = .035, height = .38;
      void wall(String suffix, double x, double z, double w, double d) => box(
          '${p.id}_$suffix',
          x,
          base + .09 + height / 2,
          z,
          w,
          height,
          d,
          1,
          floor,
          place: p);
      wall('N', (r.centerX - .5) * 10, (r.top - .5) * 10, r.width * 10, thick);
      wall(
          'W', (r.left - .5) * 10, (r.centerY - .5) * 10, thick, r.height * 10);
      wall('E', (r.right - .5) * 10, (r.centerY - .5) * 10, thick,
          r.height * 10);
      const gap = .052;
      final leftEnd = p.x - gap / 2, rightStart = p.x + gap / 2;
      wall('S1', ((r.left + leftEnd) / 2 - .5) * 10, (r.bottom - .5) * 10,
          (leftEnd - r.left) * 10, thick);
      wall('S2', ((r.right + rightStart) / 2 - .5) * 10, (r.bottom - .5) * 10,
          (r.right - rightStart) * 10, thick);
      // Architectural furniture belongs to its room, not invented locations.
      if (p.category == FloorPlaceCategory.department) {
        box('${p.id}_DESK', (r.left + .045 - .5) * 10, base + .14,
            (r.top + .035 - .5) * 10, .35, .12, .19, 7, floor,
            place: p, kind: 'furniture');
      }
      if (p.category == FloorPlaceCategory.waitingArea) {
        for (var i = 0; i < 3; i++) {
          box('${p.id}_SEAT_$i', (r.left + .035 + i * .05 - .5) * 10,
              base + .12, (r.top + .04 - .5) * 10, .28, .1, .25, 7, floor,
              place: p, kind: 'furniture');
        }
      }
    }
    // Exterior shell retains the entrance opening on every level's cutaway.
    for (final edge in [
      (x: b.centerX, z: b.top, w: b.width, d: .004),
      (x: b.left, z: b.centerY, w: .004, d: b.height),
      (x: b.right, z: b.centerY, w: .004, d: b.height),
      (x: .25, z: b.bottom, w: .43, d: .004),
      (x: .75, z: b.bottom, w: .43, d: .004),
    ]) {
      box('${floor.id}_SHELL_${nodes.length}', (edge.x - .5) * 10, base + .20,
          (edge.z - .5) * 10, edge.w * 10, .35, edge.d * 10, 1, floor);
    }
  }
  final doc = {
    'asset': {
      'version': '2.0',
      'generator': 'Riwaq shared-data procedural cuboid generator'
    },
    'scene': 0,
    'scenes': [
      {'nodes': List.generate(nodes.length, (i) => i)}
    ],
    'nodes': nodes,
    'extras': {
      'conceptual': true,
      'coordinateUnits': 'relative design units, not metres',
      'source': 'lib/data/hospital_floor_plan_data.dart',
      'floorCount': hospitalFloorPlans.length
    },
    'materials': [
      for (final color in palette)
        {
          'pbrMetallicRoughness': {
            'baseColorFactor': color,
            'metallicFactor': 0,
            'roughnessFactor': .85
          },
          'doubleSided': true,
        }
    ],
    'meshes': [
      for (var i = 0; i < palette.length; i++)
        {
          'primitives': [
            {
              'attributes': {'POSITION': 0},
              'indices': 1,
              'material': i,
            }
          ]
        }
    ],
    'buffers': [
      {'byteLength': bin.lengthInBytes}
    ],
    'bufferViews': [
      {
        'buffer': 0,
        'byteOffset': 0,
        'byteLength': positions.length * 4,
        'target': 34962
      },
      {
        'buffer': 0,
        'byteOffset': positions.length * 4,
        'byteLength': indices.length * 2,
        'target': 34963
      },
    ],
    'accessors': [
      {
        'bufferView': 0,
        'componentType': 5126,
        'count': 8,
        'type': 'VEC3',
        'min': [-.5, -.5, -.5],
        'max': [.5, .5, .5]
      },
      {
        'bufferView': 1,
        'componentType': 5123,
        'count': indices.length,
        'type': 'SCALAR'
      },
    ],
  };
  List<int> jsonBytes = utf8.encode(jsonEncode(doc));
  while (jsonBytes.length % 4 != 0) {
    jsonBytes = [...jsonBytes, 32];
  }
  final total = 12 + 8 + jsonBytes.length + 8 + bin.lengthInBytes;
  final output = ByteData(total)
    ..setUint32(0, 0x46546c67, Endian.little)
    ..setUint32(4, 2, Endian.little)
    ..setUint32(8, total, Endian.little)
    ..setUint32(12, jsonBytes.length, Endian.little)
    ..setUint32(16, 0x4e4f534a, Endian.little);
  final bytes = output.buffer.asUint8List();
  bytes.setRange(20, 20 + jsonBytes.length, jsonBytes);
  final offset = 20 + jsonBytes.length;
  output
    ..setUint32(offset, bin.lengthInBytes, Endian.little)
    ..setUint32(offset + 4, 0x004e4942, Endian.little);
  bytes.setRange(offset + 8, total, bin.buffer.asUint8List());
  final file = File('assets/hospital/riwaq_hospital.glb');
  if (args.contains('--check')) {
    if (!file.existsSync() ||
        base64Encode(file.readAsBytesSync()) != base64Encode(bytes)) {
      stderr.writeln(
          'GLB is stale. Run dart run tool/generate_hospital_model.dart');
      exitCode = 1;
      return;
    }
    stdout.writeln('Shared architectural data and GLB match.');
  } else {
    file.parent.createSync(recursive: true);
    file.writeAsBytesSync(bytes);
    stdout.writeln(
        'Generated ${file.path}: ${nodes.length} architectural parts, ${bytes.length} bytes.');
  }
}
