# 29LT Bukra fonts

The app now bundles the provided **29LT Bukra Light, Regular, and Bold** TTF
files and registers the family in `pubspec.yaml`. Flutter uses the real Bukra
faces for those weights throughout the theme.

The attachment did not include a Medium face. `FontWeight.w500` therefore uses
Flutter's normal font matching with the registered Regular/Bold family; it is
not a separate medium file. Add the licensed `29LTBukra-Medium.ttf` face when
available, then register it at weight `500` in `pubspec.yaml`.

The supplied italic and OpenType variants are preserved in the original
attachments but are not needed by the current non-italic interface.
