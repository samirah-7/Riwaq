Place approved Figma-exported images and hospital map assets here.
