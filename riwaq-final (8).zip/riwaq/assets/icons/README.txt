Place approved icon assets here. Current prototype uses Material icons.
