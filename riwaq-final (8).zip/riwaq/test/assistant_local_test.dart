import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/data/repositories/doctor_repository.dart';
import 'package:riwaq/models/assistant_response.dart';
import 'package:riwaq/services/ai/ai_provider.dart';
import 'package:riwaq/services/ai/ai_service.dart';
import 'package:riwaq/services/ai/health_safety_rules.dart';
import 'package:riwaq/services/ai/intent_classifier.dart';
import 'package:riwaq/services/hospital_route_service.dart';

void main() {
  group('local assistant understanding', () {
    test('recognizes English and Arabic ways to ask for an eye clinic', () {
      final classifier = IntentClassifier();
      const phrases = [
        'Where is the ophthalmology clinic?',
        'I need to go to the eye clinic.',
        'How can I reach the eye department?',
        'وين عيادة العيون؟',
        'أبغى أروح لعيادة العيون',
        'كيف أوصل لقسم العيون؟',
      ];

      for (final phrase in phrases) {
        final response = classifier.classify(
          phrase,
          currentLocationId: 'RECEPTION',
        );
        expect(response.destinationId, 'EYE_CLINIC', reason: phrase);
        expect(response.actions, contains('open_map'), reason: phrase);
      }
    });

    test('separates a stated origin from the requested destination', () {
      final classifier = IntentClassifier();
      final english = classifier.classify(
        "I'm at reception and I want to go to the eye clinic",
        currentLocationId: 'MAIN_ENTRANCE',
      );
      expect(english.originId, 'RECEPTION');
      expect(english.originWasSpecified, isTrue);
      expect(english.destinationId, 'EYE_CLINIC');

      final arabic = classifier.classify(
        'أنا في الاستقبال وأريد الذهاب إلى عيادة العيون',
        currentLocationId: 'MAIN_ENTRANCE',
      );
      expect(arabic.originId, 'RECEPTION');
      expect(arabic.originWasSpecified, isTrue);
      expect(arabic.destinationId, 'EYE_CLINIC');
    });

    test('asks for unclear origins and destinations instead of guessing', () {
      final classifier = IntentClassifier();
      final unclearOrigin = classifier.classify(
        'I am at the cafeteria and want to go to the eye clinic',
        currentLocationId: 'MAIN_ENTRANCE',
      );
      expect(unclearOrigin.clarificationNeeded,
          AssistantClarificationField.origin);

      final unclearDestination = classifier.classify(
        'I am at reception and want to go to the ear clinic',
        currentLocationId: 'MAIN_ENTRANCE',
      );
      expect(unclearDestination.clarificationNeeded,
          AssistantClarificationField.destination);
      expect(unclearDestination.destinationId, isNull);
    });

    test('uses the current chat context for a follow-up route request', () async {
      final assistant = AiService();
      final first = await assistant.respond('Where is the dental clinic?');
      final followUp = await assistant.respond(
        'How do I get there from reception?',
      );

      expect(first.destinationId, 'DENTAL_CLINIC');
      expect(followUp.originId, 'RECEPTION');
      expect(followUp.originWasSpecified, isTrue);
      expect(followUp.destinationId, 'DENTAL_CLINIC');
      expect(followUp.actions, contains('open_map'));

      final route = HospitalRouteService().findRouteResult(
        startLocationId: followUp.originId!,
        destinationLocationId: followUp.destinationId!,
      );
      expect(route.route, isNotNull);
    });

    test('returns only registered doctor, specialty, department and location IDs',
        () {
      expect(
        const DoctorRepository()
            .findByText('Dr. Noura Al-Otaibi')
            ?.id,
        'DOC_EYE_01',
      );
      final response =
          IntentClassifier().classify('Where is Dr. Noura Al-Otaibi?');
      expect(response.intent, AssistantIntent.doctorSearch);
      expect(response.doctorIds, ['DOC_EYE_01']);
      expect(response.specialtyId, 'OPHTHALMOLOGY');
      expect(response.departmentId, 'EYE');
      expect(response.destinationId, 'EYE_CLINIC');
      expect(response.actions, contains('open_map'));
    });
  });

  group('local health safety', () {
    test('keeps safety rules separate and prioritizes urgent indicators', () {
      final rules = HealthSafetyRules();
      final classifier = IntentClassifier(safetyRules: rules);
      expect(rules.emergencyResponse('What causes chest pain?'), isNull);
      expect(classifier.classify('What causes chest pain?').intent,
          AssistantIntent.healthInformation);

      for (final phrase in [
        'I have severe chest pain',
        "I can't breathe",
        'Someone is unconscious',
      ]) {
        final response = classifier.classify(phrase);
        expect(response.intent, AssistantIntent.emergency, reason: phrase);
        expect(response.actions, ['call_emergency'], reason: phrase);
        expect(response.destinationId, isNull, reason: phrase);
      }
    });

    test('ordinary emergency-department searches are not emergency reports', () {
      final response =
          IntentClassifier().classify('Where is the emergency department?');
      expect(response.intent, AssistantIntent.facilitySearch);
      expect(response.destinationId, 'EMERGENCY');
    });
  });

  test('AiService passes a consistent request to its replaceable provider',
      () async {
    final provider = _RecordingProvider();
    final assistant = AiService(provider: provider, fallback: provider);
    await assistant.respond(
      'Where is radiology?',
      history: const [AiChatTurn(role: 'user', content: 'Where is reception?')],
      currentLocationId: 'RECEPTION',
      destinationId: 'RADIOLOGY',
    );

    expect(provider.request?.message, 'Where is radiology?');
    expect(provider.request?.currentLocationId, 'RECEPTION');
    expect(provider.request?.destinationId, 'RADIOLOGY');
    expect(provider.request?.history.single.content, 'Where is reception?');
  });
}

class _RecordingProvider implements AiProvider {
  AssistantRequest? request;

  @override
  Future<AssistantResponse> respond(AssistantRequest request) async {
    this.request = request;
    return const AssistantResponse(
      intent: AssistantIntent.facilitySearch,
      message: 'Sample response',
      confidence: 1,
    );
  }
}
