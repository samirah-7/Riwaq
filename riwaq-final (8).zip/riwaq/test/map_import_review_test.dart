import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:file_picker/src/platform/file_picker_platform_interface.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/data/hospital_floor_plan_data.dart';
import 'package:riwaq/screens/floor_plan_screen.dart';
import 'package:riwaq/services/hospital_floor_plan_editor.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  late FilePickerPlatform originalFilePicker;
  late _FakeFilePickerPlatform filePicker;

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    hospitalFloorPlans = defaultHospitalFloorPlans;
    originalFilePicker = FilePickerPlatform.instance;
    filePicker = _FakeFilePickerPlatform();
    FilePickerPlatform.instance = filePicker;
  });

  tearDown(() {
    FilePickerPlatform.instance = originalFilePicker;
    hospitalFloorPlans = defaultHospitalFloorPlans;
  });

  testWidgets('map file changes are previewed before confirm or cancel',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;

    final currentJson = HospitalFloorPlanEditor.exportJson();
    final document = jsonDecode(currentJson) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    final firstPlace = (ground['places'] as List).first as Map<String, dynamic>;
    firstPlace['nameAr'] = 'اسم جديد للمعاينة';
    final bytes = Uint8List.fromList(utf8.encode(jsonEncode(document)));
    filePicker.selectedFile = PlatformFile(
      name: 'map.json',
      size: bytes.length,
      bytes: bytes,
    );

    await _openEditor(tester);
    final editorJson = tester
        .widget<TextField>(find.byKey(const ValueKey('floor-plan-json-editor')))
        .controller!
        .text;

    await tester.tap(find.byKey(const ValueKey('import-floor-plan-json-file')));
    await tester.pumpAndSettle();
    expect(find.text('مراجعة تغييرات المخطط'), findsOneWidget);
    expect(find.textContaining('اسم جديد للمعاينة'), findsOneWidget);
    expect(HospitalFloorPlanEditor.exportJson(), currentJson);
    expect(
      (await SharedPreferences.getInstance())
          .getString('riwaq.simulatedFloorPlans.v1'),
      isNull,
    );

    await tester.tap(find.byKey(const ValueKey('cancel-floor-plan-import')));
    await tester.pumpAndSettle();
    expect(
        find.byKey(const ValueKey('floor-plan-json-editor')), findsOneWidget);
    expect(
      tester
          .widget<TextField>(
              find.byKey(const ValueKey('floor-plan-json-editor')))
          .controller!
          .text,
      editorJson,
    );
    expect(HospitalFloorPlanEditor.exportJson(), currentJson);
    expect(
      (await SharedPreferences.getInstance())
          .getString('riwaq.simulatedFloorPlans.v1'),
      isNull,
    );

    await tester.tap(find.byKey(const ValueKey('import-floor-plan-json-file')));
    await tester.pumpAndSettle();
    expect(find.text('مراجعة تغييرات المخطط'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('confirm-floor-plan-import')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('floor-plan-json-editor')), findsNothing);
    expect(
      hospitalFloorPlans
          .firstWhere((floor) => floor.id == 'GROUND')
          .places
          .first
          .nameAr,
      'اسم جديد للمعاينة',
    );
    expect(
      (await SharedPreferences.getInstance())
          .getString('riwaq.simulatedFloorPlans.v1'),
      HospitalFloorPlanEditor.exportJson(),
    );
    expect(filePicker.lastPickRequestedWithData, isTrue);
    expect(filePicker.lastPickAllowedExtensions, ['json']);
    expect(tester.takeException(), isNull);
  });

  testWidgets('invalid browser-selected JSON leaves the active map unchanged',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;

    final activeMapBeforeImport = HospitalFloorPlanEditor.exportJson();
    filePicker.selectedFile = PlatformFile(
      name: 'broken.json',
      size: 15,
      bytes: Uint8List.fromList(utf8.encode('{not valid json')),
    );

    await _openEditor(tester);
    final editor = find.byKey(const ValueKey('floor-plan-json-editor'));
    final editorText = tester.widget<TextField>(editor).controller!.text;

    await tester.tap(find.byKey(const ValueKey('import-floor-plan-json-file')));
    await tester.pumpAndSettle();

    expect(find.textContaining('لم يُستورد الملف'), findsOneWidget);
    expect(editor, findsOneWidget);
    expect(tester.widget<TextField>(editor).controller!.text, editorText);
    expect(HospitalFloorPlanEditor.exportJson(), activeMapBeforeImport);
    expect(
      (await SharedPreferences.getInstance())
          .getString('riwaq.simulatedFloorPlans.v1'),
      isNull,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('browser download receives the exact JSON shown in the editor',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;

    await _openEditor(tester);
    final editor = find.byKey(const ValueKey('floor-plan-json-editor'));
    final originalEditorText =
        tester.widget<TextField>(editor).controller!.text;
    final editedEditorText = originalEditorText.replaceFirst(
      'Conceptual prototype data only.',
      'Edited export text.',
    );
    expect(editedEditorText, isNot(originalEditorText));
    await tester.enterText(editor, editedEditorText);

    await tester.tap(find.byKey(const ValueKey('download-floor-plan-json')));
    await tester.pumpAndSettle();

    expect(filePicker.savedFileName, startsWith('riwaq-simulated-floor-plan-'));
    expect(filePicker.savedFileName, endsWith('.json'));
    expect(
      utf8.decode(filePicker.savedBytes!),
      tester.widget<TextField>(editor).controller!.text,
    );
    expect(filePicker.savedBytes, utf8.encode(editedEditorText));
    expect(tester.takeException(), isNull);
  });
}

Future<void> _openEditor(WidgetTester tester) async {
  await tester.pumpWidget(MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: FloorPlanScreen(
          onOpenMap: (_) {},
          destinationLocationId: 'EYE_CLINIC',
        ),
      ),
    ),
  ));
  await tester.pumpAndSettle();
  await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
  await tester.pumpAndSettle();
  await tester.ensureVisible(find.byKey(const ValueKey('edit-prototype-map')));
  await tester.tap(find.byKey(const ValueKey('edit-prototype-map')));
  await tester.pumpAndSettle();
}

class _FakeFilePickerPlatform extends FilePickerPlatform {
  PlatformFile? selectedFile;
  bool? lastPickRequestedWithData;
  List<String>? lastPickAllowedExtensions;
  Uint8List? savedBytes;
  String? savedFileName;

  @override
  Future<FilePickerResult?> pickFiles({
    String? dialogTitle,
    String? initialDirectory,
    FileType type = FileType.any,
    List<String>? allowedExtensions,
    Function(FilePickerStatus)? onFileLoading,
    int compressionQuality = 0,
    bool allowMultiple = false,
    bool withData = false,
    bool withReadStream = false,
    bool lockParentWindow = false,
    bool readSequential = false,
    bool cancelUploadOnWindowBlur = true,
  }) async {
    expect(type, FileType.custom);
    expect(allowMultiple, isFalse);
    lastPickRequestedWithData = withData;
    lastPickAllowedExtensions = allowedExtensions;
    final file = selectedFile;
    return file == null ? null : FilePickerResult([file]);
  }

  @override
  Future<String?> saveFile({
    String? dialogTitle,
    String? fileName,
    String? initialDirectory,
    FileType type = FileType.any,
    List<String>? allowedExtensions,
    Uint8List? bytes,
    bool lockParentWindow = false,
  }) async {
    savedBytes = bytes;
    savedFileName = fileName;
    return null;
  }
}
