import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/app.dart';
import 'package:riwaq/data/hospital_floor_plan_data.dart';
import 'package:riwaq/models/hospital_floor_plan.dart';
import 'package:riwaq/screens/floor_plan_screen.dart';
import 'package:riwaq/widgets/hospital_plan_2d.dart';
import 'package:riwaq/services/hospital_route_service.dart';
import 'package:riwaq/services/location_state.dart';
import 'package:riwaq/services/riwaq_local_store.dart';
import 'package:riwaq/services/ai/intent_classifier.dart';
import 'package:riwaq/models/assistant_response.dart';
import 'package:riwaq/services/ai/ai_service.dart';
import 'package:riwaq/data/repositories/location_repository.dart';
import 'package:riwaq/services/vision/visual_landmark_recognizer.dart';
import 'package:riwaq/models/visual_landmark.dart';
import 'package:riwaq/theme/app_theme.dart';
import 'package:image/image.dart' as image_lib;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('Riwaq app renders home screen', (tester) async {
    await tester.pumpWidget(const RiwaqApp());
    expect(find.text('خريطة المستشفى'), findsNothing);
    expect(find.textContaining('مرحباً'), findsOneWidget);
  });

  testWidgets(
      'primary navigation, doctor details, and destination handoff work',
      (tester) async {
    await tester.pumpWidget(const RiwaqApp());
    expect(find.text('الرئيسية'), findsOneWidget);
    expect(find.text('الخريطة'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is NavigationDestination && widget.label == 'مواعيدي',
      ),
      findsOneWidget,
    );
    expect(find.text('رِواق'), findsOneWidget);

    await tester.tap(find.byTooltip('فتح القائمة'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الأطباء والتخصصات'));
    await tester.pumpAndSettle();
    expect(find.text('د. نورة العتيبي'), findsOneWidget);

    await tester.tap(find.text('د. نورة العتيبي'));
    await tester.pumpAndSettle();
    expect(find.text('اعرض العيادة على الخريطة'), findsOneWidget);

    await tester.ensureVisible(find.text('اعرض العيادة على الخريطة'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('اعرض العيادة على الخريطة'));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<DropdownButtonFormField<String>>(
              find.byType(DropdownButtonFormField<String>))
          .initialValue,
      'F_OPHTHALMOLOGY',
    );
    final map = tester.widget<HospitalPlan2D>(find.byType(HospitalPlan2D));
    expect(map.floor.id, 'FIRST');
    expect(map.destinationId, 'F_OPHTHALMOLOGY');
    expect(map.route, isNotNull);
    expect(find.byKey(const ValueKey('navigation-start')), findsOneWidget);
  });

  testWidgets('assistant input stays mounted while switching primary tabs',
      (tester) async {
    await tester.pumpWidget(const RiwaqApp());
    await tester.tap(find.text('رِواق'));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField), 'وين الصيدلية؟');
    await tester.tap(find.text('الرئيسية'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('رِواق'));
    await tester.pumpAndSettle();

    expect(
      tester.widget<TextField>(find.byType(TextField)).controller?.text,
      'وين الصيدلية؟',
    );
  });

  testWidgets('every drawer destination opens and returns home',
      (tester) async {
    await tester.pumpWidget(const RiwaqApp());
    for (final title in [
      'الأطباء والتخصصات',
      'آخر الزيارات',
      'العناوين المحفوظة',
      'الملف الشخصي',
      'الإشعارات',
      'الإعدادات',
      'المساعدة والدعم',
    ]) {
      await tester.tap(find.byTooltip('فتح القائمة'));
      await tester.pumpAndSettle();
      final destination = find.text(title).last;
      await tester.ensureVisible(destination);
      await tester.tap(destination);
      await tester.pumpAndSettle();
      expect(find.byTooltip('رجوع'), findsOneWidget);
      expect(find.text(title), findsWidgets);
      await tester.tap(find.byTooltip('رجوع'));
      await tester.pumpAndSettle();
      expect(find.textContaining('مرحباً'), findsOneWidget);
    }
  });

  test('schematic floor data has stable unique IDs and connected nodes', () {
    expect(hospitalFloorPlans.map((floor) => floor.id).toSet(), hasLength(3));
    final allPlaceIds = hospitalFloorPlans
        .expand((floor) => floor.places)
        .map((place) => place.id)
        .toList();
    expect(allPlaceIds.toSet(), hasLength(allPlaceIds.length));

    for (final floor in hospitalFloorPlans) {
      final placesById = {for (final place in floor.places) place.id: place};
      expect(
        floor.selectablePlaces
            .where((place) => place.category == FloorPlaceCategory.prayerRoom)
            .length,
        2,
      );
      expect(
        floor.selectablePlaces
            .where((place) => place.category == FloorPlaceCategory.restroom)
            .length,
        2,
      );
      expect(
        floor.places
            .where((place) => place.category == FloorPlaceCategory.corridor)
            .length,
        greaterThanOrEqualTo(20),
      );
      for (final place in floor.places) {
        expect(place.floorId, floor.id);
        expect(place.x, inInclusiveRange(0, 1));
        expect(place.y, inInclusiveRange(0, 1));
        for (final connectionId in place.connections) {
          expect(placesById.containsKey(connectionId), isTrue,
              reason: '${place.id} connects to a missing node $connectionId');
        }
      }
    }
  });

  testWidgets(
      'unified map switches floors, selects places, and links destinations',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    await tester.pumpWidget(const RiwaqApp());
    await tester.tap(find.text('الخريطة'));
    await tester.pumpAndSettle();
    expect(find.text('الخريطة الحالية'), findsNothing);
    expect(find.text('مخطط الطابق 2D'), findsNothing);
    expect(find.textContaining('مسار محاكاة من'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('source-plan-button')), findsNothing);
    expect(find.textContaining('مرجع المخطط'), findsNothing);

    await tester.ensureVisible(find.text('الدور الثاني'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الدور الثاني'));
    await tester.pumpAndSettle();
    await tester
        .ensureVisible(find.byKey(const ValueKey('plan-place-S_OBSTETRICS')));
    await tester.tap(find.byKey(const ValueKey('plan-place-S_OBSTETRICS')));
    await tester.pumpAndSettle();
    await tester
        .ensureVisible(find.byKey(const ValueKey('destination-details')));
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('destination-details')),
        matching: find.byType(Text),
      ),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('destination-details')),
        matching: find.byType(IconButton),
      ),
      findsOneWidget,
    );
    expect(find.textContaining('S_OBSTETRICS'), findsNothing);
    expect(find.textContaining('لا تستخدم للتوجيه الفعلي'), findsOneWidget);

    await tester.ensureVisible(find.text('الدور الأول'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الدور الأول'));
    await tester.pumpAndSettle();
    await tester.drag(find.byType(Scrollable).first, const Offset(0, -400));
    await tester.pumpAndSettle();
    await tester.ensureVisible(
        find.byKey(const ValueKey('plan-place-F_OPHTHALMOLOGY')));
    await tester.tap(find.byKey(const ValueKey('plan-place-F_OPHTHALMOLOGY')));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<DropdownButtonFormField<String>>(
              find.byType(DropdownButtonFormField<String>))
          .initialValue,
      'F_OPHTHALMOLOGY',
    );
  });

  testWidgets(
      'map labels have contrast backplates and route markers have spoken roles',
      (tester) async {
    final semantics = tester.ensureSemantics();
    final floor =
        hospitalFloorPlans.firstWhere((floor) => floor.id == 'GROUND');
    final route = HospitalRouteService().findRoute(
      startLocationId: 'MAIN_ENTRANCE',
      destinationLocationId: 'PHARMACY',
    );
    expect(route, isNotNull);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SizedBox(
          width: 430,
          height: 480,
          child: HospitalPlan2D(
            floor: floor,
            route: route,
            startId: 'MAIN_ENTRANCE',
            destinationId: 'PHARMACY',
            onSelect: (_) {},
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final place = floor.places.firstWhere((place) => place.id == 'G_PHARMACY');
    final placeSemantics = tester
        .getSemantics(find.byKey(const ValueKey('plan-place-G_PHARMACY')))
        .getSemanticsData();
    expect(placeSemantics.label, contains(place.nameAr));
    expect(placeSemantics.label, contains(place.descriptionAr));
    expect(placeSemantics.hasFlag(SemanticsFlag.isButton), isTrue);
    expect(placeSemantics.hasAction(SemanticsAction.tap), isTrue);

    final label = tester.widget<Text>(
      find.byKey(const ValueKey('plan-place-label-G_PHARMACY')),
    );
    expect(label.style?.color, const Color(0xFF193B34));
    expect(label.style?.fontSize, 10);
    expect(
      tester
          .widget<DecoratedBox>(find
              .byKey(const ValueKey('plan-place-label-backplate-G_PHARMACY')))
          .decoration,
      isA<BoxDecoration>().having(
        (decoration) => decoration.color,
        'opaque label backing',
        const Color(0xFFFDFEFD),
      ),
    );

    expect(
      tester
          .getSemantics(find.byKey(const ValueKey('route-marker-start')))
          .getSemanticsData()
          .label,
      startsWith('نقطة البداية:'),
    );
    expect(
      tester
          .getSemantics(find.byKey(const ValueKey('route-marker-destination')))
          .getSemanticsData()
          .label,
      startsWith('نقطة الوجهة:'),
    );
    expect(
      tester
          .widget<Icon>(
            find.byKey(const ValueKey('route-marker-icon-start')),
          )
          .icon,
      Icons.flag_rounded,
    );
    expect(
      tester
          .widget<Icon>(
            find.byKey(const ValueKey('route-marker-icon-destination')),
          )
          .icon,
      Icons.place_rounded,
    );
    expect(
      tester
          .widget<Text>(
            find.byKey(const ValueKey('route-marker-text-start')),
          )
          .style
          ?.color,
      const Color(0xFF193B34),
    );

    final firstFloor =
        hospitalFloorPlans.firstWhere((floor) => floor.id == 'FIRST');
    final crossFloorRoute = HospitalRouteService().findRoute(
      startLocationId: 'MAIN_ENTRANCE',
      destinationLocationId: 'EYE_CLINIC',
    );
    expect(crossFloorRoute, isNotNull);
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SizedBox(
          width: 430,
          height: 480,
          child: HospitalPlan2D(
            floor: firstFloor,
            route: crossFloorRoute,
            startId: 'MAIN_ENTRANCE',
            destinationId: 'EYE_CLINIC',
            onSelect: (_) {},
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    expect(
      tester
          .getSemantics(
              find.byKey(const ValueKey('route-marker-floor-transition')))
          .getSemanticsData()
          .label,
      startsWith('تغيير الدور:'),
    );
    expect(
      tester
          .widget<Icon>(
            find.byKey(const ValueKey('route-marker-icon-floor-transition')),
          )
          .icon,
      Icons.swap_vert_rounded,
    );
    semantics.dispose();
  });

  testWidgets('map status and legend text use readable non-color labels',
      (tester) async {
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final warning = tester.widget<Text>(
      find.byKey(const ValueKey('map-simulation-warning')),
    );
    expect(warning.style?.color, const Color(0xFF52645E));
    expect(warning.style?.fontSize, 12);
    expect(find.byKey(const ValueKey('map-marker-legend')), findsOneWidget);
    const labels = [
      'بداية المسار والممرات',
      'الوجهة',
      'تغيير الدور',
    ];
    for (final label in labels) {
      expect(
        tester
            .widget<Text>(find.byKey(ValueKey('map-legend-label-$label')))
            .style
            ?.color,
        const Color(0xFF52645E),
      );
    }
    expect(tester.takeException(), isNull);
  });

  testWidgets('map pins stay tappable after zoom and pan on phone and tablet',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });

    for (final viewport in [const Size(320, 740), const Size(900, 1200)]) {
      await tester.pumpWidget(const SizedBox.shrink());
      tester.view.physicalSize = viewport;
      tester.view.devicePixelRatio = 1;
      final selectedPlaces = <String>[];

      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: SafeArea(
            child: SingleChildScrollView(
              child: FloorPlanScreen(
                onOpenMap: selectedPlaces.add,
                destinationLocationId: 'EYE_CLINIC',
              ),
            ),
          ),
        ),
      ));
      await tester.pumpAndSettle();

      final warning = find.textContaining(
        'خريطة ومسارات تجريبية غير متحقق منها',
      );
      expect(warning, findsOneWidget);
      expect(tester.takeException(), isNull);

      final map = find.byType(InteractiveViewer);
      await tester.ensureVisible(map);
      await tester.pumpAndSettle();
      final pin = find.byKey(const ValueKey('plan-place-F_OPHTHALMOLOGY'));
      await tester.ensureVisible(pin);
      await tester.pumpAndSettle();
      final transform =
          tester.widget<InteractiveViewer>(map).transformationController!;
      final initialScale = transform.value.getMaxScaleOnAxis();
      final pinchCenter = tester.getCenter(pin);

      final firstFinger = await tester.startGesture(
        pinchCenter + const Offset(-25, 0),
        pointer: 1,
      );
      final secondFinger = await tester.startGesture(
        pinchCenter + const Offset(25, 0),
        pointer: 2,
      );
      await firstFinger.moveTo(pinchCenter + const Offset(-65, 0));
      await secondFinger.moveTo(pinchCenter + const Offset(65, 0));
      await tester.pump();
      expect(transform.value.getMaxScaleOnAxis(), greaterThan(initialScale));

      final beforePan = transform.value.getTranslation();
      await firstFinger.moveTo(pinchCenter + const Offset(-45, 12));
      await secondFinger.moveTo(pinchCenter + const Offset(85, 12));
      await tester.pump();
      expect(transform.value.getTranslation(), isNot(equals(beforePan)));
      await firstFinger.up();
      await secondFinger.up();
      await tester.pumpAndSettle();

      await tester.tap(pin);
      await tester.pumpAndSettle();
      expect(selectedPlaces, contains('EYE_CLINIC'));
      expect(warning, findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('map controls and pins work on a short landscape viewport',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(740, 320);
    tester.view.devicePixelRatio = 1;
    final selectedPlaces = <String>[];

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: selectedPlaces.add,
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final warning = find.textContaining(
      'خريطة ومسارات تجريبية غير متحقق منها',
    );
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);

    final zoomIn = find.byKey(const ValueKey('map-zoom-in'));
    await tester.ensureVisible(zoomIn);
    await tester.pumpAndSettle();
    final map = find.byType(InteractiveViewer);
    final transform =
        tester.widget<InteractiveViewer>(map).transformationController!;
    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    expect(transform.value.getMaxScaleOnAxis(), greaterThan(1));

    await tester.tap(find.byKey(const ValueKey('map-zoom-reset')));
    await tester.pumpAndSettle();
    final pin = find.byKey(const ValueKey('plan-place-F_OPHTHALMOLOGY'));
    await tester.ensureVisible(pin);
    await tester.pumpAndSettle();
    await tester.tap(pin);
    await tester.pumpAndSettle();

    expect(selectedPlaces, contains('EYE_CLINIC'));
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('map controls and pins work with enlarged text', (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    final selectedPlaces = <String>[];

    await tester.pumpWidget(MaterialApp(
      home: Builder(
        builder: (context) => MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: const TextScaler.linear(2)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: FloorPlanScreen(
                onOpenMap: selectedPlaces.add,
                destinationLocationId: 'EYE_CLINIC',
              ),
            ),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final warning = find.textContaining(
      'خريطة ومسارات تجريبية غير متحقق منها',
    );
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);

    final zoomIn = find.byKey(const ValueKey('map-zoom-in'));
    await tester.ensureVisible(zoomIn);
    await tester.pumpAndSettle();
    final map = find.byType(InteractiveViewer);
    final transform =
        tester.widget<InteractiveViewer>(map).transformationController!;
    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    expect(transform.value.getMaxScaleOnAxis(), greaterThan(1));

    await tester.tap(find.byKey(const ValueKey('map-zoom-reset')));
    await tester.pumpAndSettle();
    final pin = find.byKey(const ValueKey('plan-place-F_OPHTHALMOLOGY'));
    await tester.ensureVisible(pin);
    await tester.pumpAndSettle();
    await tester.tap(pin);
    await tester.pumpAndSettle();

    expect(selectedPlaces, contains('EYE_CLINIC'));
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
      '3D model controls stay usable on a short landscape screen with enlarged text',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(740, 320);
    tester.view.devicePixelRatio = 1;
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    await store.setAllowStairs(true);
    await store.setAllowElevators(true);
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      home: Builder(
        builder: (context) => MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: const TextScaler.linear(2)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: FloorPlanScreen(
                onOpenMap: (_) {},
                destinationLocationId: 'EYE_CLINIC',
              ),
            ),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final warning = find.textContaining(
      'خريطة ومسارات تجريبية غير متحقق منها',
    );
    expect(warning, findsOneWidget);

    final modelToggle = find.text('نموذج 3D');
    await tester.ensureVisible(modelToggle);
    await tester.tap(modelToggle);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('hospital-3d-view')), findsOneWidget);

    final zoomIn = find.byTooltip('تكبير النموذج');
    final zoomOut = find.byTooltip('تصغير النموذج');
    final reset = find.byTooltip('إعادة ضبط الكاميرا');
    final cameraStatus = find.byKey(const ValueKey('model-camera-status'));

    await tester.ensureVisible(zoomIn);
    await tester.pumpAndSettle();
    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(cameraStatus).data, contains('تقريب 120٪'));

    await tester.tap(zoomOut);
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(cameraStatus).data, contains('تقريب 100٪'));

    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    await tester.tap(reset);
    await tester.pumpAndSettle();
    expect(tester.widget<Text>(cameraStatus).data, contains('تقريب 100٪'));
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('2D map zoom controls are accessible, bounded, and resettable',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    final semantics = tester.ensureSemantics();

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final warning = find.textContaining(
      'خريطة ومسارات تجريبية غير متحقق منها',
    );
    expect(warning, findsOneWidget);

    final zoomIn = find.byKey(const ValueKey('map-zoom-in'));
    final zoomOut = find.byKey(const ValueKey('map-zoom-out'));
    final reset = find.byKey(const ValueKey('map-zoom-reset'));
    await tester.ensureVisible(zoomIn);
    await tester.pumpAndSettle();

    expect(
      tester.getSemantics(zoomIn).getSemanticsData().tooltip,
      'تكبير الخريطة',
    );
    expect(
      tester.getSemantics(zoomOut).getSemanticsData().tooltip,
      'تصغير الخريطة',
    );
    expect(
      tester.getSemantics(reset).getSemanticsData().tooltip,
      'إعادة ضبط تكبير الخريطة',
    );
    expect(
      tester
          .getSemantics(zoomIn)
          .getSemanticsData()
          .hasAction(SemanticsAction.tap),
      isTrue,
    );

    final map = find.byType(InteractiveViewer);
    final transform =
        tester.widget<InteractiveViewer>(map).transformationController!;
    expect(transform.value.getMaxScaleOnAxis(), 1);

    final zoomInButton = tester.widget<IconButton>(zoomIn);
    zoomInButton.focusNode!.requestFocus();
    await tester.pump();
    await tester.sendKeyEvent(LogicalKeyboardKey.enter);
    await tester.pumpAndSettle();
    expect(transform.value.getMaxScaleOnAxis(), greaterThan(1));
    SemanticsData zoomAnnouncement() => tester
        .getSemantics(
          find.byKey(const ValueKey('map-zoom-announcement')),
        )
        .getSemanticsData();
    expect(zoomAnnouncement().label, 'مقياس الخريطة: 125٪');
    expect(zoomAnnouncement().hasFlag(SemanticsFlag.isLiveRegion), isTrue);

    await tester.tap(zoomOut);
    await tester.pumpAndSettle();
    expect(zoomAnnouncement().label, 'مقياس الخريطة: 100٪');
    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    expect(zoomAnnouncement().label, 'مقياس الخريطة: 125٪');
    await tester.tap(reset);
    await tester.pumpAndSettle();
    expect(zoomAnnouncement().label, 'مقياس الخريطة: 100٪');

    for (var count = 0; count < 20; count++) {
      await tester.tap(zoomIn);
      await tester.pump();
    }
    expect(
      transform.value.getMaxScaleOnAxis(),
      closeTo(4.5, 0.0001),
    );

    for (var count = 0; count < 40; count++) {
      await tester.tap(zoomOut);
      await tester.pump();
    }
    expect(transform.value.getMaxScaleOnAxis(), closeTo(1, 0.0001));

    await tester.tap(zoomIn);
    await tester.pumpAndSettle();
    await tester.tap(reset);
    await tester.pumpAndSettle();
    expect(transform.value.getMaxScaleOnAxis(), 1);
    final resetTranslation = transform.value.getTranslation();
    expect(resetTranslation.x, 0);
    expect(resetTranslation.y, 0);
    expect(resetTranslation.z, 0);
    expect(warning, findsOneWidget);
    expect(tester.takeException(), isNull);
    semantics.dispose();
  });

  testWidgets('2D map pans with arrow keys and stays within its boundaries',
      (tester) async {
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 400,
            height: 400,
            child: HospitalPlan2D(
              floor: hospitalFloorPlans.first,
              onSelect: (_) {},
            ),
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final map = find.byType(InteractiveViewer);
    final transform =
        tester.widget<InteractiveViewer>(map).transformationController!;
    await tester.tapAt(tester.getRect(map).center);
    await tester.pump();

    await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
    await tester.sendKeyEvent(LogicalKeyboardKey.arrowDown);
    await tester.pump();
    var translation = transform.value.getTranslation();
    expect(translation.x, 40);
    expect(translation.y, 40);

    for (var count = 0; count < 10; count++) {
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowDown);
    }
    await tester.pump();
    translation = transform.value.getTranslation();
    expect(translation.x, 70);
    expect(translation.y, 70);

    for (var count = 0; count < 10; count++) {
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowLeft);
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowUp);
    }
    await tester.pump();
    translation = transform.value.getTranslation();
    expect(translation.x, -70);
    expect(translation.y, -70);

    final zoomIn = find.byKey(const ValueKey('map-zoom-in'));
    final zoomInFocusNode = tester.widget<IconButton>(zoomIn).focusNode!;
    zoomInFocusNode.requestFocus();
    await tester.pump();
    await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
    await tester.pump();
    translation = transform.value.getTranslation();
    expect(translation.x, -70);

    zoomInFocusNode.requestFocus();
    await tester.pump();
    await tester.sendKeyEvent(LogicalKeyboardKey.enter);
    await tester.pumpAndSettle();
    expect(transform.value.getMaxScaleOnAxis(), greaterThan(1));
    expect(tester.takeException(), isNull);
  });

  testWidgets('demo start changes the route and shows elevator transitions',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    await tester.pumpWidget(const RiwaqApp());
    await tester.tap(find.text('الخريطة'));
    await tester.pumpAndSettle();

    await tester
        .ensureVisible(find.textContaining('انتقل عبر المصعد إلى الدور الأول'));
    expect(find.textContaining('انتقل عبر المصعد إلى الدور الأول'),
        findsOneWidget);

    await tester.ensureVisible(find.byKey(const ValueKey('change-demo-start')));
    await tester.tap(find.byKey(const ValueKey('change-demo-start')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('demo-start-dropdown')));
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
        find.text('الاستقبال الرئيسي · الدور الأرضي'), -200,
        scrollable: find.byType(Scrollable).last);
    await tester.tap(find.text('الاستقبال الرئيسي · الدور الأرضي').last);
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.textContaining('مسار محاكاة من الاستقبال'));
    expect(find.textContaining('مسار محاكاة من الاستقبال'), findsOneWidget);
    expect(RiwaqLocationState.instance.currentLocationId, 'RECEPTION');
  });

  testWidgets('screen readers hear ordered floor transition directions',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    final semantics = tester.ensureSemantics();
    RiwaqLocationState.instance
        .setCurrent(locationId: 'G_MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'S_SURGERY', floor: 2);
    final route = HospitalRouteService().findRoute(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'S_SURGERY',
    );
    expect(route, isNotNull);
    expect(route!.floorTransitions, hasLength(2));

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'S_SURGERY',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    const floorNames = {
      'GROUND': 'الدور الأرضي',
      'FIRST': 'الدور الأول',
      'SECOND': 'الدور الثاني',
    };
    final spokenLabels = <String>[];
    for (final entry in route.floorTransitions.asMap().entries) {
      final key = ValueKey('route-floor-transition-${entry.key + 1}');
      await tester.ensureVisible(find.byKey(key));
      await tester.pumpAndSettle();

      final semanticsData =
          tester.getSemantics(find.byKey(key)).getSemanticsData();
      final spokenLabel = semanticsData.label;
      spokenLabels.add(spokenLabel);
      expect(semanticsData.hasFlag(SemanticsFlag.isButton), isTrue);
      expect(semanticsData.hasAction(SemanticsAction.tap), isTrue);
      final transition = entry.value;
      final mode = transition.from.category == FloorPlaceCategory.elevator
          ? 'المصعد'
          : 'السلالم';
      expect(
        spokenLabel,
        'الانتقال ${entry.key + 1}: استخدم $mode من '
        '${floorNames[transition.from.floorId]} إلى '
        '${floorNames[transition.to.floorId]}.',
      );
    }
    expect(spokenLabels, hasLength(2));
    semantics.dispose();
  });

  testWidgets('mobility controls expose and announce their current state',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    addTearDown(() async {
      await store.setAllowStairs(true);
      await store.setAllowElevators(true);
    });
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    final semantics = tester.ensureSemantics();
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();
    const stairsKey = ValueKey('route-avoid-stairs-semantics');
    const elevatorsKey = ValueKey('route-avoid-elevators-semantics');
    await tester.ensureVisible(find.byKey(stairsKey));
    await tester.pumpAndSettle();

    SemanticsData dataFor(ValueKey<String> key) =>
        tester.getSemantics(find.byKey(key)).getSemanticsData();

    expect(dataFor(stairsKey).label, 'السلالم');
    expect(dataFor(stairsKey).value, 'مسموح');
    expect(
      dataFor(stairsKey).hasFlag(SemanticsFlag.hasToggledState),
      isTrue,
    );
    expect(dataFor(stairsKey).hasFlag(SemanticsFlag.isToggled), isFalse);
    expect(dataFor(stairsKey).hasFlag(SemanticsFlag.isLiveRegion), isTrue);
    expect(dataFor(stairsKey).hasAction(SemanticsAction.tap), isTrue);

    expect(dataFor(elevatorsKey).label, 'المصاعد');
    expect(dataFor(elevatorsKey).value, 'مسموح');
    expect(
      dataFor(elevatorsKey).hasFlag(SemanticsFlag.hasToggledState),
      isTrue,
    );
    expect(dataFor(elevatorsKey).hasFlag(SemanticsFlag.isToggled), isFalse);
    expect(dataFor(elevatorsKey).hasFlag(SemanticsFlag.isLiveRegion), isTrue);

    tester.semantics.tap(find.semantics.byLabel('السلالم'));
    await tester.pumpAndSettle();
    expect(dataFor(stairsKey).label, 'السلالم');
    expect(dataFor(stairsKey).value, 'متجنب');
    expect(dataFor(stairsKey).hasFlag(SemanticsFlag.isToggled), isTrue);
    expect(dataFor(stairsKey).hasFlag(SemanticsFlag.isLiveRegion), isTrue);

    await tester.ensureVisible(find.byKey(elevatorsKey));
    await tester.pumpAndSettle();
    tester.semantics.tap(find.semantics.byLabel('المصاعد'));
    await tester.pumpAndSettle();
    expect(dataFor(elevatorsKey).label, 'المصاعد');
    expect(dataFor(elevatorsKey).value, 'متجنب');
    expect(dataFor(elevatorsKey).hasFlag(SemanticsFlag.isToggled), isTrue);
    expect(dataFor(elevatorsKey).hasFlag(SemanticsFlag.isLiveRegion), isTrue);

    tester.semantics.tap(find.semantics.byLabel('السلالم'));
    await tester.pumpAndSettle();
    expect(dataFor(stairsKey).value, 'مسموح');
    expect(dataFor(stairsKey).hasFlag(SemanticsFlag.isToggled), isFalse);
    semantics.dispose();
  });

  testWidgets(
      'step navigation moves the demo marker and synchronizes 3D floors',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    await store.setAllowStairs(true);
    await store.setAllowElevators(true);
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.text('الدور الأرضي'));
    await tester.tap(find.text('الدور الأرضي'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const ValueKey('navigation-start')));
    await tester.tap(find.byKey(const ValueKey('navigation-start')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-progress')), findsOneWidget);

    await tester.ensureVisible(find.byKey(const ValueKey('navigation-pause')));
    await tester.tap(find.byKey(const ValueKey('navigation-pause')));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const ValueKey('navigation-resume')));
    await tester.tap(find.byKey(const ValueKey('navigation-resume')));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.text('نموذج 3D'));
    await tester.tap(find.text('نموذج 3D'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('الدور المحدد'));
    await tester.tap(find.text('الدور المحدد'));
    await tester.pumpAndSettle();

    final initialLocation = RiwaqLocationState.instance.currentLocationId;
    await tester
        .ensureVisible(find.byKey(const ValueKey('navigation-next-step')));
    await tester.tap(find.byKey(const ValueKey('navigation-next-step')));
    await tester.pumpAndSettle();
    expect(
        RiwaqLocationState.instance.currentLocationId, isNot(initialLocation));
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('route-summary'))).data,
      isNot(contains('المدخل الرئيسي')),
    );

    var safety = 0;
    while (RiwaqLocationState.instance.currentFloor != 1 && safety < 20) {
      final next = find.byKey(const ValueKey('navigation-next-step'));
      expect(next, findsOneWidget,
          reason: 'the route should remain navigable until floor one');
      await tester.ensureVisible(next);
      await tester.tap(next);
      await tester.pumpAndSettle();
      safety++;
    }
    expect(RiwaqLocationState.instance.currentFloor, 1);
    final firstFloorChip = find.ancestor(
      of: find.text('الدور الأول'),
      matching: find.byType(ChoiceChip),
    );
    expect(tester.widget<ChoiceChip>(firstFloorChip.first).selected, isTrue);
    expect(find.byKey(const ValueKey('hospital-3d-view')), findsOneWidget);

    while (find
            .byKey(const ValueKey('navigation-next-step'))
            .evaluate()
            .isNotEmpty &&
        safety < 24) {
      final next = find.byKey(const ValueKey('navigation-next-step'));
      await tester.ensureVisible(next);
      await tester.tap(next);
      await tester.pumpAndSettle();
      safety++;
    }
    expect(RiwaqLocationState.instance.currentLocationId, 'EYE_CLINIC');
    expect(find.byKey(const ValueKey('navigation-arrived')), findsOneWidget);

    await tester
        .ensureVisible(find.byKey(const ValueKey('navigation-restart')));
    await tester.tap(find.byKey(const ValueKey('navigation-restart')));
    await tester.pumpAndSettle();
    expect(RiwaqLocationState.instance.currentLocationId, 'MAIN_ENTRANCE');
    expect(RiwaqLocationState.instance.currentFloor, 0);
    await tester.ensureVisible(find.byKey(const ValueKey('navigation-cancel')));
    await tester.tap(find.byKey(const ValueKey('navigation-cancel')));
    await tester.pumpAndSettle();
    expect(find.text('أُلغي التوجيه التجريبي.'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
      'active and paused simulated directions recalculate after a location change',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    SharedPreferences.setMockInitialValues({});
    RiwaqColors.darkMode = false;
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    await store.setAllowStairs(true);
    await store.setAllowElevators(true);
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const ValueKey('navigation-start')));
    await tester.tap(find.byKey(const ValueKey('navigation-start')));
    await tester.pumpAndSettle();

    final initialSummary =
        tester.widget<Text>(find.byKey(const ValueKey('route-summary'))).data;
    expect(initialSummary, contains('المدخل الرئيسي'));
    expect(find.byKey(const ValueKey('navigation-pause')), findsOneWidget);

    RiwaqLocationState.instance.setCurrent(locationId: 'G_RECEPTION', floor: 0);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-pause')), findsOneWidget);
    expect(find.byKey(const ValueKey('navigation-progress')), findsOneWidget);
    expect(
      tester
          .widget<Text>(find.byKey(const ValueKey('navigation-progress')))
          .data,
      startsWith('الخطوة 1'),
    );
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('route-summary'))).data,
      isNot(initialSummary),
    );
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('route-summary'))).data,
      contains('الاستقبال الرئيسي'),
    );

    await tester.ensureVisible(find.byKey(const ValueKey('navigation-pause')));
    await tester.tap(find.byKey(const ValueKey('navigation-pause')));
    await tester.pumpAndSettle();
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('navigation-resume')), findsOneWidget);
    expect(find.byKey(const ValueKey('navigation-progress')), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('map controls and route labels follow the English locale',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    SharedPreferences.setMockInitialValues({});
    RiwaqColors.darkMode = false;
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    addTearDown(() async => store.setLanguageCode('ar'));
    await store.setLanguageCode('en');
    await store.setAllowStairs(true);
    await store.setAllowElevators(true);
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      theme: AppTheme.light,
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    expect(find.text('Hospital map'), findsOneWidget);
    expect(find.text('Destination'), findsWidgets);
    expect(find.text('My location'), findsOneWidget);
    expect(find.text('Choose map start'), findsOneWidget);
    expect(find.text('Ground floor'), findsOneWidget);
    expect(find.text('2D plan'), findsOneWidget);
    expect(find.text('Eye clinic'), findsWidgets);
    expect(
      tester.widget<Text>(find.byKey(const ValueKey('route-summary'))).data,
      contains('Main entrance'),
    );
    expect(find.text('موقعي'), findsNothing);
    expect(find.text('المدخل الرئيسي'), findsNothing);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('mobility preferences choose alternatives and explain no route',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    await store.setAllowStairs(true);
    await store.setAllowElevators(true);
    addTearDown(() async {
      await store.resetMobilityPreferences();
    });
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    final semantics = tester.ensureSemantics();

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    const routeAnnouncementKey = ValueKey('route-availability-announcement');

    SemanticsData routeAnnouncement() => tester
        .getSemantics(find.byKey(routeAnnouncementKey))
        .getSemanticsData();

    expect(routeAnnouncement().label, contains('مسار محاكاة'));
    expect(
      routeAnnouncement().hasFlag(SemanticsFlag.isLiveRegion),
      isTrue,
    );

    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();
    final avoidElevators = find.byKey(const ValueKey('route-avoid-elevators'));
    await tester.tap(avoidElevators);
    await tester.pumpAndSettle();
    expect(find.textContaining('انتقل عبر السلالم'), findsOneWidget);

    final avoidStairs = find.byKey(const ValueKey('route-avoid-stairs'));
    await tester.tap(avoidStairs);
    await tester.pumpAndSettle();
    expect(
      find.textContaining('لا يتوفر مسار يطابق تفضيلات الحركة'),
      findsOneWidget,
    );
    expect(routeAnnouncement().label, contains('لا يتوفر مسار'));
    expect(
      routeAnnouncement().hasFlag(SemanticsFlag.isLiveRegion),
      isTrue,
    );

    await tester.tap(find.byKey(const ValueKey('reset-route-preferences')));
    await tester.pumpAndSettle();
    expect(routeAnnouncement().label, contains('مسار محاكاة'));
    expect(
      routeAnnouncement().hasFlag(SemanticsFlag.isLiveRegion),
      isTrue,
    );
    semantics.dispose();
  });

  testWidgets(
      'failed mobility preference saves are announced while routes update',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    var writeCount = 0;
    store.mobilityPreferenceWriteOverride = (_, __) async {
      writeCount++;
      if (writeCount == 2) throw StateError('storage unavailable');
      return false;
    };
    addTearDown(() async {
      store.mobilityPreferenceWriteOverride = null;
      await store.resetMobilityPreferences();
    });
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: FloorPlanScreen(
            onOpenMap: (_) {},
            destinationLocationId: 'EYE_CLINIC',
          ),
        ),
      ),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('route-avoid-elevators')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('mobility-preference-save-error')),
      findsOneWidget,
    );
    expect(find.textContaining('انتقل عبر السلالم'), findsOneWidget);
    expect(
      tester
          .widget<FilterChip>(
              find.byKey(const ValueKey('route-avoid-elevators')))
          .selected,
      isTrue,
    );

    await tester.tap(find.byKey(const ValueKey('route-avoid-stairs')));
    await tester.pumpAndSettle();
    expect(find.textContaining('لا يتوفر مسار يطابق تفضيلات الحركة'),
        findsOneWidget);
    expect(
      find.byKey(const ValueKey('mobility-preference-save-error')),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('reset-route-preferences')));
    await tester.pumpAndSettle();
    expect(
      tester
          .widget<FilterChip>(find.byKey(const ValueKey('route-avoid-stairs')))
          .selected,
      isFalse,
    );
    expect(
      tester
          .widget<FilterChip>(
              find.byKey(const ValueKey('route-avoid-elevators')))
          .selected,
      isFalse,
    );
    expect(find.textContaining('انتقل عبر المصعد'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('mobility-preference-save-error')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('open map views share mobility choices and recalculate routes',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    addTearDown(() async {
      await store.resetMobilityPreferences();
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    tester.view.physicalSize = const Size(430, 1000);
    tester.view.devicePixelRatio = 1;

    FloorPlanScreen mapView() => FloorPlanScreen(
          onOpenMap: (_) {},
          destinationLocationId: 'EYE_CLINIC',
        );

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: Column(children: [mapView(), mapView()]),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    final options = find.byKey(const ValueKey('advanced-map-options'));
    await tester.tap(options.first);
    await tester.pumpAndSettle();
    final avoidElevators = find.byKey(const ValueKey('route-avoid-elevators'));
    await tester.tap(avoidElevators.first);
    await tester.pumpAndSettle();

    expect(
      find.textContaining('انتقل عبر السلالم'),
      findsNWidgets(2),
    );
    expect(
      tester
          .widgetList<FilterChip>(avoidElevators)
          .map((chip) => chip.selected),
      everyElement(isTrue),
    );

    final avoidStairs = find.byKey(const ValueKey('route-avoid-stairs'));
    await tester.tap(avoidStairs.first);
    await tester.pumpAndSettle();

    expect(
      find.textContaining('لا يتوفر مسار يطابق تفضيلات الحركة'),
      findsNWidgets(2),
    );
    expect(
      tester.widgetList<FilterChip>(avoidStairs).map((chip) => chip.selected),
      everyElement(isTrue),
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('mobility preferences survive leaving and reopening the map',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = RiwaqLocalStore.instance;
    await store.initialize();
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    addTearDown(() async {
      await store.setAllowStairs(true);
      await store.setAllowElevators(true);
    });

    Future<void> openMap() async {
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: FloorPlanScreen(
              onOpenMap: (_) {},
              destinationLocationId: 'EYE_CLINIC',
            ),
          ),
        ),
      ));
      await tester.pumpAndSettle();
    }

    await openMap();
    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();
    final warning = find.textContaining(
      'خريطة ومسارات تجريبية غير متحقق منها',
    );
    expect(warning, findsOneWidget);

    final avoidStairs = find.byKey(const ValueKey('route-avoid-stairs'));
    final avoidElevators = find.byKey(const ValueKey('route-avoid-elevators'));
    await tester.ensureVisible(avoidStairs);
    await tester.tap(avoidStairs);
    await tester.pumpAndSettle();
    await tester.ensureVisible(avoidElevators);
    await tester.tap(avoidElevators);
    await tester.pumpAndSettle();

    // Wait for both local writes before simulating a fresh map visit.
    await store.setAllowStairs(store.allowStairs);
    await store.setAllowElevators(store.allowElevators);
    expect(store.allowStairs, isFalse);
    expect(store.allowElevators, isFalse);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pumpAndSettle();
    await store.initialize();
    await openMap();
    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();

    expect(
      tester.widget<FilterChip>(avoidStairs).selected,
      isTrue,
    );
    expect(
      tester.widget<FilterChip>(avoidElevators).selected,
      isTrue,
    );
    expect(warning, findsOneWidget);

    await tester
        .ensureVisible(find.byKey(const ValueKey('reset-route-preferences')));
    await tester.tap(find.byKey(const ValueKey('reset-route-preferences')));
    await tester.pumpAndSettle();

    expect(tester.widget<FilterChip>(avoidStairs).selected, isFalse);
    expect(tester.widget<FilterChip>(avoidElevators).selected, isFalse);
    expect(
      find.textContaining('لا يتوفر مسار يطابق تفضيلات الحركة'),
      findsNothing,
    );
    expect(find.textContaining('انتقل عبر المصعد'), findsOneWidget);
    expect(store.allowStairs, isTrue);
    expect(store.allowElevators, isTrue);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pumpAndSettle();
    await store.initialize();
    await openMap();
    await tester.tap(find.byKey(const ValueKey('advanced-map-options')));
    await tester.pumpAndSettle();
    expect(tester.widget<FilterChip>(avoidStairs).selected, isFalse);
    expect(tester.widget<FilterChip>(avoidElevators).selected, isFalse);
  });

  test('illustrative routes connect destinations across all three floors', () {
    final router = HospitalRouteService();
    const startId = 'MAIN_ENTRANCE';

    for (final floor in hospitalFloorPlans) {
      for (final destination in floor.selectablePlaces) {
        final route = router.findRoute(
          startLocationId: startId,
          destinationLocationId: destination.mapLocationId ?? destination.id,
        );
        expect(
          route,
          isNotNull,
          reason: '${floor.id}: ${destination.id} should be connected',
        );
        expect(route!.places.first.mapLocationId, startId);
        expect(route.places.last.id, destination.id);
        for (var index = 1; index < route.places.length; index++) {
          final previous = route.places[index - 1];
          final current = route.places[index];
          if (previous.floorId != current.floorId) {
            expect(
              [FloorPlaceCategory.elevator, FloorPlaceCategory.stairs],
              contains(previous.category),
            );
            expect(
              [FloorPlaceCategory.elevator, FloorPlaceCategory.stairs],
              contains(current.category),
            );
          } else {
            expect(
              previous.connections.contains(current.id) ||
                  current.connections.contains(previous.id),
              isTrue,
              reason: '${previous.id} -> ${current.id} must use a graph edge',
            );
          }
        }
      }
    }

    final crossFloorRoute = router.findRoute(
      startLocationId: startId,
      destinationLocationId: 'EYE_CLINIC',
    )!;
    expect(crossFloorRoute.floorTransitions, hasLength(1));
    expect(
      crossFloorRoute.floorTransitions.first.from.category,
      FloorPlaceCategory.elevator,
    );
  });

  test('same-floor routes work on ground, first, and second floors', () {
    final router = HospitalRouteService();
    const cases = [
      (start: 'G_RECEPTION', destination: 'G_PHARMACY', floor: 'GROUND'),
      (start: 'F_OPHTHALMOLOGY', destination: 'F_DERMATOLOGY', floor: 'FIRST'),
      (start: 'S_INPATIENT', destination: 'S_SURGERY', floor: 'SECOND'),
    ];

    for (final item in cases) {
      final route = router.findRoute(
        startLocationId: item.start,
        destinationLocationId: item.destination,
      );
      expect(route, isNotNull, reason: '${item.floor} needs a connected route');
      expect(route!.places.first.floorId, item.floor);
      expect(route.places.last.floorId, item.floor);
      expect(route.floorTransitions, isEmpty);
    }
  });

  test('route service rejects duplicate place IDs before selecting a floor',
      () {
    const duplicateId = 'DUPLICATE_PLACE';
    const targetId = 'FIRST_FLOOR_TARGET';
    const groundDuplicate = FloorPlanPlace(
      id: duplicateId,
      floorId: 'GROUND',
      nameAr: 'مدخل الدور الأرضي',
      category: FloorPlaceCategory.entrance,
      descriptionAr: 'مدخل تجريبي',
      x: .2,
      y: .2,
    );
    const firstFloorDuplicate = FloorPlanPlace(
      id: duplicateId,
      floorId: 'FIRST',
      nameAr: 'مدخل الدور الأول',
      category: FloorPlaceCategory.entrance,
      descriptionAr: 'مدخل تجريبي',
      x: .3,
      y: .3,
    );
    const firstFloorTarget = FloorPlanPlace(
      id: targetId,
      floorId: 'FIRST',
      nameAr: 'الوجهة',
      category: FloorPlaceCategory.department,
      descriptionAr: 'وجهة تجريبية',
      x: .8,
      y: .8,
    );
    final floors = [
      const HospitalFloorPlan(
        id: 'GROUND',
        level: 0,
        nameAr: 'الأرضي',
        places: [groundDuplicate],
      ),
      const HospitalFloorPlan(
        id: 'FIRST',
        level: 1,
        nameAr: 'الأول',
        places: [firstFloorDuplicate, firstFloorTarget],
        connections: [
          FloorPlanConnection(
            fromId: duplicateId,
            toId: targetId,
            type: FloorPlanConnectionType.doorway,
          ),
        ],
      ),
    ];

    expect(
      () => HospitalRouteService(floors: floors).findRoute(
        startLocationId: duplicateId,
        destinationLocationId: targetId,
      ),
      throwsA(
        isA<StateError>().having(
          (error) => error.message,
          'message',
          allOf(
            contains(duplicateId),
            contains('GROUND'),
            contains('FIRST'),
          ),
        ),
      ),
      reason:
          'Without validation the ID index would start this route on FIRST.',
    );
  });

  test('routes use authored edges and never infer vertical links', () {
    expect(hospitalFloorPlanSource,
        'assets/floor_plans/riwaq_conceptual_floor_plans.pdf');
    final placeIds = {
      for (final floor in hospitalFloorPlans)
        for (final place in floor.places) place.id,
    };
    for (final floor in hospitalFloorPlans) {
      expect(floor.isSimulated, isTrue);
      expect(floor.assetPath, isNotNull);
      expect(floor.connections, isNotEmpty);
      for (final edge in floor.connections) {
        expect(placeIds, contains(edge.fromId));
        expect(placeIds, contains(edge.toId));
        final from = hospitalFloorPlans
            .expand((f) => f.places)
            .firstWhere((p) => p.id == edge.fromId);
        final to = hospitalFloorPlans
            .expand((f) => f.places)
            .firstWhere((p) => p.id == edge.toId);
        expect(
          edge.type == FloorPlanConnectionType.vertical,
          from.floorId != to.floorId,
          reason: '${edge.fromId} -> ${edge.toId} must be explicitly typed',
        );
      }
    }

    final router = HospitalRouteService();
    final withinFloor = router.findRoute(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'G_PHARMACY',
    )!;
    expect(withinFloor.isSimulated, isTrue);
    expect(withinFloor.floorTransitions, isEmpty);

    final crossFloor = router.findRoute(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'S_SURGERY',
    )!;
    expect(crossFloor.floorTransitions, hasLength(2));
    for (final transition in crossFloor.floorTransitions) {
      expect(
        hospitalFloorPlans.expand((floor) => floor.connections).any((edge) =>
            edge.type == FloorPlanConnectionType.vertical &&
            ((edge.fromId == transition.from.id &&
                    edge.toId == transition.to.id) ||
                (edge.toId == transition.from.id &&
                    edge.fromId == transition.to.id))),
        isTrue,
      );
    }

    final floorsWithoutVerticalEdges = [
      for (final floor in hospitalFloorPlans)
        HospitalFloorPlan(
          id: floor.id,
          level: floor.level,
          nameAr: floor.nameAr,
          places: floor.places,
          corridors: floor.corridors,
          assetPath: floor.assetPath,
          isSimulated: floor.isSimulated,
          connections: [
            for (final edge in floor.connections)
              if (edge.type != FloorPlanConnectionType.vertical) edge,
          ],
        ),
    ];
    expect(
      HospitalRouteService(floors: floorsWithoutVerticalEdges).findRoute(
        startLocationId: 'G_MAIN_ENTRANCE',
        destinationLocationId: 'EYE_CLINIC',
      ),
      isNull,
      reason: 'verticalConnectionId metadata must not create route edges',
    );

    final floorsWithoutLifts = [
      for (final floor in hospitalFloorPlans)
        HospitalFloorPlan(
          id: floor.id,
          level: floor.level,
          nameAr: floor.nameAr,
          places: floor.places,
          corridors: floor.corridors,
          assetPath: floor.assetPath,
          isSimulated: floor.isSimulated,
          connections: [
            for (final edge in floor.connections)
              if (!edge.fromId.contains('ELEVATOR') &&
                  !edge.toId.contains('ELEVATOR'))
                edge,
          ],
        ),
    ];
    final stairsRoute = HospitalRouteService(floors: floorsWithoutLifts)
        .findRoute(
            startLocationId: 'G_MAIN_ENTRANCE',
            destinationLocationId: 'EYE_CLINIC');
    expect(stairsRoute, isNotNull);
    expect(stairsRoute!.floorTransitions.first.from.category,
        FloorPlaceCategory.stairs);
  });

  test('authored vertical links join adjacent matching stair or lift nodes',
      () {
    final floorsById = {
      for (final floor in hospitalFloorPlans) floor.id: floor
    };
    final placesById = {
      for (final floor in hospitalFloorPlans)
        for (final place in floor.places) place.id: place,
    };
    const supportedCategories = {
      FloorPlaceCategory.stairs,
      FloorPlaceCategory.elevator,
    };
    var verticalLinkCount = 0;

    for (final floor in hospitalFloorPlans) {
      for (final edge in floor.connections) {
        if (edge.type != FloorPlanConnectionType.vertical) continue;
        verticalLinkCount++;

        final from = placesById[edge.fromId];
        final to = placesById[edge.toId];
        expect(from, isNotNull, reason: 'Unknown endpoint ${edge.fromId}');
        expect(to, isNotNull, reason: 'Unknown endpoint ${edge.toId}');
        expect(
          from!.floorId,
          isNot(to!.floorId),
          reason: '${edge.fromId} -> ${edge.toId} must cross floors',
        );
        final fromLevel = floorsById[from.floorId]?.level;
        final toLevel = floorsById[to.floorId]?.level;
        expect(fromLevel, isNotNull, reason: 'Unknown floor ${from.floorId}');
        expect(toLevel, isNotNull, reason: 'Unknown floor ${to.floorId}');
        expect(
          (fromLevel! - toLevel!).abs(),
          1,
          reason: '${edge.fromId} -> ${edge.toId} must join adjacent levels',
        );
        expect(
          from.category,
          to.category,
          reason: '${edge.fromId} -> ${edge.toId} must use matching endpoints',
        );
        expect(
          supportedCategories,
          contains(from.category),
          reason:
              '${edge.fromId} -> ${edge.toId} must connect stairs or elevators',
        );
      }
    }

    expect(verticalLinkCount, greaterThan(0));
  });

  test('route service clearly rejects malformed vertical links', () {
    final ground =
        hospitalFloorPlans.firstWhere((floor) => floor.id == 'GROUND');
    final first = hospitalFloorPlans.firstWhere((floor) => floor.id == 'FIRST');
    final invalidLinks = [
      (
        from: 'GROUND_COMMON_ELEVATOR',
        to: 'SECOND_COMMON_ELEVATOR',
        reason: 'non-adjacent floors',
      ),
      (
        from: 'GROUND_COMMON_ELEVATOR',
        to: 'FIRST_COMMON_STAIRCASE',
        reason: 'different endpoint categories',
      ),
      (
        from: 'GROUND_COMMON_ELEVATOR',
        to: first.places
            .firstWhere(
                (place) => place.category == FloorPlaceCategory.corridor)
            .id,
        reason: 'unsupported endpoint category',
      ),
      (
        from: 'GROUND_COMMON_ELEVATOR',
        to: 'GROUND_COMMON_STAIRCASE',
        reason: 'same-floor endpoints',
      ),
    ];

    for (final invalidLink in invalidLinks) {
      final floors = [
        for (final floor in hospitalFloorPlans)
          HospitalFloorPlan(
            id: floor.id,
            level: floor.level,
            nameAr: floor.nameAr,
            places: floor.places,
            corridors: floor.corridors,
            assetPath: floor.assetPath,
            isSimulated: floor.isSimulated,
            connections: [
              ...floor.connections,
              if (floor.id == ground.id)
                FloorPlanConnection(
                  fromId: invalidLink.from,
                  toId: invalidLink.to,
                  type: FloorPlanConnectionType.vertical,
                ),
            ],
          ),
      ];

      expect(
        () => HospitalRouteService(floors: floors).findRoute(
          startLocationId: 'G_MAIN_ENTRANCE',
          destinationLocationId: 'EYE_CLINIC',
        ),
        throwsA(
          isA<StateError>().having(
            (error) => error.message,
            'message',
            allOf(
              contains('Invalid vertical route edge'),
              contains(invalidLink.from),
              contains(invalidLink.to),
            ),
          ),
        ),
        reason: 'The route service must reject ${invalidLink.reason}',
      );
    }
  });

  test('route service clearly rejects malformed non-vertical links', () {
    final ground =
        hospitalFloorPlans.firstWhere((floor) => floor.id == 'GROUND');
    final first = hospitalFloorPlans.firstWhere((floor) => floor.id == 'FIRST');
    final groundCorridor = ground.places
        .firstWhere((place) => place.category == FloorPlaceCategory.corridor);
    final firstElevator = first.places
        .firstWhere((place) => place.category == FloorPlaceCategory.elevator);
    final invalidLinks = [
      (
        from: 'GROUND_COMMON_ELEVATOR',
        to: firstElevator.id,
        type: FloorPlanConnectionType.doorway,
        error: 'Non-vertical route edge',
        reason: 'non-vertical cross-floor link',
      ),
      (
        from: 'G_MAIN_ENTRANCE',
        to: groundCorridor.id,
        type: FloorPlanConnectionType.corridor,
        error: 'Corridor edge',
        reason: 'corridor link with a non-corridor endpoint',
      ),
      (
        from: 'G_MAIN_ENTRANCE',
        to: 'MISSING_ROUTE_PLACE',
        type: FloorPlanConnectionType.doorway,
        error: 'Route edge',
        reason: 'link to an unknown place',
      ),
    ];

    for (final invalidLink in invalidLinks) {
      final floors = [
        for (final floor in hospitalFloorPlans)
          HospitalFloorPlan(
            id: floor.id,
            level: floor.level,
            nameAr: floor.nameAr,
            places: floor.places,
            corridors: floor.corridors,
            assetPath: floor.assetPath,
            isSimulated: floor.isSimulated,
            connections: [
              ...floor.connections,
              if (floor.id == ground.id)
                FloorPlanConnection(
                  fromId: invalidLink.from,
                  toId: invalidLink.to,
                  type: invalidLink.type,
                ),
            ],
          ),
      ];

      expect(
        () => HospitalRouteService(floors: floors).findRoute(
          startLocationId: 'G_MAIN_ENTRANCE',
          destinationLocationId: 'EYE_CLINIC',
        ),
        throwsA(
          isA<StateError>().having(
            (error) => error.message,
            'message',
            allOf(
              contains(invalidLink.error),
              contains(invalidLink.from),
              contains(invalidLink.to),
            ),
          ),
        ),
        reason: 'The route service must reject ${invalidLink.reason}',
      );
    }
  });

  test('route search distinguishes unknown, disconnected, and blocked paths',
      () {
    final router = HospitalRouteService();
    final unknownStart = router.findRouteResult(
      startLocationId: 'UNKNOWN_PLACE',
      destinationLocationId: 'EYE_CLINIC',
    );
    expect(unknownStart.route, isNull);
    expect(unknownStart.failureReason, RouteFailureReason.unknownLocation);

    final unknownDestination = router.findRouteResult(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'UNKNOWN_PLACE',
    );
    expect(unknownDestination.route, isNull);
    expect(
        unknownDestination.failureReason, RouteFailureReason.unknownLocation);

    const floorPairs = [
      (from: 'G_MAIN_ENTRANCE', to: 'EYE_CLINIC', label: 'GROUND to FIRST'),
      (from: 'EYE_CLINIC', to: 'S_INPATIENT', label: 'FIRST to SECOND'),
      (from: 'G_MAIN_ENTRANCE', to: 'S_INPATIENT', label: 'GROUND to SECOND'),
    ];
    const preferencesByCategory = [
      (
        category: FloorPlaceCategory.stairs,
        preferences: MobilityRoutePreferences(allowElevators: false),
      ),
      (
        category: FloorPlaceCategory.elevator,
        preferences: MobilityRoutePreferences(allowStairs: false),
      ),
    ];

    for (final pair in floorPairs) {
      for (final option in preferencesByCategory) {
        final route = router.findRoute(
          startLocationId: pair.from,
          destinationLocationId: pair.to,
          preferences: option.preferences,
        );
        expect(route, isNotNull,
            reason:
                '${pair.label} should have a ${option.category.name}-only route');
        expect(route!.floorTransitions, isNotEmpty,
            reason: '${pair.label} must cross at least one floor');
        for (final transition in route.floorTransitions) {
          expect(
            transition.from.category,
            option.category,
            reason:
                '${pair.label} must use only ${option.category.name} transitions',
          );
          expect(transition.to.category, option.category);
        }
      }
    }

    final preferenceBlocked = router.findRouteResult(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'EYE_CLINIC',
      preferences: const MobilityRoutePreferences(
        allowStairs: false,
        allowElevators: false,
      ),
    );
    expect(preferenceBlocked.route, isNull);
    expect(preferenceBlocked.failureReason,
        RouteFailureReason.excludedByMobilityPreferences);

    final floorsWithoutVerticalEdges = [
      for (final floor in hospitalFloorPlans)
        HospitalFloorPlan(
          id: floor.id,
          level: floor.level,
          nameAr: floor.nameAr,
          places: floor.places,
          corridors: floor.corridors,
          assetPath: floor.assetPath,
          isSimulated: floor.isSimulated,
          connections: [
            for (final edge in floor.connections)
              if (edge.type != FloorPlanConnectionType.vertical) edge,
          ],
        ),
    ];
    final disconnected =
        HospitalRouteService(floors: floorsWithoutVerticalEdges)
            .findRouteResult(
      startLocationId: 'G_MAIN_ENTRANCE',
      destinationLocationId: 'EYE_CLINIC',
    );
    expect(disconnected.route, isNull);
    expect(disconnected.failureReason, RouteFailureReason.noConnectedPath);
  });

  testWidgets('home quick-access cards adapt to narrow and wide screens',
      (tester) async {
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    for (final size in [const Size(320, 800), const Size(1024, 900)]) {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      await tester.pumpWidget(const RiwaqApp());
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull, reason: 'Viewport $size');
      expect(find.text('الخدمات السريعة'), findsOneWidget);
      await tester.scrollUntilVisible(
        find.text('وصول سريع'),
        160,
        scrollable: find.byType(Scrollable).first,
      );
      expect(find.text('وصول سريع'), findsOneWidget);
    }
  });

  test('Arabic variations resolve to the same eye specialty', () {
    final classifier = IntentClassifier();
    for (final text in ['أحتاج طبيب عيون', 'أعاني من مشكلة في النظر']) {
      final result = classifier.classify(text);
      expect(result.intent, AssistantIntent.specialtySearch);
      expect(result.specialtyId, 'OPHTHALMOLOGY');
      expect(result.destinationId, 'EYE_CLINIC');
    }
    for (final text in ['وين عيادة العيون؟', 'أبغى أروح لقسم العيون']) {
      final result = classifier.classify(
        text,
        currentLocationId: 'RECEPTION',
      );
      expect(result.intent, AssistantIntent.departmentNavigation);
      expect(result.destinationId, 'EYE_CLINIC');
    }
  });

  test('Dental, appointments, unclear, and emergency intents are classified',
      () {
    final classifier = IntentClassifier();
    expect(classifier.classify('أبحث عن طبيب أسنان').specialtyId, 'DENTISTRY');
    expect(
        classifier.classify('عندي حكة وطفح جلدي').specialtyId, 'DERMATOLOGY');
    expect(classifier.classify('أحتاج طبيب عيون').doctorIds, ['DOC_EYE_01']);
    expect(classifier.classify('ما مواعيدي؟').intent,
        AssistantIntent.appointmentInquiry);
    expect(classifier.classify('شيء غريب').intent, AssistantIntent.unclear);
    expect(classifier.classify('حالة طوارئ').intent, AssistantIntent.emergency);
  });

  test('urgent Arabic symptom variations always take emergency priority', () {
    final classifier = IntentClassifier();
    const emergencyPhrases = [
      'عندي ألم شديد في الصدر',
      'صدري يعورني وما أقدر أتنفس',
      'أحس بضيق في التنفس',
      'عندي صعوبة في التنفس',
      'أحس أني باختنق',
      'عندي ألم في الصدر مع دوخة',
      'شخص فقد الوعي',
      'شخص لا يتنفس',
    ];

    for (final phrase in emergencyPhrases) {
      final result = classifier.classify(phrase);
      expect(result.intent, AssistantIntent.emergency, reason: phrase);
      expect(result.actions, ['call_emergency'], reason: phrase);
      expect(result.specialtyId, isNull, reason: phrase);
      expect(result.destinationId, isNull, reason: phrase);
      expect(result.message, contains('997'), reason: phrase);
    }
  });

  test('emergency symptoms override appointment and destination requests', () {
    final result = IntentClassifier()
        .classify('عندي ألم شديد في الصدر، أبي موعد ووين أروح؟');
    expect(result.intent, AssistantIntent.emergency);
    expect(result.actions, ['call_emergency']);
    expect(result.message, contains('حالة طارئة'));
  });

  test(
      'ordinary healthcare and breathing questions are not misclassified as emergencies',
      () {
    final classifier = IntentClassifier();
    expect(classifier.classify('وين عيادة العيون؟').intent,
        AssistantIntent.departmentNavigation);
    expect(classifier.classify('أحتاج موعد لفحص الصدر').intent,
        AssistantIntent.appointmentInquiry);
    expect(classifier.classify('كيف أتمرن على التنفس؟').intent,
        AssistantIntent.healthInformation);
    expect(classifier.classify('عندي ألم خفيف في الركبة').intent,
        AssistantIntent.specialtySearch);
    expect(classifier.classify('ألم خفيف في الصدر').intent,
        AssistantIntent.specialtySearch);
  });

  test(
      'assistant recognizes every registered facility and maps it to its shared location',
      () {
    final classifier = IntentClassifier();
    final examples = <String, String>{
      'وين الصيدلية؟': 'PHARMACY',
      'أبغى أشتري دواء، وين أروح؟': 'PHARMACY',
      'هل فيه صيدلية في المستشفى؟': 'PHARMACY',
      'كيف أوصل للمختبر؟': 'LABORATORY',
      'وين أسوي التحاليل؟': 'LABORATORY',
      'وين قسم الأشعة؟': 'RADIOLOGY',
      'وين الاستقبال؟': 'RECEPTION',
      'وين الطوارئ؟': 'EMERGENCY',
      'وين المدخل الرئيسي؟': 'MAIN_ENTRANCE',
      'كيف أوصل لعيادة العيون؟': 'EYE_CLINIC',
    };
    for (final entry in examples.entries) {
      final response = classifier.classify(
        entry.key,
        currentLocationId: 'MAIN_ENTRANCE',
      );
      expect(response.destinationId, entry.value, reason: entry.key);
      expect(response.actions, contains('open_map'), reason: entry.key);
      expect(response.intent, isNot(AssistantIntent.emergency),
          reason: entry.key);
    }
    expect(
      classifier
          .classify(
            'كيف أوصل لعيادة العيون؟',
            currentLocationId: 'MAIN_ENTRANCE',
          )
          .intent,
      AssistantIntent.departmentNavigation,
    );
    expect(classifier.classify('وين الصيدلية؟').intent,
        AssistantIntent.facilitySearch);
    expect(
        const LocationRepository()
            .getAll()
            .map((location) => location.id)
            .toSet(),
        containsAll(examples.values.toSet()));
  });

  test('assistant remembers the last destination for follow-up questions',
      () async {
    final assistant = AiService();
    final first = await assistant.respond('وين الصيدلية؟');
    final followUp =
        await assistant.respond('طيب كيف أوصل لها من الاستقبال؟');

    expect(first.destinationId, 'PHARMACY');
    expect(followUp.intent, AssistantIntent.facilitySearch);
    expect(followUp.destinationId, 'PHARMACY');
    expect(followUp.message, contains('الصيدلية'));
    expect(followUp.actions, contains('open_map'));
  });

  test(
      'repeated facility questions vary the phrasing without changing the answer',
      () async {
    final assistant = AiService();
    final first = await assistant.respond('وين الصيدلية؟');
    final second = await assistant.respond('وين الصيدلية؟');

    expect(first.destinationId, 'PHARMACY');
    expect(second.destinationId, 'PHARMACY');
    expect(second.message, isNot(first.message));
  });

  test(
      'visual matching processes image data but refuses a location without references',
      () async {
    final sample = image_lib.Image(width: 16, height: 16);
    final png = Uint8List.fromList(image_lib.encodePng(sample));
    final recognizer = VisualLandmarkRecognizer(references: const []);
    final result = await recognizer.recognizeBytes(png);

    expect(VisualLandmarkRecognizer.describe(sample), hasLength(280));
    expect(
        VisualLandmarkRecognizer.similarity(
          VisualLandmarkRecognizer.describe(sample),
          VisualLandmarkRecognizer.describe(sample),
        ),
        1);
    expect(result.status, VisualRecognitionStatus.noReferenceData);
    expect(result.locationId, isNull);
  });
}
