import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/data/aruco_landmarks.dart';
import 'package:riwaq/data/repositories/location_repository.dart';
import 'package:riwaq/services/location_state.dart';
import 'package:riwaq/services/vision/aruco_landmark_recognizer.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('all sample ArUco IDs point to registered conceptual map nodes', () {
    const repository = LocationRepository();
    for (final marker in arucoLandmarks) {
      expect(repository.byId(marker.locationId), isNotNull);
    }
  });

  test('known marker updates location only after quality thresholds pass', () {
    final state = RiwaqLocationState.instance;
    state.setCurrent(locationId: 'RECEPTION', floor: 0);

    final weak = ArucoLandmarkRecognizer.evaluate([
      const ArucoMarkerObservation(
        markerId: 0,
        qualityScore: 0.42,
        areaRatio: 0.015,
        shortestEdgePx: 54,
        accepted: false,
      ),
    ]);
    expect(weak.status, ArucoRecognitionStatus.lowQuality);
    expect(
      applyArucoRecognitionToLocation(
        result: weak,
        repository: const LocationRepository(),
        locationState: state,
      ),
      isFalse,
    );
    expect(state.currentLocationId, 'RECEPTION');
    expect(state.currentLocationSource, RiwaqLocationSource.simulated);

    final accepted = ArucoLandmarkRecognizer.evaluate([
      const ArucoMarkerObservation(
        markerId: 0,
        qualityScore: 0.91,
        areaRatio: 0.08,
        shortestEdgePx: 160,
        accepted: true,
      ),
    ]);
    expect(accepted.status, ArucoRecognitionStatus.recognized);
    expect(accepted.locationId, 'MAIN_ENTRANCE');
    expect(
      applyArucoRecognitionToLocation(
        result: accepted,
        repository: const LocationRepository(),
        locationState: state,
      ),
      isTrue,
    );
    expect(state.currentLocationId, 'MAIN_ENTRANCE');
    expect(state.currentLocationSource, RiwaqLocationSource.visualMarker);
  });

  test('unknown marker never changes the current indoor node', () {
    final state = RiwaqLocationState.instance;
    state.setCurrent(locationId: 'RADIOLOGY', floor: 0);

    final result = ArucoLandmarkRecognizer.evaluate([
      const ArucoMarkerObservation(
        markerId: 48,
        qualityScore: 0.94,
        areaRatio: 0.09,
        shortestEdgePx: 190,
        accepted: true,
      ),
    ]);
    expect(result.status, ArucoRecognitionStatus.unknownMarker);
    expect(
      applyArucoRecognitionToLocation(
        result: result,
        repository: const LocationRepository(),
        locationState: state,
      ),
      isFalse,
    );
    expect(state.currentLocationId, 'RADIOLOGY');
  });

  test('no detections are reported without changing location', () {
    expect(
      ArucoLandmarkRecognizer.evaluate(const []).status,
      ArucoRecognitionStatus.noMarker,
    );
  });

  test('recognizer parses local native detections', () async {
    const channel = MethodChannel('test/riwaq_aruco');
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(channel, (call) async {
      expect(call.method, 'detectArucoMarkers');
      expect(call.arguments, isA<Map<Object?, Object?>>());
      return [
        {
          'markerId': 2,
          'qualityScore': 0.89,
          'areaRatio': 0.06,
          'shortestEdgePx': 140.0,
          'accepted': true,
        },
      ];
    });
    addTearDown(() => messenger.setMockMethodCallHandler(channel, null));

    final result = await ArucoLandmarkRecognizer(channel: channel)
        .recognizeBytes(Uint8List.fromList([1, 2, 3]));
    expect(result.status, ArucoRecognitionStatus.recognized);
    expect(result.markerId, 2);
    expect(result.locationId, 'RADIOLOGY');
  });
}
