import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/data/hospital_floor_plan_data.dart';
import 'package:riwaq/data/localization_landmarks.dart';
import 'package:riwaq/data/location_data.dart';
import 'package:riwaq/models/architectural_model.dart';
import 'package:riwaq/models/hospital_floor_plan.dart';
import 'package:riwaq/models/indoor_localization.dart';
import 'package:riwaq/services/location_provider.dart';
import 'package:riwaq/services/hospital_route_service.dart';
import 'package:riwaq/widgets/hospital_model_3d.dart';
import 'package:riwaq/app.dart';
import 'package:riwaq/services/location_state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('required departments and every-floor facilities share one registry',
      () {
    const expected = {
      'GROUND': [
        'G_RECEPTION',
        'G_EMERGENCY',
        'G_PHARMACY',
        'G_RADIOLOGY',
        'G_LABORATORY',
        'G_ADMINISTRATION',
        'G_GARDEN',
        'G_MAIN_ENTRANCE'
      ],
      'FIRST': [
        'F_OPHTHALMOLOGY',
        'F_DENTAL',
        'F_INTERNAL_MEDICINE',
        'F_DERMATOLOGY',
        'F_CAFETERIA'
      ],
      'SECOND': ['S_INPATIENT', 'S_OBSTETRICS', 'S_SURGERY', 'S_NURSERY'],
    };
    for (final f in hospitalFloorPlans) {
      expect(f.places.map((p) => p.id), containsAll(expected[f.id]!));
      for (final category in [
        FloorPlaceCategory.restroom,
        FloorPlaceCategory.prayerRoom,
        FloorPlaceCategory.elevator,
        FloorPlaceCategory.stairs,
        FloorPlaceCategory.emergencyExit,
        FloorPlaceCategory.waitingArea
      ]) {
        expect(f.selectablePlaces.any((p) => p.category == category), isTrue);
      }
      final lift =
          f.places.firstWhere((p) => p.category == FloorPlaceCategory.elevator);
      expect(lift.bounds!.left, .06);
      expect(lift.verticalConnectionId, 'CORE_LIFT');
    }
    expect(virtualLocations.firstWhere((p) => p.id == 'RADIOLOGY').floor, 0);
    expect(virtualLocations.map((p) => p.id).toSet(),
        hasLength(virtualLocations.length));
    expect(findHospitalPlace('RADIOLOGY')!.id, 'G_RADIOLOGY');
  });

  test('corridor edges are orthogonal and never cut through room interiors',
      () {
    for (final floor in hospitalFloorPlans) {
      final byId = {for (final p in floor.places) p.id: p};
      for (final p in floor.places) {
        for (final targetId in p.connections) {
          final q = byId[targetId]!;
          expect((p.x - q.x).abs() < 1e-9 || (p.y - q.y).abs() < 1e-9, isTrue,
              reason: '${p.id} -> ${q.id} must be orthogonal');
          for (var step = 1; step < 10; step++) {
            final t = step / 10;
            final x = p.x + (q.x - p.x) * t, y = p.y + (q.y - p.y) * t;
            for (final room in floor.selectablePlaces
                .where((r) => r.bounds != null && r.zone != PlanZone.outdoor)) {
              final r = room.bounds!;
              final inside = x > r.left + 1e-7 &&
                  x < r.right - 1e-7 &&
                  y > r.top + 1e-7 &&
                  y < r.bottom - 1e-7;
              expect(inside, isFalse,
                  reason: '${p.id} -> ${q.id} crosses ${room.id}');
            }
          }
        }
      }
    }
    expect(
        HospitalRouteService().findRoute(
            startLocationId: 'not-a-node', destinationLocationId: 'EYE_CLINIC'),
        isNull);
  });

  test('generated GLB meshes match all shared room IDs and bounds', () async {
    final model = ArchitecturalModel.fromGlb(
        await rootBundle.load('assets/hospital/riwaq_hospital.glb'));
    final roomParts = model.parts.where((p) => p.kind == 'room').toList();
    final rooms = [
      for (final f in hospitalFloorPlans)
        ...f.selectablePlaces.where((p) => p.bounds != null)
    ];
    expect(roomParts.map((p) => p.placeId).toSet(),
        rooms.map((p) => p.id).toSet());
    expect(model.parts.where((p) => p.kind == 'slab'), hasLength(3));
    for (final room in rooms) {
      final part = roomParts.singleWhere((p) => p.placeId == room.id);
      expect(part.floorId, room.floorId);
      final minX = part.vertices.map((v) => v.x).reduce(math.min);
      final maxX = part.vertices.map((v) => v.x).reduce(math.max);
      final minZ = part.vertices.map((v) => v.z).reduce(math.min);
      expect(minX, closeTo((room.bounds!.left - .5) * 10, 1e-7));
      expect(maxX, closeTo((room.bounds!.right - .5) * 10, 1e-7));
      expect(minZ, closeTo((room.bounds!.top - .5) * 10, 1e-7));
    }
    for (final size in [const Size(350, 500), const Size(1100, 500)]) {
      for (final view in BuildingView.values) {
        final projection = HospitalSceneProjection(
            model, size, -.4, .82, 1, view, hospitalFloorPlans[1], null);
        for (final part in model.parts) {
          if (view == BuildingView.floor && part.floorId != 'FIRST') continue;
          for (final v in part.vertices) {
            final p =
                projection.project(projection.adjust(v, part.level)).point;
            expect(p.dx, inInclusiveRange(23.99, size.width - 23.99));
            expect(p.dy, inInclusiveRange(31.99, size.height - 31.99));
          }
        }
      }
    }
  });

  test('future localization validates IDs, floors, score and timestamp',
      () async {
    final provider = PredictionLocalizationProvider();
    final now = DateTime.now();
    IndoorLocationPrediction prediction(
            {String floor = 'FIRST',
            double confidence = .95,
            DateTime? timestamp,
            String? landmark = 'LM_F_OPHTHALMOLOGY_ENTRY'}) =>
        IndoorLocationPrediction(
            locationId: 'F_OPHTHALMOLOGY',
            floorId: floor,
            confidence: confidence,
            timestamp: timestamp ?? now,
            providerId: 'future-test-adapter',
            landmarkId: landmark);
    expect(localizationLandmarks.map((l) => l.id).toSet(),
        hasLength(localizationLandmarks.length));
    expect(provider.receive(prediction(floor: 'GROUND'), now: now), isFalse);
    expect(provider.receive(prediction(confidence: .4), now: now), isFalse);
    expect(
        provider.receive(
            prediction(timestamp: now.subtract(const Duration(minutes: 1))),
            now: now),
        isFalse);
    expect(provider.receive(prediction(landmark: 'unregistered'), now: now),
        isFalse);
    expect(provider.receive(prediction(), now: now), isTrue);
    expect((await provider.requestLocation())!.locationId, 'F_OPHTHALMOLOGY');
    expect(await UnavailableIndoorLocationProvider().requestLocation(), isNull);
  });

  testWidgets('3D GLB rotates, zooms, resets, switches view and picks a room',
      (tester) async {
    tester.view.physicalSize = const Size(850, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    FloorPlanPlace? picked;
    await tester.pumpWidget(MaterialApp(
        home: Scaffold(
            body: SingleChildScrollView(
      child: HospitalModel3D(
        floor: hospitalFloorPlans[1],
        destinationId: 'F_OPHTHALMOLOGY',
        startId: 'G_MAIN_ENTRANCE',
        route: HospitalRouteService().findRoute(
            startLocationId: 'MAIN_ENTRANCE',
            destinationLocationId: 'EYE_CLINIC'),
        onSelect: (p) => picked = p,
        onFloorSelect: (_) {},
      ),
    ))));
    await tester.pumpAndSettle();
    expect(find.textContaining('تعذر تحميل'), findsNothing);
    final canvas = find.byKey(const ValueKey('hospital-3d-canvas'));
    final before = tester
        .widget<Text>(find.byKey(const ValueKey('model-camera-status')))
        .data;
    await tester.drag(canvas, const Offset(85, 15));
    await tester.pumpAndSettle();
    expect(
        tester
            .widget<Text>(find.byKey(const ValueKey('model-camera-status')))
            .data,
        isNot(before));
    await tester.tap(find.byTooltip('تكبير النموذج'));
    await tester.pumpAndSettle();
    expect(find.textContaining('120٪'), findsOneWidget);
    await tester.tap(find.byTooltip('إعادة ضبط الكاميرا'));
    await tester.pumpAndSettle();
    expect(
        tester
            .widget<Text>(find.byKey(const ValueKey('model-camera-status')))
            .data,
        before);
    await tester.tap(find.text('الدور المحدد'));
    await tester.pumpAndSettle();
    final box = tester.getRect(canvas);
    final model = ArchitecturalModel.fromGlb(
        await rootBundle.load('assets/hospital/riwaq_hospital.glb'));
    final projection = HospitalSceneProjection(model, box.size, -.4, .82, 1,
        BuildingView.floor, hospitalFloorPlans[1], null);
    // Tap the actual visible room-floor centres, not a scan that can pass after
    // hitting a tiny wall while a wrongly painted slab covers most of the room.
    for (final id in ['F_OPHTHALMOLOGY', 'F_DENTAL']) {
      final bounds = findHospitalPlace(id)!.bounds!;
      final p = projection
          .project(ModelVertex((bounds.centerX - .5) * 10, .72 + .0775,
              (bounds.centerY - .5) * 10))
          .point;
      await tester.tapAt(box.topLeft + p);
      await tester.pump();
      expect(picked?.id, id);
    }
    expect(picked, isNotNull);
    expect(picked!.floorId, 'FIRST');
    await tester.tap(find.text('المبنى كاملاً'));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets(
      'mobile map search updates destination and location stays explicitly demo',
      (tester) async {
    tester.view.physicalSize = const Size(390, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(() {
      tester.view.resetPhysicalSize();
      tester.view.resetDevicePixelRatio();
    });
    RiwaqLocationState.instance
        .setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    RiwaqLocationState.instance
        .setDestination(locationId: 'EYE_CLINIC', floor: 1);
    await tester.pumpWidget(const RiwaqApp());
    await tester.tap(find.text('الخريطة'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const ValueKey('map-search')), 'الأشعة');
    await tester.pumpAndSettle();
    await tester.tap(find.byType(DropdownButtonFormField<String>));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الأشعة · الدور الأرضي').last);
    await tester.pumpAndSettle();
    expect(RiwaqLocationState.instance.destinationLocationId, 'RADIOLOGY');
    expect(RiwaqLocationState.instance.destinationFloor, 0);
    await tester.tap(find.text('اختيار نقطة البداية'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('demo-start-dropdown')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('المدخل الرئيسي · الدور الأرضي').last);
    await tester.pumpAndSettle();
    expect(find.textContaining('البداية التجريبية: المدخل الرئيسي'),
        findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
