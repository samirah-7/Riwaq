import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/l10n/riwaq_text.dart';
import 'package:riwaq/services/location_state.dart';
import 'package:riwaq/services/riwaq_local_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  final store = RiwaqLocalStore.instance;
  final locationState = RiwaqLocationState.instance;

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    await store.initialize();
  });

  test('language and dark appearance preferences persist locally', () async {
    await store.setLanguageCode('en');
    await store.setDarkMode(true);

    final preferences = await SharedPreferences.getInstance();
    expect(riwaqText('الخريطة', 'Map'), 'Map');
    expect(preferences.getString('riwaq.language'), 'en');
    expect(preferences.getBool('riwaq.darkMode'), isTrue);
  });

  test('approximate GPS never replaces the simulated indoor start', () {
    locationState.setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);

    locationState.setApproximateGps(accuracyMeters: 34.5);

    expect(locationState.currentLocationId, 'MAIN_ENTRANCE');
    expect(locationState.currentFloor, 0);
    expect(locationState.currentLocationSource,
        RiwaqLocationSource.gpsApproximate);
    expect(locationState.approximateGpsAccuracyMeters, 34.5);
  });
}
