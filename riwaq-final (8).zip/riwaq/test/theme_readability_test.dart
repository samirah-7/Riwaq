import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/theme/app_theme.dart';

void main() {
  tearDown(() => RiwaqColors.darkMode = false);

  test('light and dark text colors meet readable contrast on their surfaces',
      () {
    for (final dark in [false, true]) {
      RiwaqColors.darkMode = dark;
      final theme = dark ? AppTheme.dark : AppTheme.light;
      final surface = theme.colorScheme.surface;
      final background = theme.scaffoldBackgroundColor;

      expect(
        _contrast(theme.colorScheme.onSurface, surface),
        greaterThanOrEqualTo(4.5),
        reason: '${dark ? 'dark' : 'light'} body text on a card',
      );
      expect(
        _contrast(theme.textTheme.bodySmall!.color!, background),
        greaterThanOrEqualTo(4.5),
        reason: '${dark ? 'dark' : 'light'} secondary text on the page',
      );
      expect(
        _contrast(theme.colorScheme.onPrimary, theme.colorScheme.primary),
        greaterThanOrEqualTo(4.5),
        reason: '${dark ? 'dark' : 'light'} text on primary buttons',
      );
      expect(
        _contrast(RiwaqColors.muted, surface),
        greaterThanOrEqualTo(4.5),
        reason: '${dark ? 'dark' : 'light'} muted labels on cards',
      );
    }
  });
}

double _contrast(Color first, Color second) {
  final a = first.computeLuminance();
  final b = second.computeLuminance();
  final lighter = a > b ? a : b;
  final darker = a > b ? b : a;
  return (lighter + .05) / (darker + .05);
}
