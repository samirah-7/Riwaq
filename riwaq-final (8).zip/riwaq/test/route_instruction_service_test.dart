import 'package:flutter_test/flutter_test.dart';
import 'package:riwaq/models/hospital_floor_plan.dart';
import 'package:riwaq/models/navigation_instruction.dart';
import 'package:riwaq/services/route_instruction_service.dart';

void main() {
  FloorPlanPlace place(
    String id, {
    String floorId = 'GROUND',
    required double x,
    required double y,
    FloorPlaceCategory category = FloorPlaceCategory.corridor,
  }) =>
      FloorPlanPlace(
        id: id,
        floorId: floorId,
        nameAr: id,
        category: category,
        descriptionAr: 'اختبار',
        x: x,
        y: y,
      );

  test('instructions merge straight corridor nodes and name turns/floors', () {
    final route = HospitalRoute(
      startLocationId: 'START',
      destinationLocationId: 'DESTINATION',
      places: [
        place('START', x: .1, y: .1, category: FloorPlaceCategory.entrance),
        place('EAST', x: .3, y: .1),
        place('SOUTH', x: .3, y: .3),
        place('GROUND_LIFT',
            x: .3, y: .5, category: FloorPlaceCategory.elevator),
        place('FIRST_LIFT',
            floorId: 'FIRST',
            x: .3,
            y: .5,
            category: FloorPlaceCategory.elevator),
        place('FIRST_SOUTH', floorId: 'FIRST', x: .1, y: .5),
        place('DESTINATION',
            floorId: 'FIRST',
            x: .1,
            y: .7,
            category: FloorPlaceCategory.department),
      ],
    );

    final instructions = const RouteInstructionService().build(route);

    expect(
      instructions.map((instruction) => instruction.maneuver),
      [
        NavigationManeuver.start,
        NavigationManeuver.turnRight,
        NavigationManeuver.floorTransition,
        NavigationManeuver.start,
        NavigationManeuver.turnLeft,
      ],
    );
    expect(instructions[1].textAr, contains('انعطف يميناً'));
    expect(
        instructions[0].textEn, contains('Start from the simulated location'));
    expect(instructions[2].textAr, contains('المصعد'));
    expect(instructions[2].textAr, contains('الدور الأول'));
    expect(instructions[2].textEn, contains('Take the elevator'));
    expect(instructions.last.textAr, contains('انعطف يساراً'));
    expect(instructions.last.textAr, contains('وصل إلى DESTINATION'));
    expect(instructions.last.arrival, isTrue);
    expect(
        instructions.every(
            (instruction) => instruction.toIndex > instruction.fromIndex),
        isTrue);
  });

  test('same-place route needs no movement instructions', () {
    final destination = place('DESTINATION',
        x: .5, y: .5, category: FloorPlaceCategory.department);
    final instructions = const RouteInstructionService().build(
      HospitalRoute(
        startLocationId: destination.id,
        destinationLocationId: destination.id,
        places: [destination],
      ),
    );
    expect(instructions, isEmpty);
  });

  test('floor transition directions name stairs when that route is selected',
      () {
    final instructions = const RouteInstructionService().build(
      HospitalRoute(
        startLocationId: 'GROUND_STAIRS',
        destinationLocationId: 'FIRST_STAIRS',
        places: [
          place('GROUND_STAIRS',
              x: .2, y: .5, category: FloorPlaceCategory.stairs),
          place('FIRST_STAIRS',
              floorId: 'FIRST',
              x: .2,
              y: .5,
              category: FloorPlaceCategory.stairs),
        ],
      ),
    );

    expect(instructions, hasLength(1));
    expect(instructions.single.maneuver, NavigationManeuver.floorTransition);
    expect(instructions.single.textAr, contains('السلالم'));
    expect(instructions.single.textAr, contains('الدور الأول'));
    expect(instructions.single.textEn, contains('Take the stairs'));
  });
}
