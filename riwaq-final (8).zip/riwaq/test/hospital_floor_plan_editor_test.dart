import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:riwaq/data/hospital_floor_plan_data.dart';
import 'package:riwaq/models/hospital_floor_plan.dart';
import 'package:riwaq/services/hospital_floor_plan_editor.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    hospitalFloorPlans = defaultHospitalFloorPlans;
  });

  test('exported simulated plans validate and preserve their locations', () {
    final json = HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    );

    final imported = HospitalFloorPlanEditor.decodeAndValidate(
      json,
      base: defaultHospitalFloorPlans,
    );

    expect(imported.map((floor) => floor.id),
        defaultHospitalFloorPlans.map((floor) => floor.id));
    expect(
      imported.expand((floor) => floor.places).map((place) => place.id).toSet(),
      defaultHospitalFloorPlans
          .expand((floor) => floor.places)
          .map((place) => place.id)
          .toSet(),
    );
    expect(imported.every((floor) => floor.isSimulated), isTrue);
  });

  test('a new location and explicit same-floor edge can be imported', () {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    (ground['places'] as List).add({
      'id': 'G_TEST_ROOM',
      'floorId': 'GROUND',
      'nameAr': 'غرفة اختبار',
      'category': 'room',
      'descriptionAr': 'موقع تصوري للاختبار.',
      'x': .2,
      'y': .2,
      'mapLocationId': null,
      'zone': 'public',
      'verticalConnectionId': null,
      'keywords': ['اختبار'],
      'pathLinks': [],
    });
    (ground['edges'] as List).add({
      'fromId': 'G_TEST_ROOM',
      'toId': 'G_MAIN_ENTRANCE',
      'type': 'doorway',
    });

    final imported = HospitalFloorPlanEditor.decodeAndValidate(
      jsonEncode(document),
      base: defaultHospitalFloorPlans,
    );

    expect(
      imported
          .singleWhere((floor) => floor.id == 'GROUND')
          .places
          .any((place) => place.id == 'G_TEST_ROOM'),
      isTrue,
    );
  });

  test('missing node IDs are rejected before any save operation', () {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    ((ground['places'] as List).first as Map<String, dynamic>).remove('id');

    expect(
      () => HospitalFloorPlanEditor.decodeAndValidate(
        jsonEncode(document),
        base: defaultHospitalFloorPlans,
      ),
      throwsA(isA<FormatException>()),
    );
  });

  test('non-vertical links across floors are rejected', () {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    (ground['edges'] as List).add({
      'fromId': 'G_MAIN_ENTRANCE',
      'toId': 'F_OPHTHALMOLOGY',
      'type': 'doorway',
    });

    expect(
      () => HospitalFloorPlanEditor.decodeAndValidate(
        jsonEncode(document),
        base: defaultHospitalFloorPlans,
      ),
      throwsA(isA<FormatException>()),
    );
  });

  test('valid imports replace the active map and persist locally', () async {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    final firstPlace = (ground['places'] as List).first as Map<String, dynamic>;
    firstPlace['nameAr'] = 'اسم مستورد للاختبار';

    await HospitalFloorPlanEditor.importAndSave(jsonEncode(document));

    expect(
      hospitalFloorPlans
          .firstWhere((floor) => floor.id == 'GROUND')
          .places
          .first
          .nameAr,
      'اسم مستورد للاختبار',
    );
    final preferences = await SharedPreferences.getInstance();
    expect(
      preferences.getString('riwaq.simulatedFloorPlans.v1'),
      HospitalFloorPlanEditor.exportJson(),
    );
  });

  test(
      'saved location edits on multiple floors return after startup restoration',
      () async {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final floors = (document['floors'] as List).cast<Map<String, dynamic>>();
    final ground = floors.firstWhere((floor) => floor['id'] == 'GROUND');
    final first = floors.firstWhere((floor) => floor['id'] == 'FIRST');
    final groundPlace =
        (ground['places'] as List).first as Map<String, dynamic>;
    final firstPlace = (first['places'] as List).first as Map<String, dynamic>;
    groundPlace['nameAr'] = 'اسم الطابق الأرضي يعود بعد إعادة التشغيل';
    firstPlace['nameAr'] = 'اسم الطابق الأول يعود بعد إعادة التشغيل';

    // setUp gives this test an isolated local-preferences store.
    await HospitalFloorPlanEditor.importAndSave(jsonEncode(document));

    // A browser restart creates a fresh in-memory registry but retains local
    // preferences. Restore from that saved state just as main() does at startup.
    hospitalFloorPlans = defaultHospitalFloorPlans;
    await HospitalFloorPlanEditor.restore();

    expect(
      hospitalFloorPlans
          .firstWhere((floor) => floor.id == 'GROUND')
          .places
          .first
          .nameAr,
      'اسم الطابق الأرضي يعود بعد إعادة التشغيل',
    );
    expect(
      hospitalFloorPlans
          .firstWhere((floor) => floor.id == 'FIRST')
          .places
          .first
          .nameAr,
      'اسم الطابق الأول يعود بعد إعادة التشغيل',
    );
  });

  test('compatible saved plans migrate onto changed bundled floors', () async {
    final document = jsonDecode(HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    )) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    ((ground['places'] as List).first as Map<String, dynamic>)['nameAr'] =
        'تعديل محفوظ قبل تحديث المخطط';
    (ground['places'] as List).add({
      'id': 'G_SAVED_CUSTOM_ROOM',
      'floorId': 'GROUND',
      'nameAr': 'غرفة محفوظة مضافة',
      'category': 'room',
      'descriptionAr': 'موقع محفوظ للاختبار.',
      'x': .2,
      'y': .2,
      'mapLocationId': null,
      'zone': 'public',
      'verticalConnectionId': null,
      'keywords': [],
      'pathLinks': ['G_REMOVED_ROUTE_NODE'],
    });
    (ground['edges'] as List).add({
      'fromId': 'G_SAVED_CUSTOM_ROOM',
      'toId': 'G_REMOVED_ROUTE_NODE',
      'type': 'doorway',
    });
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      'riwaq.simulatedFloorPlans.v1',
      jsonEncode(document),
    );

    // Simulate a bundled update: remove a floor and add a new place to a
    // retained floor. The matching saved floor edit should survive.
    hospitalFloorPlans = [
      for (final floor in defaultHospitalFloorPlans)
        if (floor.id != 'SECOND')
          if (floor.id == 'GROUND')
            HospitalFloorPlan(
              id: floor.id,
              level: floor.level,
              nameAr: floor.nameAr,
              assetPath: floor.assetPath,
              corridors: floor.corridors,
              connections: floor.connections,
              places: [
                ...floor.places,
                const FloorPlanPlace(
                  id: 'G_BUNDLED_NEW_ROOM',
                  floorId: 'GROUND',
                  nameAr: 'غرفة مضافة في التحديث',
                  category: FloorPlaceCategory.room,
                  descriptionAr: 'موقع توضيحي جديد.',
                  x: .3,
                  y: .3,
                ),
              ],
            )
          else
            floor,
    ];

    await HospitalFloorPlanEditor.restore();

    final restoredGround =
        hospitalFloorPlans.singleWhere((floor) => floor.id == 'GROUND');
    expect(restoredGround.places.first.nameAr, 'تعديل محفوظ قبل تحديث المخطط');
    final restoredCustomPlace = restoredGround.places
        .singleWhere((place) => place.id == 'G_SAVED_CUSTOM_ROOM');
    expect(restoredCustomPlace.connections, isEmpty);
    expect(
      restoredGround.connections
          .any((edge) => edge.toId == 'G_REMOVED_ROUTE_NODE'),
      isFalse,
    );
    expect(
      restoredGround.places.any((place) => place.id == 'G_BUNDLED_NEW_ROOM'),
      isTrue,
    );
    expect(hospitalFloorPlans.any((floor) => floor.id == 'SECOND'), isFalse);
    expect(
      jsonDecode(
              preferences.getString('riwaq.simulatedFloorPlans.v1')!)['floors']
          .map((floor) => floor['id']),
      ['GROUND', 'FIRST'],
    );
  });

  test('unsupported saved versions fall back to bundled plans', () async {
    final bundledPlansJson = HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    );
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      'riwaq.simulatedFloorPlans.v1',
      jsonEncode({
        'schemaVersion': 999,
        'dataStatus': 'SIMULATED_UNVERIFIED',
        'floors': [
          {'id': 'GROUND', 'places': [], 'edges': []}
        ],
      }),
    );

    await expectLater(HospitalFloorPlanEditor.restore(), completes);

    expect(HospitalFloorPlanEditor.exportJson(), bundledPlansJson);
    expect(preferences.getString('riwaq.simulatedFloorPlans.v1'), isNull);
  });

  test('reset removes saved edits and restores bundled plans', () async {
    final bundledPlansJson = HospitalFloorPlanEditor.exportJson(
      floors: defaultHospitalFloorPlans,
    );
    final document = jsonDecode(bundledPlansJson) as Map<String, dynamic>;
    final ground = (document['floors'] as List)
        .cast<Map<String, dynamic>>()
        .firstWhere((floor) => floor['id'] == 'GROUND');
    final editedPlace =
        (ground['places'] as List).first as Map<String, dynamic>;
    editedPlace['nameAr'] = 'اسم يجب حذفه عند إعادة الضبط';

    await HospitalFloorPlanEditor.importAndSave(jsonEncode(document));
    await HospitalFloorPlanEditor.resetToDefaults();

    final preferences = await SharedPreferences.getInstance();
    expect(preferences.getString('riwaq.simulatedFloorPlans.v1'), isNull);
    expect(HospitalFloorPlanEditor.exportJson(), bundledPlansJson);

    // Confirm a later startup cannot bring the removed edit back.
    hospitalFloorPlans = defaultHospitalFloorPlans;
    await HospitalFloorPlanEditor.restore();
    expect(HospitalFloorPlanEditor.exportJson(), bundledPlansJson);
  });

  test('invalid imports leave the active map and local save unchanged',
      () async {
    final activeMapBeforeImport = HospitalFloorPlanEditor.exportJson();
    const invalidDocument =
        '{"schemaVersion":1,"dataStatus":"SIMULATED_UNVERIFIED","floors":[]}';

    await expectLater(
      HospitalFloorPlanEditor.importAndSave(invalidDocument),
      throwsA(isA<FormatException>()),
    );

    expect(HospitalFloorPlanEditor.exportJson(), activeMapBeforeImport);
    final preferences = await SharedPreferences.getInstance();
    expect(preferences.getString('riwaq.simulatedFloorPlans.v1'), isNull);
  });
}
