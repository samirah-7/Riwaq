package com.example.riwaq

import android.util.Log
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.opencv.android.OpenCVLoader
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.objdetect.ArucoDetector
import org.opencv.objdetect.Objdetect
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : FlutterActivity() {
    private val channelName = "riwaq/aruco"
    private var openCvLoaded: Boolean? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "detectArucoMarkers" -> {
                        val imageBytes = call.argument<ByteArray>("imageBytes")
                        if (imageBytes == null || imageBytes.isEmpty()) {
                            result.error("invalid_image", "Image bytes are required.", null)
                        } else if (imageBytes.size > 15 * 1024 * 1024) {
                            result.error("image_too_large", "Image exceeds the 15 MB limit.", null)
                        } else {
                            runOnWorker(result) {
                                detectArucoMarkers(imageBytes)
                            }
                        }
                    }

                    "generateArucoMarker" -> {
                        val markerId = call.argument<Int>("markerId")
                        val sidePixels = call.argument<Int>("sidePixels") ?: 360
                        if (markerId == null || markerId !in 0 until 50 ||
                            sidePixels !in 128..1024
                        ) {
                            result.error("invalid_marker", "Marker parameters are invalid.", null)
                        } else {
                            runOnWorker(result) {
                                generateArucoMarker(markerId, sidePixels)
                            }
                        }
                    }

                    else -> result.notImplemented()
                }
            }
    }

    private fun <T> runOnWorker(
        result: MethodChannel.Result,
        operation: () -> T
    ) {
        Thread {
            try {
                if (!ensureOpenCvLoaded()) {
                    throw IllegalStateException("OpenCV could not be initialized.")
                }
                val value = operation()
                runOnUiThread { result.success(value) }
            } catch (exception: Exception) {
                Log.e("RiwaqAruco", "OpenCV operation failed.", exception)
                runOnUiThread {
                    result.error(
                        "opencv_operation_failed",
                        "The local marker operation could not be completed.",
                        null
                    )
                }
            }
        }.start()
    }

    @Synchronized
    private fun ensureOpenCvLoaded(): Boolean {
        openCvLoaded?.let { return it }
        val loaded = OpenCVLoader.initLocal()
        openCvLoaded = loaded
        return loaded
    }

    private fun generateArucoMarker(markerId: Int, sidePixels: Int): ByteArray {
        val dictionary = Objdetect.getPredefinedDictionary(Objdetect.DICT_4X4_50)
        val marker = Mat()
        val encoded = MatOfByte()
        try {
            Objdetect.generateImageMarker(dictionary, markerId, sidePixels, marker, 1)
            if (!Imgcodecs.imencode(".png", marker, encoded)) {
                throw IllegalStateException("OpenCV could not encode the marker.")
            }
            return encoded.toArray()
        } finally {
            marker.release()
            encoded.release()
        }
    }

    private fun detectArucoMarkers(imageBytes: ByteArray): List<Map<String, Any>> {
        val encoded = MatOfByte(*imageBytes)
        val image = Imgcodecs.imdecode(encoded, Imgcodecs.IMREAD_GRAYSCALE)
        val ids = Mat()
        val corners = mutableListOf<Mat>()
        try {
            if (image.empty()) return emptyList()
            val detector = ArucoDetector(
                Objdetect.getPredefinedDictionary(Objdetect.DICT_4X4_50)
            )
            detector.detectMarkers(image, corners, ids)
            val frameArea = image.cols().toDouble() * image.rows().toDouble()
            if (frameArea <= 0.0) return emptyList()

            return (0 until ids.rows()).mapNotNull { row ->
                val markerId = ids.get(row, 0)?.firstOrNull()?.toInt()
                    ?: return@mapNotNull null
                val points = FloatArray(8)
                val markerCorners = corners.getOrNull(row)
                    ?: return@mapNotNull null
                if (markerCorners.get(0, 0, points) != points.size) {
                    return@mapNotNull null
                }

                val edgeLengths = (0..3).map { index ->
                    val next = (index + 1) % 4
                    hypot(
                        (points[index * 2] - points[next * 2]).toDouble(),
                        (points[index * 2 + 1] - points[next * 2 + 1]).toDouble()
                    )
                }
                val shortestEdge = edgeLengths.minOrNull() ?: 0.0
                val longestEdge = edgeLengths.maxOrNull() ?: 0.0
                var doubledArea = 0.0
                for (index in 0..3) {
                    val next = (index + 1) % 4
                    doubledArea += points[index * 2] * points[next * 2 + 1] -
                        points[next * 2] * points[index * 2 + 1]
                }
                val areaRatio = (abs(doubledArea) / 2.0 / frameArea)
                    .coerceIn(0.0, 1.0)
                val shapeScore = if (longestEdge <= 0.0) 0.0
                    else (shortestEdge / longestEdge).coerceIn(0.0, 1.0)
                val areaScore = (areaRatio / 0.05).coerceIn(0.0, 1.0)
                val edgeScore = (shortestEdge / 140.0).coerceIn(0.0, 1.0)
                val qualityScore = (
                    shapeScore * 0.45 + areaScore * 0.30 + edgeScore * 0.25
                    ).coerceIn(0.0, 1.0)
                val accepted = shortestEdge >= 80.0 &&
                    areaRatio >= 0.02 &&
                    qualityScore >= 0.55

                mapOf(
                    "markerId" to markerId,
                    "qualityScore" to qualityScore,
                    "areaRatio" to areaRatio,
                    "shortestEdgePx" to shortestEdge,
                    "accepted" to accepted
                )
            }
        } finally {
            encoded.release()
            image.release()
            ids.release()
            corners.forEach(Mat::release)
        }
    }
}
