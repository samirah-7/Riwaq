# رِواق | Riwaq Hospital Guide

Riwaq is a bilingual Arabic/English Flutter prototype that helps a first-time
hospital visitor find clinics, doctors, appointments, and previously visited
locations.
Hospital data and routes are simulated. The assistant runs locally on bundled
rules and sample data; it does not call a generative model or external API.

## Current source and handoff

This folder contains the current Flutter app, including its 2D/3D map and
simulated route graph. The downloadable `riwaq-final.zip` is packaged from this
source and includes the supplied conceptual floor-plan PDF, its page images,
source, assets, tests, and documentation.

Build outputs, dependency caches, editor session files, generated plugin
registrants, and machine-specific Android `local.properties` are intentionally
excluded. Flutter recreates the necessary local files. No Replit account,
Node.js, pnpm, database, API key, or backend is needed for the Flutter app.

## Simulation-only notice

The supplied PDF is explicitly conceptual and has approximate dimensions. Every
room position, entrance, exit, corridor, elevator, stair, connection, and route
in this app is simulated and unverified. This project is for local testing and
hackathon prototyping only; it is not intended for real hospital visitors or
safety-critical navigation.

## Open and run locally in VS Code

### 1. Install the tools

- Install the Flutter SDK and add its `bin` directory to your system `PATH`.
  The browser app and automated checks were verified using **Flutter 3.32.0 /
  Dart 3.8.0**. Flutter includes Dart; do not install Dart separately.
- Install VS Code and its **Flutter** extension (`Dart-Code.flutter`).
  This also installs the Dart extension.
- Install Google Chrome for the browser preview.
- For Android, also install Android Studio, the Android SDK and command-line
  tools, an emulator or a USB-debugging-enabled phone, and a compatible JDK.
  See the Android compatibility note below before choosing your SDK version.

Run this in a terminal and resolve any issues for your chosen target:

```bash
flutter --version
flutter doctor -v
```

### 2. Extract and open the project

In VS Code, choose **File → Open Folder** and select **apps/riwaq** from this
workspace (or an extracted **riwaq** folder) containing `pubspec.yaml`.
Do not open only its `lib` folder. If VS Code asks for the Flutter SDK location,
select the Flutter SDK directory.

Open **Terminal → New Terminal** inside VS Code. It should be in that same
`riwaq` folder. Run:

```bash
flutter pub get
flutter devices
```

### 3. Run in Chrome

```bash
flutter run -d chrome
```

Alternatively, select **Chrome** in VS Code's device selector, then press **F5**
or choose **Run → Start Debugging**. Press `r` in the Flutter terminal for hot
reload, `R` for hot restart, and `q` to stop.

If you prefer opening a URL manually:

```bash
flutter run -d web-server --web-hostname 127.0.0.1 --web-port 8099
```

Then open `http://127.0.0.1:8099/` in Chrome. The included `web/` folder is ready
to use; there is no need to run `flutter create`.

### 4. Run on Android

Start an Android emulator from Android Studio's Device Manager, or connect an
Android phone with USB debugging enabled. Accept the SDK licenses if required:

```bash
flutter doctor --android-licenses
flutter devices
flutter run -d <android-device-id>
```

Replace `<android-device-id>` with the actual ID printed by `flutter devices`.
You can also select that device in VS Code and press **F5**. On macOS/Linux, if
the extracted Gradle script loses its executable permission, run:

```bash
chmod +x android/gradlew
```

**Android compatibility note:** The supplied Android build configuration was
preserved: Android Gradle Plugin **9.1.0**, Gradle **9.3.1**, and Kotlin plugin
**2.4.0**. A native APK build was attempted but is blocked because no Android
SDK is installed in this environment. These newer Android build tools also
require a Flutter SDK with compatible AGP/Kotlin support; the Flutter 3.32.0
browser build is not an Android build guarantee.
The SDK's standard Gradle wrapper launcher files are included in the handoff;
their distribution URL remains the project's original Gradle 9.3.1 setting.
Machine-specific SDK paths are recreated locally rather than shipped.

## Test locally

From VS Code's terminal in the extracted `riwaq` folder:

```bash
flutter analyze --no-fatal-infos
flutter test
dart run tool/generate_hospital_model.dart --check
```

Tests cover floor-plan data and connected nodes, same-floor routes on all three
levels, cross-floor and mobility routes, turn/floor instructions, manual
navigation progress and controls, recalculation after a location change,
2D/3D floor synchronization, corridor/wall separation, GLB room identities and
bounds, 3D gestures/picking, localization and theme-contrast checks, search and
doctor-to-map handoff, narrow and wide layouts, bilingual local assistant
understanding and route handoff, ArUco marker mapping and quality thresholds,
main navigation, all drawer destinations, and assistant input preservation.
They do not replace physical Android device or camera testing.

Current checks: `flutter test` passes 80 tests; `flutter analyze
--no-fatal-infos` passes with 31 informational `prefer_const` suggestions;
the bundled GLB matches the shared floor-plan data; `flutter build web` passes.

Optional browser build:

```bash
flutter build web
```

## Shared 2D / 3D architecture

The unified Map tab uses `lib/data/hospital_floor_plan_data.dart` for room bounds,
doorways, corridor nodes, floor IDs, and vertical-core identities. The GLB is
generated from this same definition, not maintained as a second floor plan.

After changing that data, run:

```bash
dart run tool/generate_hospital_model.dart
dart run tool/generate_hospital_model.dart --check
flutter test
```

The small GLB at `assets/hospital/riwaq_hospital.glb` is bundled locally.
The Flutter viewer reads its mesh vertex/index buffers and supports rotation,
zoom, picking, full-building, exploded, and individual-floor views. No 3D-viewer
package, WebView, remote model server, Blender installation, or external API is
required. See `PHASE_2_REPORT.md` for scope, file list, and future CV requirements.

## Included

- Four primary destinations: Home, Map, Appointments, and Riwaq Assistant.
- A right-side RTL drawer for doctors, visit history, saved locations, profile,
  notifications, settings, and help.
- Arabic/English visitor labels, RTL/LTR layout, and light/dark themes with
  contrast-checked text colors.
- Local doctor, appointment, location, visit, and notification sample data.
- Arabic and English doctor search and specialty filters.
- Persistent saved locations, profile fields, notification read states, and
  preferences on the current device.
- A bilingual local assistant that recognizes navigation, doctor, specialty,
  and safety intents from bundled hospital data.
- One hospital map with architectural 2D plans and an interactive procedural
  3D model for the ground, first, and second floors.
- An Android OpenCV ArUco prototype that maps four sample marker IDs to
  conceptual location nodes and rejects small or low-quality detections.
- Searchable departments and facilities, selected destinations, visible
  corridor-following demo routes, floor transitions, and movable demo starts.
- Step-by-step simulated directions with straight/turn/floor-transition
  instructions, start/pause/resume/cancel/restart controls, and manual progress
  that updates the demo location and both map views; active directions
  recalculate when the simulated start changes.
- Explicit unavailable-indoor-location handling and a future localization
  interface accepting IDs, floor metadata, confidence, and timestamps.

## Brand assets and font

The Riwaq image and vector assets from the supplied Figma frame are in
`assets/images/`. The supplied **29LT Bukra Light, Regular, and Bold** TTF files
are bundled and registered in `pubspec.yaml`. The upload did not include a
Medium face; details are in `assets/fonts/README.md`.

## Local assistant

The assistant uses local intent rules and the bundled sample hospital data.
It does not call a generative AI model or external API. The `AiProvider`
interface is the future integration point; no external provider is connected
in this phase.

## Prototype limitations

- Doctors, appointments, visits, and notifications are mock data.
- The 2D schematics and calculated routes are demonstrations, not approved
  blueprints or real-world wayfinding. The default and selectable start points
  are simulated, not detected location.
- The supplied conceptual PDF is only a testing reference. Floor-plan
  coordinates and corridor, entrance, exit, elevator, and stair connections are
  approximate and unverified. Do not use the app to direct real hospital
  visitors. There is no validated indoor location source or real-time tracking.
- ArUco detection is Android-only. Sample marker-to-place associations are
  simulated and not installed or verified at the real hospital. The image
  quality score is a geometric heuristic, not a location-accuracy estimate.
- The local assistant provides general information only. It does not
  diagnose, prescribe, or verify live doctors or schedules; emergency calls
  direct users to local emergency services (997 in Saudi Arabia).
- Appointment booking, cancellation, and modification are not connected.
- Profile and saved-place data remain on this device; no account or cloud sync
  exists.
