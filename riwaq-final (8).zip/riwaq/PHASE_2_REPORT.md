# Riwaq — Phase 2 implementation report

## 1. Existing map audit and fixes

The merged workspace already had a single map entry point, but retained the
old label-tile schematic. Every room connected to one corridor center; drawing
those edges made paths cut across the conceptual room areas. Several requested
departments were also missing, and the legacy radiology destination was on the
wrong floor.

The Map tab now has one selection, search, floor state, and route shared between
the 2D and 3D renderers. Legacy destination aliases such as EYE_CLINIC still work
from doctor, appointment, assistant, and saved-location screens. Their display
metadata now comes from the architectural registry rather than a duplicate list.
Saving a destination remains available and now works for every mapped place.

Routes use explicit doorway anchors and orthogonal corridor nodes, with no
diagonal shortcuts. Weighted illustrative graph search prefers elevators for
ordinary cross-floor trips. Vertical edges join the same core on adjacent floors,
not arbitrary facilities sharing a category. The blue route is painted on the
visible map; start, destination, and floor-transition markers are included.
Changing a start or destination recalculates the visible route.

## 2. Architectural 2D appearance

The new top-down drawing includes a perimeter, consistent walls, room
boundaries, doorway openings and swing arcs, intersecting corridors, department
groups, reception/waiting fixtures, stairs/elevator core, facilities, and a
ground-floor garden linked to the entrance by an outdoor path.

Clinical, public, staff, service, and outdoor areas have distinct restrained
finishes. Arabic labels and selectable room targets sit within the architectural
drawing, not independent dashboard cards. Pan, zoom, reset, and room selection
are available. Compact garden labels adapt to narrow mobile layouts.

All geometry is conceptual, normalized design data. There are no invented
metre dimensions, travel times, or claims that the building matches a real site.

## 3. Department / facility distribution

| Floor | Departments and areas |
| --- | --- |
| Ground | Main reception, emergency, pharmacy, radiology, laboratory, administration, main entrance, outdoor garden |
| First | Ophthalmology, dental, internal medicine, dermatology, cafeteria |
| Second | Inpatient, obstetrics/gynecology, surgery, nursery |
| Every floor | Men's and women's restrooms, men's and women's prayer rooms, elevator, staircase, emergency exit, waiting/rest area |

The ground garden is outside the building perimeter and has a connected
illustrative outdoor walking path. Elevator/stair locations align across floors.

## 4. Real 3D asset and integration

`tool/generate_hospital_model.dart` procedurally creates the GLB 2.0 asset
`assets/hospital/riwaq_hospital.glb` directly from the shared floor definition.
It contains 277 architectural cuboid parts (slabs, room floors, walls with
door gaps, and room-associated furniture), indexed vertex buffers, materials,
stable place/floor metadata, and conceptual-coordinate metadata.

The native Flutter viewer parses the GLB's actual position/index buffers,
applies its node transforms, projects and shades its mesh faces, depth-sorts
them, and performs face hit-testing. It is not a static illustration or a
parallel reconstruction from an unrelated model.

Controls include full-building/cutaway, exploded floors, individual floor,
drag rotation, pinch/mouse-wheel and button zoom, camera reset, floor selection,
and room picking. Selected rooms are highlighted and their Arabic name, floor,
and ID appear in the shared destination panel. The route also appears in 3D.
There is no external viewer dependency; Flutter 3.32 / Dart 3.8 is retained.

## 5. Maintaining 2D / 3D consistency

Both map rendering and GLB generation import
`lib/data/hospital_floor_plan_data.dart`. Rooms have one stable ID, floor ID,
relative bounds, doorway anchor, access-zone classification, and graph links.
Vertical connections have explicit core IDs.

After changing architecture:

```bash
dart run tool/generate_hospital_model.dart
dart run tool/generate_hospital_model.dart --check
flutter analyze
flutter test
```

The `--check` command fails if the bundled model is stale. Automated checks
compare all GLB room IDs, floors, and mesh bounds with the shared definition;
they also sample corridor edges to reject paths through room interiors.

## 6. Current location and destination selection

The main entrance is a clearly labeled **demo** starting point, never detected
GPS/indoor position. “My Location” calls the localization-provider interface
only after the user presses it. The default provider explains that no validated
indoor source is available; it requests no unnecessary GPS permission and offers
the entrance as an explicit demo choice.

The demo-start sheet moves the start between registered doorway/navigation
points. Search filters the destination list by Arabic name, floor and keywords.
Users can also select a room in either map representation. Cross-floor routes
have clickable transition instructions that change the visible floor.

Future providers can be injected without coupling camera/recognition to map
painting. Accepted predictions update start state with their source metadata.
Invalid, stale, wrong-floor, low-confidence, or unregistered-landmark predictions
are rejected. A provider estimate remains labeled unverified, not real tracking.

## 7. Computer Vision readiness — not a trained model

Each mapped place has a reserved stable visual-landmark ID and floor/location
mapping in `localization_landmarks.dart`. These are **capture targets**, not
collected or verified hospital photographs.

`IndoorLocationPrediction` supports location ID, floor ID, optional landmark ID,
provider ID, confidence, and timestamp. `IndoorLocalizationProvider` is separate
from the camera, the existing reference-image recognition prototype, and map
renderers. `PredictionLocalizationProvider` validates incoming predictions.
No trained computer-vision model, synthetic recognition results, or fake indoor
tracking has been added. The older reference-photo matcher remains disabled as
a locator while its approved reference list is empty.

Before future CV localization can be claimed:

1. Obtain permission for collecting hospital images; avoid faces, patient
   records, and other private information.
2. Capture approved signage/landmarks from multiple viewpoints, distances,
   lighting conditions, and camera devices; label stable place/floor IDs.
3. Choose and train or configure a suitable localization model, with held-out
   test photographs from different capture sessions.
4. Calibrate confidence and rejection rules against actual false matches;
   measure room/floor confusion, latency, and unknown-location behavior.
5. Validate on real devices in the actual hospital, including repeated corridors,
   changing signs, occlusions, low light, and loss of connectivity.
6. Connect a permission-aware capture adapter only on explicit user action.

The development confidence/age thresholds are input safeguards, not evidence
of model accuracy or clinical/navigation safety.

## 8. Verification and real-data blockers

Automated checks cover department distribution, unique IDs, room/corridor
separation, connected routes, adjacent-floor transitions, GLB geometry parity,
3D camera/picking behavior, destination search, demo updates, localization
validation, existing navigation/assistant behavior, and mobile layouts.
The running browser is separately checked for visible architectural plans,
routes, and interactive 3D; see the final handoff message for the observed result.

Results:
- The full Flutter suite passed 24 tests; the six architectural tests were
  re-run successfully after the final rendering/camera-fit changes.
- `flutter analyze`: no issues.
- GLB `--check`: shared data and generated model matched.
- Actual browser checks passed at 390×1000 and 1100×1000: architectural plans,
  room selection, search, visible routes, floor transitions, demo starts,
  unavailable-location dialog, 3D views, rotation/zoom/reset, and exact dental
  and eye-room surface selection.
- The browser exposed a slab-overpainting/picking defect, which was fixed and
  successfully rechecked. A later default-camera fit correction is covered by
  projecting every GLB vertex into mobile/wide viewport bounds in all modes.
- No JavaScript console errors were observed. The test browser used Flutter's
  CPU fallback because WebGL was unavailable; hardware performance remains an
  on-device validation item.

Still required for real wayfinding: approved architectural plans, surveyed
coordinates, confirmed doors and public/staff access permissions, actual vertical
cores and accessible paths, emergency-egress approval, a validated indoor-location
source, and on-site device testing. Native Android APK/camera tests are not
substituted by browser verification.

No Phase 3 or production-grade routing / indoor tracking was started.

## 9. Created and modified files

### Created
- `assets/hospital/riwaq_hospital.glb`
- `tool/generate_hospital_model.dart`
- `lib/models/architectural_model.dart`
- `lib/models/indoor_localization.dart`
- `lib/data/localization_landmarks.dart`
- `lib/widgets/hospital_plan_2d.dart`
- `lib/widgets/hospital_model_3d.dart`
- `test/hospital_architecture_test.dart`
- `PHASE_2_REPORT.md`

### Modified
- `lib/models/hospital_floor_plan.dart`
- `lib/data/hospital_floor_plan_data.dart`
- `lib/data/location_data.dart`
- `lib/services/hospital_route_service.dart`
- `lib/services/location_provider.dart`
- `lib/services/location_state.dart`
- `lib/screens/floor_plan_screen.dart`
- `lib/screens/map_screen.dart`
- `pubspec.yaml`
- `test/widget_test.dart`
- `README.md`
- `MAP_INTEGRATION.md`
- Workspace `replit.md` (updated scope and maintenance guidance)
- Workspace `.agents/memory/MEMORY.md` and
  `.agents/memory/flutter-3d-preview.md` (browser-environment compatibility note)

Paths above are relative to `apps/riwaq` unless identified as workspace files.
The earlier Phase 1 ZIP was not regenerated as part of this Phase 2 request.
