enum AppNotificationKind { appointment, location, general }

class AppNotification {
  const AppNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.dateLabel,
    required this.kind,
    this.appointmentId,
    this.locationId,
  });

  final String id;
  final String title;
  final String message;
  final String dateLabel;
  final AppNotificationKind kind;
  final String? appointmentId;
  final String? locationId;
}
