class VisualLandmarkReference {
  const VisualLandmarkReference(
      {required this.locationId, required this.assetPath});
  final String locationId;
  final String assetPath;
}

enum VisualRecognitionStatus {
  matched,
  noReferenceData,
  noReliableMatch,
  invalidImage
}

class VisualRecognitionResult {
  const VisualRecognitionResult(
      {required this.status, this.locationId, this.confidence});
  final VisualRecognitionStatus status;
  final String? locationId;
  final double? confidence;
}
