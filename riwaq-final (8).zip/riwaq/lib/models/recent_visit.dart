class RecentVisit {
  const RecentVisit({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.date,
    required this.locationId,
    this.doctorId,
  });

  final String id;
  final String title;
  final String subtitle;
  final String date;
  final String locationId;
  final String? doctorId;
}
