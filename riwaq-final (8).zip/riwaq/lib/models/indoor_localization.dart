/// Contract for a future independently validated indoor localization source.
/// A confidence is a provider's score, not a calibrated accuracy guarantee.
class IndoorLocationPrediction {
  const IndoorLocationPrediction({
    required this.locationId,
    required this.floorId,
    required this.confidence,
    required this.timestamp,
    required this.providerId,
    this.landmarkId,
  });
  final String locationId, floorId, providerId;
  final String? landmarkId;
  final double confidence;
  final DateTime timestamp;
}

class LocalizationLandmark {
  const LocalizationLandmark(
      {required this.id,
      required this.locationId,
      required this.floorId,
      required this.descriptionAr});
  final String id, locationId, floorId, descriptionAr;
}
