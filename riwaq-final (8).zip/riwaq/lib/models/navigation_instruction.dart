enum NavigationManeuver {
  start,
  straight,
  turnLeft,
  turnRight,
  turnAround,
  floorTransition,
}

/// One instruction in a simulated route. Indices point into [HospitalRoute.places].
class NavigationInstruction {
  const NavigationInstruction({
    required this.fromIndex,
    required this.toIndex,
    required this.floorId,
    required this.maneuver,
    required this.textAr,
    required this.textEn,
    this.arrival = false,
  });

  final int fromIndex;
  final int toIndex;
  final String floorId;
  final NavigationManeuver maneuver;
  final String textAr;
  final String textEn;
  final bool arrival;
}
