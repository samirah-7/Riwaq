enum AssistantIntent {
  emergency,
  healthInformation,
  specialtySearch,
  departmentNavigation,
  facilitySearch,
  doctorSearch,
  appointmentInquiry,
  general,
  unclear,
}

enum AssistantClarificationField { topic, origin, destination }

class AssistantResponse {
  const AssistantResponse({
    required this.intent,
    required this.message,
    required this.confidence,
    this.originId,
    this.originWasSpecified = false,
    this.destinationId,
    this.specialtyId,
    this.departmentId,
    this.clarificationNeeded,
    this.doctorIds = const [],
    this.actions = const [],
  });

  final AssistantIntent intent;
  final String message;
  final double confidence;
  final String? originId;
  final bool originWasSpecified;
  final String? specialtyId;
  final String? destinationId;
  final String? departmentId;
  final AssistantClarificationField? clarificationNeeded;
  final List<String> doctorIds;
  final List<String> actions;
}
