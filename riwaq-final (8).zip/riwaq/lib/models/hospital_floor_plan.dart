enum FloorPlaceCategory {
  department,
  service,
  room,
  corridor,
  entrance,
  restroom,
  prayerRoom,
  stairs,
  emergencyExit,
  elevator,
  waitingArea,
  garden,
}

enum PlanZone { public, clinical, staff, service, outdoor }

enum FloorPlanConnectionType { corridor, doorway, vertical }

class MobilityRoutePreferences {
  const MobilityRoutePreferences({
    this.allowStairs = true,
    this.allowElevators = true,
  });

  final bool allowStairs;
  final bool allowElevators;

  MobilityRoutePreferences copyWith({
    bool? allowStairs,
    bool? allowElevators,
  }) =>
      MobilityRoutePreferences(
        allowStairs: allowStairs ?? this.allowStairs,
        allowElevators: allowElevators ?? this.allowElevators,
      );
}

enum RouteFailureReason {
  unknownLocation,
  noConnectedPath,
  excludedByMobilityPreferences,
}

class HospitalRouteSearchResult {
  const HospitalRouteSearchResult({
    this.route,
    this.failureReason,
  });

  final HospitalRoute? route;
  final RouteFailureReason? failureReason;

  bool get found => route != null;
}

/// Relative design units only: these are not real-world dimensions.
class PlanRect {
  const PlanRect(this.left, this.top, this.width, this.height);
  final double left, top, width, height;
  double get right => left + width;
  double get bottom => top + height;
  double get centerX => left + width / 2;
  double get centerY => top + height / 2;
}

class FloorPlanPlace {
  const FloorPlanPlace({
    required this.id,
    required this.floorId,
    required this.nameAr,
    required this.category,
    required this.descriptionAr,
    required this.x,
    required this.y,
    this.mapLocationId,
    this.connections = const [],
    this.bounds,
    this.zone = PlanZone.public,
    this.verticalConnectionId,
    this.keywords = const [],
  });

  final String id;
  final String floorId;
  final String nameAr;
  final FloorPlaceCategory category;
  final String descriptionAr;

  /// Normalized walkable/doorway anchor (0–1), NOT the room's label/centre.
  /// Bounds describe room extents; none of these are measured floor-plan data.
  final double x;
  final double y;

  /// Connects to the shared virtual location ID when one is registered.
  final String? mapLocationId;

  /// Illustrative graph connections. They must not be treated as surveyed paths.
  final List<String> connections;
  final PlanRect? bounds;
  final PlanZone zone;
  final String? verticalConnectionId;
  final List<String> keywords;
}

class FloorPlanConnection {
  const FloorPlanConnection({
    required this.fromId,
    required this.toId,
    required this.type,
  });

  final String fromId;
  final String toId;
  final FloorPlanConnectionType type;
}

class HospitalFloorPlan {
  const HospitalFloorPlan({
    required this.id,
    required this.level,
    required this.nameAr,
    required this.places,
    this.connections = const [],
    this.corridors = const [],
    this.assetPath,
    this.isSimulated = true,
  });

  final String id;
  final int level;
  final String nameAr;
  final List<FloorPlanPlace> places;

  /// Explicit route edges, including only the cross-floor links declared in data.
  final List<FloorPlanConnection> connections;
  final List<PlanRect> corridors;
  final String? assetPath;
  final bool isSimulated;

  List<FloorPlanPlace> get selectablePlaces => places
      .where((place) => place.category != FloorPlaceCategory.corridor)
      .toList();
}

class HospitalRoute {
  const HospitalRoute({
    required this.startLocationId,
    required this.destinationLocationId,
    required this.places,
    this.isSimulated = true,
  });

  final String startLocationId;
  final String destinationLocationId;
  final List<FloorPlanPlace> places;
  final bool isSimulated;

  List<FloorPlanPlace> placesOnFloor(String floorId) =>
      places.where((place) => place.floorId == floorId).toList(growable: false);

  List<({FloorPlanPlace from, FloorPlanPlace to})> get floorTransitions {
    final transitions = <({FloorPlanPlace from, FloorPlanPlace to})>[];
    for (var index = 1; index < places.length; index++) {
      final from = places[index - 1];
      final to = places[index];
      if (from.floorId != to.floorId) {
        transitions.add((from: from, to: to));
      }
    }
    return transitions;
  }
}
