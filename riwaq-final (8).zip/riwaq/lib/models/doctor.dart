class Doctor {
  const Doctor(
      {required this.name,
      required this.specialty,
      required this.availability,
      required this.initials,
      required this.id,
      required this.specialtyId,
      required this.departmentId,
      required this.locationId,
      required this.floor});
  final String id;
  final String name;
  final String specialty;
  final String specialtyId;
  final String departmentId;
  final String locationId;
  final int floor;
  final String availability;
  final String initials;
}
