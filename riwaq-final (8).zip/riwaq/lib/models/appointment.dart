class Appointment {
  const Appointment(
      {required this.id,
      required this.doctorId,
      required this.doctorName,
      required this.specialty,
      required this.date,
      required this.time,
      required this.locationId,
      this.status = 'مؤكد'});
  final String id;
  final String doctorId;
  final String doctorName;
  final String specialty;
  final String date;
  final String time;
  final String locationId;
  final String status;
}
