import 'dart:convert';
import 'dart:typed_data';

class ModelVertex {
  const ModelVertex(this.x, this.y, this.z);
  final double x, y, z;
}

class ArchitecturalPart {
  const ArchitecturalPart({
    required this.vertices,
    required this.indices,
    required this.color,
    required this.floorId,
    required this.level,
    required this.kind,
    this.placeId,
  });
  final List<ModelVertex> vertices;
  final List<int> indices;
  final List<double> color;
  final String floorId, kind;
  final int level;
  final String? placeId;
}

/// Minimal reader for our procedural GLB's indexed, transformed cuboid meshes.
/// Reads actual vertex/index buffers, not a separately reconstructed building.
class ArchitecturalModel {
  ArchitecturalModel(this.parts);
  final List<ArchitecturalPart> parts;

  factory ArchitecturalModel.fromGlb(ByteData bytes) {
    if (bytes.getUint32(0, Endian.little) != 0x46546c67 ||
        bytes.getUint32(4, Endian.little) != 2) {
      throw const FormatException('Expected a GLB 2.0 architectural asset');
    }
    final jsonLength = bytes.getUint32(12, Endian.little);
    final raw =
        bytes.buffer.asUint8List(bytes.offsetInBytes, bytes.lengthInBytes);
    final doc = jsonDecode(utf8.decode(raw.sublist(20, 20 + jsonLength)))
        as Map<String, dynamic>;
    final binStart = 20 + jsonLength + 8;
    final accessors = doc['accessors'] as List;
    final views = doc['bufferViews'] as List;
    int offset(Map a) =>
        binStart +
        ((views[a['bufferView']] as Map)['byteOffset'] as int? ?? 0) +
        (a['byteOffset'] as int? ?? 0);
    final parts = <ArchitecturalPart>[];
    for (final node in doc['nodes'] as List) {
      if (node['mesh'] == null) continue;
      final extras = node['extras'] as Map;
      final mesh = (doc['meshes'] as List)[node['mesh']];
      final t = (node['translation'] as List).cast<num>();
      final s = (node['scale'] as List).cast<num>();
      for (final primitive in mesh['primitives'] as List) {
        final a = accessors[primitive['attributes']['POSITION']] as Map;
        final start = offset(a);
        final vertices = <ModelVertex>[];
        for (var i = 0; i < (a['count'] as int); i++) {
          vertices.add(ModelVertex(
            bytes.getFloat32(start + i * 12, Endian.little) * s[0] + t[0],
            bytes.getFloat32(start + i * 12 + 4, Endian.little) * s[1] + t[1],
            bytes.getFloat32(start + i * 12 + 8, Endian.little) * s[2] + t[2],
          ));
        }
        final ia = accessors[primitive['indices']] as Map;
        final indices = List.generate(ia['count'] as int,
            (i) => bytes.getUint16(offset(ia) + i * 2, Endian.little));
        final material = (doc['materials'] as List)[primitive['material']];
        parts.add(ArchitecturalPart(
          vertices: vertices,
          indices: indices,
          color: (material['pbrMetallicRoughness']['baseColorFactor'] as List)
              .map((v) => (v as num).toDouble())
              .toList(),
          floorId: extras['floorId'] as String,
          level: extras['level'] as int,
          kind: extras['kind'] as String,
          placeId: extras['placeId'] as String?,
        ));
      }
    }
    if (parts.isEmpty) {
      throw const FormatException('Architectural model has no meshes');
    }
    return ArchitecturalModel(parts);
  }
}
