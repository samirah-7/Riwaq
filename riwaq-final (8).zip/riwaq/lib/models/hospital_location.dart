class HospitalLocation {
  const HospitalLocation(
      {required this.id,
      required this.nameAr,
      required this.floor,
      this.buildingId = 'VIRTUAL_BUILDING',
      this.keywords = const []});
  final String id;
  final String nameAr;
  final int floor;
  final String buildingId;
  final List<String> keywords;
}
