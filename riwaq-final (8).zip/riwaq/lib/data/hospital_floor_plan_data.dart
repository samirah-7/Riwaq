import '../models/hospital_floor_plan.dart';

// Conceptual test data adapted from the supplied floor-plan PDF. All geometry
// and links are approximate and unverified; never use them for real wayfinding.
const hospitalFloorPlanSource =
    'assets/floor_plans/riwaq_conceptual_floor_plans.pdf';
const hospitalBuildingBounds = PlanRect(.035, .035, .93, .86);
const _rows = [.065, .275, .475, .675];
const _columns = [.06, .255, .555, .75];
const _hallY = [.235, .435, .635, .835];
const _hallX = [.155, .35, .5, .65, .845];

typedef _Department = ({
  String id,
  String name,
  String? alias,
  int row,
  int column,
  bool wide,
  PlanZone zone,
  List<String> keywords,
});

FloorPlanPlace? findHospitalPlace(String? id) {
  if (id == null) return null;
  for (final floor in hospitalFloorPlans) {
    for (final place in floor.places) {
      if (place.id == id || place.mapLocationId == id) return place;
    }
  }
  return null;
}

HospitalFloorPlan _floor(
    String id, int level, String name, List<_Department> departments) {
  final places = <FloorPlanPlace>[];
  FloorPlanPlace room({
    required String key,
    required String label,
    required int row,
    required int column,
    bool wide = false,
    String? alias,
    FloorPlaceCategory category = FloorPlaceCategory.department,
    PlanZone zone = PlanZone.public,
    String? vertical,
    List<String> keywords = const [],
  }) {
    final rect = PlanRect(_columns[column], _rows[row], wide ? .385 : .19, .14);
    // Wide rooms open at the nearer of the two corridor nodes.
    final nodeColumn =
        wide ? (column == 0 ? 1 : 3) : (column < 2 ? column : column + 1);
    return FloorPlanPlace(
      id: key,
      floorId: id,
      nameAr: label,
      category: category,
      descriptionAr: zone == PlanZone.staff
          ? 'منطقة مخصصة للموظفين؛ التصميم توضيحي.'
          : 'موقع في مخطط المستشفى التصوري، غير معتمد للملاحة الفعلية.',
      x: _hallX[nodeColumn],
      y: rect.bottom,
      bounds: rect,
      zone: zone,
      mapLocationId: alias,
      connections: ['${id}_H${row}_$nodeColumn'],
      verticalConnectionId: vertical,
      keywords: keywords,
    );
  }

  for (final d in departments) {
    places.add(room(
        key: d.id,
        label: d.name,
        row: d.row,
        column: d.column,
        wide: d.wide,
        alias: d.alias,
        zone: d.zone,
        keywords: d.keywords));
  }
  for (final common in [
    (
      key: 'MENS_RESTROOM',
      label: 'دورة مياه الرجال',
      row: 2,
      col: 0,
      category: FloorPlaceCategory.restroom
    ),
    (
      key: 'WOMENS_RESTROOM',
      label: 'دورة مياه النساء',
      row: 2,
      col: 1,
      category: FloorPlaceCategory.restroom
    ),
    (
      key: 'PRAYER_ROOM',
      label: 'مصلى الرجال',
      row: 2,
      col: 2,
      category: FloorPlaceCategory.prayerRoom
    ),
    (
      key: 'WOMENS_PRAYER_ROOM',
      label: 'مصلى النساء',
      row: 2,
      col: 3,
      category: FloorPlaceCategory.prayerRoom
    ),
    (
      key: 'ELEVATOR',
      label: 'المصعد',
      row: 3,
      col: 0,
      category: FloorPlaceCategory.elevator
    ),
    (
      key: 'STAIRCASE',
      label: 'السلالم',
      row: 3,
      col: 1,
      category: FloorPlaceCategory.stairs
    ),
    (
      key: 'EMERGENCY_EXIT',
      label: 'مخرج طوارئ',
      row: 3,
      col: 2,
      category: FloorPlaceCategory.emergencyExit
    ),
    (
      key: 'WAITING',
      label: level == 2 ? 'استراحة المرضى والزوار' : 'انتظار واستراحة الزوار',
      row: 3,
      col: 3,
      category: FloorPlaceCategory.waitingArea
    ),
  ]) {
    places.add(room(
      key: '${id}_COMMON_${common.key}',
      label: common.label,
      row: common.row,
      column: common.col,
      category: common.category,
      zone: PlanZone.service,
      vertical: common.category == FloorPlaceCategory.elevator
          ? 'CORE_LIFT'
          : common.category == FloorPlaceCategory.stairs
              ? 'CORE_STAIRS'
              : null,
    ));
  }
  // Explicit orthogonal corridor graph. Doorway nodes connect only to the
  // corridor directly outside their room; no diagonal shortcuts through walls.
  for (var row = 0; row < _hallY.length; row++) {
    for (var column = 0; column < _hallX.length; column++) {
      places.add(FloorPlanPlace(
        id: '${id}_H${row}_$column',
        floorId: id,
        nameAr: 'تقاطع ممر',
        category: FloorPlaceCategory.corridor,
        descriptionAr: 'عقدة مسار تصورية',
        x: _hallX[column],
        y: _hallY[row],
        connections: [
          if (column > 0) '${id}_H${row}_${column - 1}',
          if (column < 4) '${id}_H${row}_${column + 1}',
          if (column == 2 && row > 0) '${id}_H${row - 1}_2',
          if (column == 2 && row < 3) '${id}_H${row + 1}_2',
        ],
      ));
    }
  }
  // The concept plan shows a second lift and stair core on each level.
  places.addAll([
    FloorPlanPlace(
      id: '${id}_COMMON_ELEVATOR_B',
      floorId: id,
      nameAr: 'المصاعد - المجموعة ب',
      category: FloorPlaceCategory.elevator,
      descriptionAr: 'مصاعد في المخطط التصوري، غير متحقق منها ميدانياً.',
      x: .56,
      y: .835,
      connections: ['${id}_H3_2'],
      zone: PlanZone.service,
      verticalConnectionId: 'CORE_LIFT_B',
    ),
    FloorPlanPlace(
      id: '${id}_COMMON_STAIRCASE_B',
      floorId: id,
      nameAr: 'السلالم ب',
      category: FloorPlaceCategory.stairs,
      descriptionAr: 'سلالم في المخطط التصوري، غير متحقق منها ميدانياً.',
      x: .77,
      y: .835,
      connections: ['${id}_H3_4'],
      zone: PlanZone.service,
      verticalConnectionId: 'CORE_STAIRS_B',
    ),
    for (final exit in [
      (side: 'WEST', row: 1, column: 0, label: 'الغربي العلوي'),
      (side: 'EAST', row: 1, column: 4, label: 'الشرقي العلوي'),
      (side: 'WEST', row: 2, column: 0, label: 'الغربي السفلي'),
      (side: 'EAST', row: 2, column: 4, label: 'الشرقي السفلي'),
    ])
      FloorPlanPlace(
        id: '${id}_EXIT_${exit.side}_${exit.row}',
        floorId: id,
        nameAr: 'مخرج الطوارئ ${exit.label}',
        category: FloorPlaceCategory.emergencyExit,
        descriptionAr: 'مخرج تصوري متصل بالممر؛ غير معتمد للاستخدام الفعلي.',
        x: _hallX[exit.column],
        y: _hallY[exit.row],
        connections: ['${id}_H${exit.row}_${exit.column}'],
        zone: PlanZone.service,
      ),
  ]);
  if (level == 0) {
    places.addAll([
      const FloorPlanPlace(
        id: 'G_MAIN_ENTRANCE',
        floorId: 'GROUND',
        nameAr: 'المدخل الرئيسي',
        category: FloorPlaceCategory.entrance,
        descriptionAr: 'بداية تجريبية افتراضية، وليست موقعاً مكتشفاً للمستخدم.',
        x: .5,
        y: .89,
        mapLocationId: 'MAIN_ENTRANCE',
        connections: ['GROUND_H3_2', 'G_OUTDOOR_PATH'],
      ),
      const FloorPlanPlace(
        id: 'G_EMERGENCY_ENTRANCE',
        floorId: 'GROUND',
        nameAr: 'مدخل الطوارئ',
        category: FloorPlaceCategory.entrance,
        descriptionAr: 'مدخل تصوري للطوارئ، غير متحقق ميدانياً.',
        x: .35,
        y: .89,
        connections: ['GROUND_H3_1'],
      ),
      const FloorPlanPlace(
        id: 'G_AMBULANCE_ENTRANCE',
        floorId: 'GROUND',
        nameAr: 'مدخل الإسعاف',
        category: FloorPlaceCategory.entrance,
        descriptionAr: 'مدخل إسعاف تصوري، غير متحقق ميدانياً.',
        x: .155,
        y: .89,
        connections: ['GROUND_H3_0'],
      ),
      const FloorPlanPlace(
        id: 'G_OUTDOOR_PATH',
        floorId: 'GROUND',
        nameAr: 'الممر الخارجي',
        category: FloorPlaceCategory.corridor,
        descriptionAr: 'ممشى الحديقة التصوري',
        x: .5,
        y: .95,
        connections: ['G_GARDEN'],
      ),
      const FloorPlanPlace(
        id: 'G_GARDEN',
        floorId: 'GROUND',
        nameAr: 'حديقة المستشفى',
        category: FloorPlaceCategory.garden,
        descriptionAr: 'حديقة خارجية متصلة بالمدخل عبر ممشى تصوري.',
        x: .25,
        y: .95,
        bounds: PlanRect(.055, .915, .38, .075),
        zone: PlanZone.outdoor,
        connections: ['G_OUTDOOR_PATH'],
      ),
    ]);
  }
  final placesById = {for (final place in places) place.id: place};
  final seenEdges = <String>{};
  final connections = <FloorPlanConnection>[];
  for (final place in places) {
    for (final targetId in place.connections) {
      final target = placesById[targetId];
      if (target == null) {
        throw StateError('Unknown route endpoint $targetId from ${place.id}');
      }
      final ids = [place.id, target.id]..sort();
      if (!seenEdges.add(ids.join('|'))) continue;
      connections.add(FloorPlanConnection(
        fromId: place.id,
        toId: target.id,
        type: place.category == FloorPlaceCategory.corridor &&
                target.category == FloorPlaceCategory.corridor
            ? FloorPlanConnectionType.corridor
            : FloorPlanConnectionType.doorway,
      ));
    }
  }
  return HospitalFloorPlan(
    id: id,
    level: level,
    nameAr: name,
    places: List.unmodifiable(places),
    connections: List.unmodifiable(connections),
    assetPath: 'assets/floor_plans/${id.toLowerCase()}_floor.png',
    isSimulated: true,
    corridors: [
      const PlanRect(.465, .045, .07, .845),
      for (final y in _hallY) PlanRect(.055, y - .025, .89, .05),
    ],
  );
}

final _baseFloorPlans = [
  _floor('GROUND', 0, 'الدور الأرضي', [
    (
      id: 'G_RECEPTION',
      name: 'الاستقبال الرئيسي',
      alias: 'RECEPTION',
      row: 0,
      column: 0,
      wide: true,
      zone: PlanZone.public,
      keywords: ['استقبال', 'استعلامات', 'معلومات']
    ),
    (
      id: 'G_EMERGENCY',
      name: 'الطوارئ',
      alias: 'EMERGENCY',
      row: 0,
      column: 2,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['طوارئ', 'الطوارئ']
    ),
    (
      id: 'G_PHARMACY',
      name: 'الصيدلية',
      alias: 'PHARMACY',
      row: 1,
      column: 0,
      wide: false,
      zone: PlanZone.service,
      keywords: ['صيدلية', 'دواء', 'أدوية', 'صرف الدواء']
    ),
    (
      id: 'G_RADIOLOGY',
      name: 'الأشعة',
      alias: 'RADIOLOGY',
      row: 1,
      column: 1,
      wide: false,
      zone: PlanZone.clinical,
      keywords: ['أشعة', 'تصوير أشعة', 'x-ray', 'radiology']
    ),
    (
      id: 'G_LABORATORY',
      name: 'المختبر',
      alias: 'LABORATORY',
      row: 1,
      column: 2,
      wide: false,
      zone: PlanZone.clinical,
      keywords: ['مختبر', 'تحاليل', 'فحص الدم', 'تحليل دم']
    ),
    (
      id: 'G_ADMINISTRATION',
      name: 'الإدارة',
      alias: null,
      row: 1,
      column: 3,
      wide: false,
      zone: PlanZone.staff,
      keywords: ['إدارة', 'مكاتب']
    ),
  ]),
  _floor('FIRST', 1, 'الدور الأول', [
    (
      id: 'F_OPHTHALMOLOGY',
      name: 'عيادة العيون',
      alias: 'EYE_CLINIC',
      row: 0,
      column: 0,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['عيون', 'عيادات العيون', 'طب العيون']
    ),
    (
      id: 'F_DENTAL',
      name: 'عيادة الأسنان',
      alias: 'DENTAL_CLINIC',
      row: 0,
      column: 2,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['أسنان', 'الأسنان', 'عيادات الأسنان']
    ),
    (
      id: 'F_INTERNAL_MEDICINE',
      name: 'عيادات الباطنية',
      alias: null,
      row: 1,
      column: 0,
      wide: false,
      zone: PlanZone.clinical,
      keywords: ['باطنية', 'الباطنية']
    ),
    (
      id: 'F_DERMATOLOGY',
      name: 'عيادة الجلدية',
      alias: 'DERMATOLOGY',
      row: 1,
      column: 1,
      wide: false,
      zone: PlanZone.clinical,
      keywords: ['جلدية', 'الجلدية']
    ),
    (
      id: 'F_CAFETERIA',
      name: 'الكافتيريا',
      alias: null,
      row: 1,
      column: 2,
      wide: true,
      zone: PlanZone.public,
      keywords: ['كافتيريا', 'طعام']
    ),
  ]),
  _floor('SECOND', 2, 'الدور الثاني', [
    (
      id: 'S_INPATIENT',
      name: 'التنويم',
      alias: null,
      row: 0,
      column: 0,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['تنويم']
    ),
    (
      id: 'S_OBSTETRICS',
      name: 'النساء والولادة',
      alias: null,
      row: 0,
      column: 2,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['نساء', 'ولادة']
    ),
    (
      id: 'S_SURGERY',
      name: 'الجراحة',
      alias: null,
      row: 1,
      column: 0,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['جراحة']
    ),
    (
      id: 'S_NURSERY',
      name: 'الحضانة',
      alias: null,
      row: 1,
      column: 2,
      wide: true,
      zone: PlanZone.clinical,
      keywords: ['حضانة', 'مواليد']
    ),
  ]),
];

// Cross-floor transitions are authored links; matching labels or group IDs
// never create an implicit route.
final List<HospitalFloorPlan> defaultHospitalFloorPlans = List.unmodifiable([
  for (final floor in _baseFloorPlans)
    HospitalFloorPlan(
      id: floor.id,
      level: floor.level,
      nameAr: floor.nameAr,
      places: floor.places,
      corridors: floor.corridors,
      assetPath: floor.assetPath,
      isSimulated: true,
      connections: List.unmodifiable([
        ...floor.connections,
        if (floor.id == 'GROUND') ...const [
          FloorPlanConnection(
              fromId: 'GROUND_COMMON_ELEVATOR',
              toId: 'FIRST_COMMON_ELEVATOR',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'GROUND_COMMON_ELEVATOR_B',
              toId: 'FIRST_COMMON_ELEVATOR_B',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'GROUND_COMMON_STAIRCASE',
              toId: 'FIRST_COMMON_STAIRCASE',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'GROUND_COMMON_STAIRCASE_B',
              toId: 'FIRST_COMMON_STAIRCASE_B',
              type: FloorPlanConnectionType.vertical),
        ],
        if (floor.id == 'FIRST') ...const [
          FloorPlanConnection(
              fromId: 'FIRST_COMMON_ELEVATOR',
              toId: 'SECOND_COMMON_ELEVATOR',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'FIRST_COMMON_ELEVATOR_B',
              toId: 'SECOND_COMMON_ELEVATOR_B',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'FIRST_COMMON_STAIRCASE',
              toId: 'SECOND_COMMON_STAIRCASE',
              type: FloorPlanConnectionType.vertical),
          FloorPlanConnection(
              fromId: 'FIRST_COMMON_STAIRCASE_B',
              toId: 'SECOND_COMMON_STAIRCASE_B',
              type: FloorPlanConnectionType.vertical),
        ],
      ]),
    ),
]);

List<HospitalFloorPlan> hospitalFloorPlans = defaultHospitalFloorPlans;
