import '../models/hospital_location.dart';
import 'hospital_floor_plan_data.dart';

/// Legacy destination aliases are retained, but names and floors come from the
/// same architectural data used by the unified map and generated 3D model.
final virtualLocations = [
  for (final floor in hospitalFloorPlans)
    for (final place in floor.selectablePlaces)
      HospitalLocation(
        id: place.mapLocationId ?? place.id,
        nameAr: place.nameAr,
        floor: floor.level,
        keywords: [place.nameAr, ...place.keywords],
      ),
];
