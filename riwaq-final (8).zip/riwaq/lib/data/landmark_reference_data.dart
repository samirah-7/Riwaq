import '../models/visual_landmark.dart';

/// Add approved, labeled reference photos only after the virtual-map team supplies them.
/// Each location should have several angles and lighting conditions.
const visualLandmarkReferences = <VisualLandmarkReference>[];
