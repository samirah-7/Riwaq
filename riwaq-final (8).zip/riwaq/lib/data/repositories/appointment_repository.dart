import '../mock_data.dart';
import '../../models/appointment.dart';

class AppointmentRepository {
  const AppointmentRepository();
  List<Appointment> getAll() => appointmentItems;
  Appointment? byId(String id) {
    for (final appointment in appointmentItems) {
      if (appointment.id == id) return appointment;
    }
    return null;
  }
}
