import '../mock_data.dart';
import '../../models/doctor.dart';
import '../../services/ai/arabic_text.dart';
import '../../l10n/riwaq_text.dart';

class DoctorRepository {
  const DoctorRepository();

  List<Doctor> getAll() => doctors;

  List<Doctor> bySpecialty(String specialtyId) => doctors
      .where((doctor) => doctor.specialtyId == specialtyId)
      .toList(growable: false);

  Doctor? byId(String id) {
    for (final doctor in doctors) {
      if (doctor.id == id) return doctor;
    }
    return null;
  }

  Doctor? findByText(String input) {
    final text = normalizeArabic(input);
    if (text.isEmpty) return null;
    final matches = doctors.where((doctor) {
      final arabicName = normalizeArabic(doctor.name);
      final englishName = normalizeArabic(
        riwaqLocalizedValue(doctor.name, languageCode: 'en'),
      );
      return _containsName(text, arabicName) ||
          _containsName(text, englishName);
    }).toList(growable: false);
    return matches.length == 1 ? matches.single : null;
  }

  bool _containsName(String text, String name) {
    if (name.isEmpty) return false;
    if (name.contains(' ')) {
      if (text.contains(name)) return true;
      final nameWords = name.split(' ').where(
            (word) =>
                word.length > 1 &&
                !const {'dr', 'doctor', 'al', 'el'}.contains(word),
          );
      return nameWords.any((word) => text.split(' ').contains(word));
    }
    return text.split(' ').contains(name);
  }
}
