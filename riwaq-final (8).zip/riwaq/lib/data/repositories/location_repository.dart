import '../../models/hospital_location.dart';
import '../location_data.dart';
import '../../services/ai/arabic_text.dart';
import '../specialty_data.dart';

class LocationRepository {
  const LocationRepository();

  static const _aliases = <String, List<String>>{
    'RECEPTION': ['reception', 'front desk', 'information desk'],
    'MAIN_ENTRANCE': ['main entrance', 'hospital entrance', 'entrance'],
    'EMERGENCY': ['emergency', 'emergency department', 'er'],
    'PHARMACY': [
      'pharmacy',
      'drugstore',
      'medicine',
      'medication',
      'prescription',
      'صيدليه',
      'دواء',
      'ادويه',
    ],
    'LABORATORY': [
      'laboratory',
      'medical laboratory',
      'blood test',
      'lab test',
      'lab',
      'مختبر',
      'تحاليل',
      'تحليل',
      'فحص دم',
    ],
    'RADIOLOGY': ['radiology', 'imaging', 'x ray', 'xray'],
    'EYE_CLINIC': [
      'eye clinic',
      'ophthalmology clinic',
      'eye department',
      'ophthalmology',
      'eyes',
    ],
    'DENTAL_CLINIC': ['dental clinic', 'dentist', 'dentistry'],
    'DERMATOLOGY': ['dermatology clinic', 'dermatology'],
  };

  List<HospitalLocation> getAll() => virtualLocations;

  HospitalLocation? byId(String? id) {
    if (id == null) return null;
    for (final location in virtualLocations) {
      if (location.id == id) return location;
    }
    return null;
  }

  /// Returns only locations tied for the most specific matching name.
  List<HospitalLocation> findMatchesByText(String input) {
    final matches = _matches(input);
    if (matches.isEmpty) return const [];
    final bestLength = matches.fold<int>(
      0,
      (best, match) => match.length > best ? match.length : best,
    );
    final seen = <String>{};
    return [
      for (final match in matches)
        if (match.length == bestLength && seen.add(match.location.id))
          match.location,
    ];
  }

  /// Returns locations in the order they appear in a phrase.
  List<HospitalLocation> findMentionedByText(String input) {
    final matches = _matches(input)
      ..sort((a, b) {
        final byPosition = a.start.compareTo(b.start);
        return byPosition != 0 ? byPosition : b.length.compareTo(a.length);
      });
    final seen = <String>{};
    return [
      for (final match in matches)
        if (seen.add(match.location.id)) match.location,
    ];
  }

  HospitalLocation? findByText(String input) {
    final matches = findMatchesByText(input);
    return matches.length == 1 ? matches.single : null;
  }

  List<({HospitalLocation location, int start, int length})> _matches(
    String input,
  ) {
    final text = normalizeArabic(input);
    if (text.isEmpty) return const [];
    final matches = <({HospitalLocation location, int start, int length})>[];
    for (final location in virtualLocations) {
      final keywords = [
        ...location.keywords,
        ...(_aliases[location.id] ?? const <String>[]),
        for (final specialty
            in specialties.where((item) => item.locationId == location.id))
          ...specialty.keywords,
      ];
      for (final keyword in keywords) {
        final normalizedKeyword = normalizeArabic(keyword);
        final start = _matchStart(text, normalizedKeyword);
        if (start != null) {
          matches.add((
            location: location,
            start: start,
            length: normalizedKeyword.length,
          ));
        }
      }
    }
    return matches;
  }

  int? _matchStart(String text, String keyword) {
    if (keyword.isEmpty) return null;
    if (keyword.contains(' ')) {
      final index = text.indexOf(keyword);
      return index < 0 ? null : index;
    }

    for (final word in RegExp(r'[\u0621-\u064A\u0660-\u0669a-z0-9]+')
        .allMatches(text)) {
      final value = word.group(0)!;
      if (value == keyword ||
          (RegExp(r'[\u0621-\u064A]').hasMatch(keyword) &&
              value.endsWith(keyword) &&
              value.length - keyword.length <= 3)) {
        return word.start;
      }
    }
    return null;
  }
}
