import '../models/doctor.dart';
import '../models/appointment.dart';
import '../models/recent_visit.dart';
import '../models/app_notification.dart';

const doctors = <Doctor>[
  Doctor(
      id: 'DOC_EYE_01',
      name: 'د. نورة العتيبي',
      specialty: 'طب العيون',
      specialtyId: 'OPHTHALMOLOGY',
      departmentId: 'EYE',
      locationId: 'EYE_CLINIC',
      floor: 1,
      availability: 'متاحة اليوم · ١١:٣٠ ص',
      initials: 'نع'),
  Doctor(
      id: 'DOC_DENTAL_01',
      name: 'د. أحمد الحربي',
      specialty: 'طب الأسنان',
      specialtyId: 'DENTISTRY',
      departmentId: 'DENTAL',
      locationId: 'DENTAL_CLINIC',
      floor: 1,
      availability: 'أقرب موعد · غداً ٩:٠٠ ص',
      initials: 'اح'),
  Doctor(
      id: 'DOC_FAMILY_01',
      name: 'د. سارة الغامدي',
      specialty: 'طب الأسرة',
      specialtyId: 'FAMILY_MEDICINE',
      departmentId: 'FAMILY_MEDICINE',
      locationId: 'RECEPTION',
      floor: 0,
      availability: 'متاحة اليوم · ١:٠٠ م',
      initials: 'سغ'),
];

const appointmentItems = <Appointment>[
  Appointment(
      id: 'APT_001',
      doctorId: 'DOC_EYE_01',
      doctorName: 'د. نورة العتيبي',
      specialty: 'طب العيون',
      date: 'الأحد، ١٥ نوفمبر',
      time: '١١:٣٠ صباحاً',
      locationId: 'EYE_CLINIC'),
  Appointment(
      id: 'APT_002',
      doctorId: 'DOC_DENTAL_01',
      doctorName: 'د. أحمد الحربي',
      specialty: 'طب الأسنان',
      date: 'الثلاثاء، ١٧ نوفمبر',
      time: '٩:٠٠ صباحاً',
      locationId: 'DENTAL_CLINIC'),
];

const recentVisits = <RecentVisit>[
  RecentVisit(
      id: 'VISIT_001',
      title: 'عيادة العيون',
      subtitle: 'د. نورة العتيبي · طب العيون',
      date: 'الأحد، ٨ نوفمبر',
      locationId: 'EYE_CLINIC',
      doctorId: 'DOC_EYE_01'),
  RecentVisit(
      id: 'VISIT_002',
      title: 'عيادة الأسنان',
      subtitle: 'د. أحمد الحربي · طب الأسنان',
      date: 'الأربعاء، ٤ نوفمبر',
      locationId: 'DENTAL_CLINIC',
      doctorId: 'DOC_DENTAL_01'),
  RecentVisit(
      id: 'VISIT_003',
      title: 'الاستقبال',
      subtitle: 'استعلامات المستشفى',
      date: 'الاثنين، ٢ نوفمبر',
      locationId: 'RECEPTION'),
];

const appNotifications = <AppNotification>[
  AppNotification(
      id: 'NOTIF_APT_001',
      title: 'تذكير بموعدك',
      message:
          'موعدك مع د. نورة العتيبي يوم الأحد، ١٥ نوفمبر الساعة ١١:٣٠ صباحاً.',
      dateLabel: 'اليوم',
      kind: AppNotificationKind.appointment,
      appointmentId: 'APT_001'),
  AppNotification(
      id: 'NOTIF_MAP_001',
      title: 'معلومة عن الزيارة',
      message: 'عيادة العيون في الدور الأول. يمكنك فتح الخريطة لمعرفة موقعها.',
      dateLabel: 'أمس',
      kind: AppNotificationKind.location,
      locationId: 'EYE_CLINIC'),
  AppNotification(
      id: 'NOTIF_GENERAL_001',
      title: 'مرحباً بك في رِواق',
      message: 'استخدم البحث أو المساعد المحلي للعثور على العيادات والخدمات.',
      dateLabel: 'قبل يومين',
      kind: AppNotificationKind.general),
];
