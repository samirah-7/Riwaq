import '../models/indoor_localization.dart';
import 'hospital_floor_plan_data.dart';

/// Reserved doorway/signage landmarks, NOT collected reference photographs.
/// Their stable identities survive camera/model/provider replacement.
final localizationLandmarks = [
  for (final floor in hospitalFloorPlans)
    for (final place in floor.selectablePlaces)
      LocalizationLandmark(
        id: 'LM_${place.id}_ENTRY',
        locationId: place.id,
        floorId: floor.id,
        descriptionAr:
            'مدخل / لوحة ${place.nameAr} — مرجع بصري مطلوب جمعه واعتماده',
      ),
];
