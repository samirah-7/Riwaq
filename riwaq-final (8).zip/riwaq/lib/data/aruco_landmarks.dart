class ArucoLandmarkDefinition {
  const ArucoLandmarkDefinition({
    required this.markerId,
    required this.locationId,
  });

  final int markerId;
  final String locationId;
}

/// Marker-to-node associations for the conceptual, simulated map only.
const arucoLandmarks = <ArucoLandmarkDefinition>[
  ArucoLandmarkDefinition(markerId: 0, locationId: 'MAIN_ENTRANCE'),
  ArucoLandmarkDefinition(markerId: 1, locationId: 'RECEPTION'),
  ArucoLandmarkDefinition(markerId: 2, locationId: 'RADIOLOGY'),
  ArucoLandmarkDefinition(markerId: 3, locationId: 'EYE_CLINIC'),
];

String? locationIdForArucoMarker(int markerId) {
  for (final landmark in arucoLandmarks) {
    if (landmark.markerId == markerId) return landmark.locationId;
  }
  return null;
}
