import 'package:flutter/material.dart';

class RiwaqColors {
  static bool _darkMode = false;

  static set darkMode(bool value) => _darkMode = value;
  static const primary = Color(0xFF2E9F7F);
  static Color get primaryDark =>
      _darkMode ? const Color(0xFF83DDBA) : const Color(0xFF20785F);
  static Color get mint =>
      _darkMode ? const Color(0xFF203C32) : const Color(0xFFE8F6F1);
  static Color get background =>
      _darkMode ? const Color(0xFF101A17) : const Color(0xFFF8FFFD);
  static Color get surface =>
      _darkMode ? const Color(0xFF1A2924) : Colors.white;
  static Color get modelCanvas =>
      _darkMode ? const Color(0xFF121F1A) : const Color(0xFFEDF5F2);
  static Color get text =>
      _darkMode ? const Color(0xFFEAF4F0) : const Color(0xFF193B34);
  static Color get muted =>
      _darkMode ? const Color(0xFFB7C9C1) : const Color(0xFF52645E);
  static Color get border =>
      _darkMode ? const Color(0xFF3B5147) : const Color(0xFFE4EFEB);
  static const orange = Color(0xFFF2A65A);
  static const blue = Color(0xFF6C9BD2);
}

class AppTheme {
  static ThemeData get light => _buildTheme(dark: false);
  static ThemeData get dark => _buildTheme(dark: true);

  static ThemeData _buildTheme({required bool dark}) {
    final background =
        dark ? const Color(0xFF101A17) : const Color(0xFFF8FFFD);
    final surface = dark ? const Color(0xFF1A2924) : Colors.white;
    final foreground =
        dark ? const Color(0xFFEAF4F0) : const Color(0xFF193B34);
    final muted = dark ? const Color(0xFFB7C9C1) : const Color(0xFF52645E);
    final border = dark ? const Color(0xFF3B5147) : const Color(0xFFE4EFEB);
    final accent = dark ? const Color(0xFF83DDBA) : const Color(0xFF20785F);
    final primary = dark ? const Color(0xFF72D5B1) : const Color(0xFF20785F);
    final onPrimary = dark ? const Color(0xFF10251D) : Colors.white;
    final mint = dark ? const Color(0xFF203C32) : const Color(0xFFE8F6F1);
    final brightness = dark ? Brightness.dark : Brightness.light;
    final scheme = ColorScheme.fromSeed(
      seedColor: RiwaqColors.primary,
      brightness: brightness,
      primary: primary,
      onPrimary: onPrimary,
      primaryContainer: mint,
      onPrimaryContainer:
          dark ? const Color(0xFFD1F7E7) : const Color(0xFF193B34),
      secondary: accent,
      onSecondary: dark ? const Color(0xFF10251D) : Colors.white,
      surface: surface,
      onSurface: foreground,
      onSurfaceVariant: muted,
      outline: border,
      outlineVariant: border,
      error: dark ? const Color(0xFFFFB4AB) : const Color(0xFFB3261E),
      onError: dark ? const Color(0xFF690005) : Colors.white,
    );
    final textTheme = ThemeData(brightness: brightness).textTheme.apply(
          bodyColor: foreground,
          displayColor: foreground,
        );
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: border),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      canvasColor: surface,
      dividerColor: border,
      disabledColor: muted.withAlpha(150),
      fontFamily: '29LT Bukra',
      textTheme: textTheme.copyWith(
        bodySmall: textTheme.bodySmall?.copyWith(color: muted),
        labelSmall: textTheme.labelSmall?.copyWith(color: muted),
      ),
      iconTheme: IconThemeData(color: scheme.onSurfaceVariant),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: foreground,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        hintStyle: TextStyle(color: muted),
        labelStyle: TextStyle(color: muted),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: fieldBorder,
        enabledBorder: fieldBorder,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: primary, width: 1.5),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: surface,
        contentTextStyle: TextStyle(color: foreground),
        actionTextColor: primary,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: textTheme.titleLarge?.copyWith(
          color: foreground,
          fontFamily: '29LT Bukra',
        ),
        contentTextStyle:
            textTheme.bodyMedium?.copyWith(color: foreground),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: primary,
        selectionColor: primary.withAlpha(64),
        selectionHandleColor: primary,
      ),
    );
  }
}
