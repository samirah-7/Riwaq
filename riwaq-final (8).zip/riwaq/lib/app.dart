import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'data/location_data.dart';
import 'data/mock_data.dart';
import 'models/app_notification.dart';
import 'screens/appointment_detail_screen.dart';
import 'screens/appointments_screen.dart';
import 'screens/assistant_screen.dart';
import 'screens/doctor_detail_screen.dart';
import 'screens/doctors_screen.dart';
import 'screens/help_screen.dart';
import 'screens/home_screen.dart';
import 'screens/map_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/recent_visits_screen.dart';
import 'screens/saved_locations_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/vision_screen.dart';
import 'l10n/riwaq_text.dart';
import 'services/location_state.dart';
import 'services/riwaq_local_store.dart';
import 'theme/app_theme.dart';
import 'widgets/riwaq_bottom_nav.dart';
import 'widgets/riwaq_drawer.dart';
import 'widgets/riwaq_page_header.dart';

class RiwaqApp extends StatelessWidget {
  const RiwaqApp({super.key});

  @override
  Widget build(BuildContext context) {
    final store = RiwaqLocalStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        RiwaqColors.darkMode = store.darkMode;
        final locale = Locale(store.languageCode);
        return MaterialApp(
          title: store.languageCode == 'en' ? 'Riwaq' : 'رِواق',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: store.darkMode ? ThemeMode.dark : ThemeMode.light,
          locale: locale,
          supportedLocales: const [Locale('ar'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          builder: (context, child) => Directionality(
            textDirection: store.languageCode == 'ar'
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: child ?? const SizedBox.shrink(),
          ),
          home: const AppShell(),
        );
      },
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _SecondaryPage {
  const _SecondaryPage({
    required this.keyName,
    required this.title,
    required this.widget,
    this.drawerDestination,
  });

  final String keyName;
  final String title;
  final Widget widget;
  final RiwaqDrawerDestination? drawerDestination;
}

class _AppShellState extends State<AppShell> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  int _tabIndex = 0;
  String? _doctorSpecialty;
  final List<_SecondaryPage> _secondaryPages = [];
  RiwaqDrawerDestination? _selectedDrawerDestination;

  void _openDrawer() => _scaffoldKey.currentState?.openDrawer();

  void _pushPage({
    required String keyName,
    required String title,
    required Widget widget,
    RiwaqDrawerDestination? drawerDestination,
  }) {
    if (_secondaryPages.isNotEmpty && _secondaryPages.last.keyName == keyName) {
      return;
    }
    final inheritedDestination = drawerDestination ??
        (_secondaryPages.isNotEmpty
            ? _secondaryPages.last.drawerDestination
            : null);
    setState(() {
      _secondaryPages.add(
        _SecondaryPage(
          keyName: keyName,
          title: title,
          widget: widget,
          drawerDestination: inheritedDestination,
        ),
      );
      _selectedDrawerDestination = inheritedDestination;
    });
  }

  void _back() {
    if (_secondaryPages.isNotEmpty) {
      setState(() {
        _secondaryPages.removeLast();
        _selectedDrawerDestination = _secondaryPages.isEmpty
            ? null
            : _secondaryPages.last.drawerDestination;
      });
    } else if (_tabIndex != 0) {
      setState(() => _tabIndex = 0);
    }
  }

  void _selectMainTab(int index) {
    if (index < 0 || index > 3) return;
    setState(() {
      _tabIndex = index;
      _secondaryPages.clear();
      _selectedDrawerDestination = null;
    });
  }

  String _secondaryPageTitle(_SecondaryPage page) {
    final title = switch (page.keyName) {
      'notifications' => riwaqText('الإشعارات', 'Notifications'),
      'recent-visits' => riwaqText('آخر الزيارات', 'Recent visits'),
      'saved-locations' => riwaqText('العناوين المحفوظة', 'Saved locations'),
      'profile' => riwaqText('الملف الشخصي', 'Profile'),
      'settings' => riwaqText('الإعدادات', 'Settings'),
      'help' => riwaqText('المساعدة والدعم', 'Help and support'),
      'vision' => riwaqText('التعرّف البصري', 'Camera landmarks'),
      _ when page.keyName.startsWith('doctors-') =>
        riwaqText('الأطباء والتخصصات', 'Doctors and specialties'),
      _ when page.keyName.startsWith('doctor-detail-') =>
        riwaqText('تفاصيل الطبيب', 'Doctor details'),
      _ when page.keyName.startsWith('appointment-detail-') =>
        riwaqText('تفاصيل الموعد', 'Appointment details'),
      _ => page.title,
    };
    return title;
  }

  void _openMap([String? destinationId]) {
    if (destinationId != null) {
      final location = virtualLocations
          .where((item) => item.id == destinationId)
          .firstOrNull;
      if (location != null) {
        RiwaqLocationState.instance.setDestination(
          locationId: location.id,
          floor: location.floor,
        );
      }
    }
    _selectMainTab(1);
  }

  void _openDoctors([String? specialtyId]) {
    _doctorSpecialty = specialtyId;
    final keyName =
        specialtyId == null ? 'doctors-all' : 'doctors-$specialtyId';
    _pushPage(
      keyName: keyName,
      title: riwaqText('الأطباء والتخصصات', 'Doctors and specialties'),
      drawerDestination: RiwaqDrawerDestination.doctors,
      widget: DoctorsScreen(
        key: ValueKey(keyName),
        initialSpecialtyId: specialtyId,
        onOpenMap: _openMap,
        onOpenDoctorDetails: _openDoctorDetails,
      ),
    );
  }

  void _openDoctorDetails(String doctorId) {
    _pushPage(
      keyName: 'doctor-detail-$doctorId',
      title: riwaqText('تفاصيل الطبيب', 'Doctor details'),
      widget: DoctorDetailScreen(doctorId: doctorId, onOpenMap: _openMap),
    );
  }

  void _openAppointmentDetails(String appointmentId) {
    _pushPage(
      keyName: 'appointment-detail-$appointmentId',
      title: riwaqText('تفاصيل الموعد', 'Appointment details'),
      widget: AppointmentDetailScreen(
        appointmentId: appointmentId,
        onOpenMap: _openMap,
        onOpenDoctor: _openDoctorDetails,
      ),
    );
  }

  void _openNotifications() {
    if (_secondaryPages.isNotEmpty &&
        _secondaryPages.last.keyName == 'notifications') {
      return;
    }
    _pushPage(
      keyName: 'notifications',
      title: riwaqText('الإشعارات', 'Notifications'),
      drawerDestination: RiwaqDrawerDestination.notifications,
      widget: NotificationsScreen(
        onOpenMap: _openMap,
        onOpenAppointment: _openAppointmentDetails,
      ),
    );
  }

  void _openRecentVisits() => _pushPage(
        keyName: 'recent-visits',
        title: riwaqText('آخر الزيارات', 'Recent visits'),
        drawerDestination: RiwaqDrawerDestination.recentVisits,
        widget: RecentVisitsScreen(
          onOpenMap: _openMap,
          onOpenDoctor: _openDoctorDetails,
        ),
      );

  void _openSavedLocations() => _pushPage(
        keyName: 'saved-locations',
        title: riwaqText('العناوين المحفوظة', 'Saved locations'),
        drawerDestination: RiwaqDrawerDestination.savedLocations,
        widget: SavedLocationsScreen(onOpenMap: _openMap),
      );

  void _openProfile() => _pushPage(
        keyName: 'profile',
        title: riwaqText('الملف الشخصي', 'Profile'),
        drawerDestination: RiwaqDrawerDestination.profile,
        widget: ProfileScreen(
          onOpenRecentVisits: _openRecentVisits,
          onOpenSavedLocations: _openSavedLocations,
          onOpenNotifications: _openNotifications,
          onOpenSettings: _openSettings,
          onOpenHelp: _openHelp,
        ),
      );

  void _openSettings() => _pushPage(
        keyName: 'settings',
        title: riwaqText('الإعدادات', 'Settings'),
        drawerDestination: RiwaqDrawerDestination.settings,
        widget: SettingsScreen(onOpenHelp: _openHelp),
      );

  void _openHelp() => _pushPage(
        keyName: 'help',
        title: riwaqText('المساعدة والدعم', 'Help and support'),
        drawerDestination: RiwaqDrawerDestination.help,
        widget: const HelpScreen(),
      );

  void _openVision() => _pushPage(
        keyName: 'vision',
        title: riwaqText('التعرّف البصري', 'Camera landmarks'),
        widget: VisionScreen(onOpenMap: _openMap),
      );

  void _selectDrawerDestination(RiwaqDrawerDestination destination) {
    switch (destination) {
      case RiwaqDrawerDestination.doctors:
        _openDoctors(_doctorSpecialty);
        break;
      case RiwaqDrawerDestination.recentVisits:
        _openRecentVisits();
        break;
      case RiwaqDrawerDestination.savedLocations:
        _openSavedLocations();
        break;
      case RiwaqDrawerDestination.profile:
        _openProfile();
        break;
      case RiwaqDrawerDestination.notifications:
        _openNotifications();
        break;
      case RiwaqDrawerDestination.settings:
        _openSettings();
        break;
      case RiwaqDrawerDestination.help:
        _openHelp();
        break;
    }
  }

  List<Widget> _mainScreens() => [
        HomeScreen(
          key: const ValueKey('home'),
          onOpenMap: _openMap,
          onOpenDoctors: _openDoctors,
          onOpenAssistant: () => _selectMainTab(3),
          onOpenAppointments: () => _selectMainTab(2),
          onOpenVision: _openVision,
          onOpenAppointmentDetails: _openAppointmentDetails,
          onOpenRecentVisits: _openRecentVisits,
          onOpenSavedLocations: _openSavedLocations,
        ),
        const MapScreen(key: ValueKey('map')),
        AppointmentsScreen(
          key: const ValueKey('appointments'),
          onOpenMap: _openMap,
          onOpenDetails: _openAppointmentDetails,
        ),
        AssistantScreen(
          key: const ValueKey('assistant'),
          onOpenMap: _openMap,
          onOpenDoctors: _openDoctors,
          onOpenAppointments: () => _selectMainTab(2),
          onOpenDoctorDetails: _openDoctorDetails,
        ),
      ];

  @override
  Widget build(BuildContext context) {
    final store = RiwaqLocalStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final isHome = _secondaryPages.isEmpty && _tabIndex == 0;
        final title = _secondaryPages.isNotEmpty
            ? _secondaryPageTitle(_secondaryPages.last)
            : [
                riwaqText('مرحباً بك في رِواق', 'Welcome to Riwaq'),
                riwaqText('الخريطة', 'Map'),
                riwaqText('مواعيدي', 'Appointments'),
                riwaqText('المساعد رِواق', 'Riwaq assistant')
              ][_tabIndex];
        final subtitle = isHome
            ? riwaqText('طريقك للرعاية · ${store.profileName}',
                'Your path to care · ${store.profileName}')
            : _secondaryPages.isEmpty && _tabIndex == 3
                ? riwaqText('مساعد محلي · لا يتصل بمزود ذكاء اصطناعي خارجي',
                    'Assistant uses the configured AI service or local fallback')
                : null;
        final unreadCount = store.notificationsEnabled
            ? appNotifications
                .where((item) =>
                    !store.dismissedNotificationIds.contains(item.id) &&
                    !store.readNotificationIds.contains(item.id) &&
                    (item.kind != AppNotificationKind.appointment ||
                        store.appointmentRemindersEnabled))
                .length
            : 0;

        final secondaryStack = _secondaryPages.isEmpty
            ? const <Widget>[SizedBox.shrink()]
            : _secondaryPages
                .map((page) => KeyedSubtree(
                    key: ValueKey(page.keyName), child: page.widget))
                .toList();

        return PopScope(
          canPop: _secondaryPages.isEmpty && _tabIndex == 0,
          onPopInvokedWithResult: (didPop, result) {
            if (!didPop) _back();
          },
          child: Scaffold(
            key: _scaffoldKey,
            drawer: RiwaqDrawer(
              selected: _selectedDrawerDestination,
              displayName: store.profileName,
              onSelect: _selectDrawerDestination,
            ),
            body: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  RiwaqPageHeader(
                    title: title,
                    subtitle: subtitle,
                    showLogo: isHome,
                    unreadCount: unreadCount,
                    onOpenMenu: _openDrawer,
                    onOpenNotifications: _openNotifications,
                    onBack: _secondaryPages.isEmpty ? null : _back,
                  ),
                  Expanded(
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: Offstage(
                            offstage: _secondaryPages.isNotEmpty,
                            child: TickerMode(
                              enabled: _secondaryPages.isEmpty,
                              child: IndexedStack(
                                  index: _tabIndex, children: _mainScreens()),
                            ),
                          ),
                        ),
                        Positioned.fill(
                          child: Offstage(
                            offstage: _secondaryPages.isEmpty,
                            child: TickerMode(
                              enabled: _secondaryPages.isNotEmpty,
                              child: IndexedStack(
                                  index: secondaryStack.length - 1,
                                  children: secondaryStack),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            bottomNavigationBar: RiwaqBottomNav(
              currentIndex: _tabIndex,
              onTap: _selectMainTab,
            ),
          ),
        );
      },
    );
  }
}
