import 'package:flutter/material.dart';

import '../data/repositories/appointment_repository.dart';
import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({
    super.key,
    required this.onOpenMap,
    required this.onOpenDetails,
  });

  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String> onOpenDetails;

  @override
  Widget build(BuildContext context) {
    final appointments = const AppointmentRepository().getAll();
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
      children: [
        Text(riwaqText('تابع مواعيدك وخطّط لزيارتك القادمة.',
            'Review your appointments and plan your next visit.'),
            style: TextStyle(color: RiwaqColors.muted)),
        const SizedBox(height: 18),
        if (appointments.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
                color: RiwaqColors.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: RiwaqColors.border)),
            child: Column(
              children: [
                Icon(Icons.event_busy_outlined,
                    color: RiwaqColors.muted, size: 34),
                SizedBox(height: 8),
                Text(riwaqText('لا توجد مواعيد قادمة', 'No upcoming appointments'),
                    style: TextStyle(
                        fontWeight: FontWeight.w800, color: RiwaqColors.text)),
                SizedBox(height: 4),
                Text(riwaqText('ستظهر مواعيدك هنا عند توفرها.',
                    'Your appointments will appear here when available.'),
                    style: TextStyle(color: RiwaqColors.muted, fontSize: 12)),
              ],
            ),
          ),
        for (final appointment in appointments)
          Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => onOpenDetails(appointment.id),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.calendar_month_outlined,
                            color: RiwaqColors.primary),
                        const SizedBox(width: 8),
                        Expanded(
                            child: Text(riwaqLocalizedValue(appointment.date),
                                style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: RiwaqColors.text))),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 9, vertical: 5),
                          decoration: BoxDecoration(
                              color: RiwaqColors.mint,
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(riwaqLocalizedValue(appointment.status),
                               style: TextStyle(
                                  color: RiwaqColors.primaryDark,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                    Divider(height: 22, color: RiwaqColors.border),
                    Text(riwaqLocalizedValue(appointment.doctorName),
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: RiwaqColors.text)),
                    const SizedBox(height: 4),
                    Text(riwaqLocalizedValue(appointment.specialty),
                        style: TextStyle(color: RiwaqColors.muted)),
                    const SizedBox(height: 8),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final time = Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.access_time_rounded,
                                size: 16, color: RiwaqColors.primary),
                            const SizedBox(width: 6),
                            Text(riwaqLocalizedValue(appointment.time),
                                style: TextStyle(color: RiwaqColors.text)),
                          ],
                        );
                        final actions = Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextButton(
                              onPressed: () => onOpenDetails(appointment.id),
                              child: Text(riwaqText('التفاصيل', 'Details')),
                            ),
                            IconButton(
                               tooltip: riwaqText('الوصول إلى الموعد', 'Open appointment location'),
                              onPressed: () =>
                                  onOpenMap(appointment.locationId),
                              icon: const Icon(Icons.directions_outlined,
                                  color: RiwaqColors.primary),
                            ),
                          ],
                        );
                        if (constraints.maxWidth < 390) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              time,
                              Align(
                                  alignment: AlignmentDirectional.centerEnd,
                                  child: actions),
                            ],
                          );
                        }
                        return Row(
                          children: [
                            time,
                            const Spacer(),
                            actions,
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        const SizedBox(height: 4),
        Text(
          riwaqText(
            'المواعيد المعروضة بيانات توضيحية؛ لا يوجد اتصال بنظام حجز المستشفى.',
            'Appointments are sample data and are not connected to a hospital booking system.',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: RiwaqColors.muted, fontSize: 11),
        ),
      ],
    );
  }
}
