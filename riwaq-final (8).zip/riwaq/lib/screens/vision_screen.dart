import 'dart:io';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

import '../data/aruco_landmarks.dart';
import '../data/repositories/location_repository.dart';
import '../models/hospital_location.dart';
import '../l10n/riwaq_text.dart';
import '../services/location_state.dart';
import '../services/vision/aruco_landmark_recognizer.dart';
import '../theme/app_theme.dart';

class VisionScreen extends StatefulWidget {
  const VisionScreen({super.key, required this.onOpenMap});
  final VoidCallback onOpenMap;

  @override
  State<VisionScreen> createState() => _VisionScreenState();
}

class _VisionScreenState extends State<VisionScreen>
    with WidgetsBindingObserver {
  final recognizer = ArucoLandmarkRecognizer();
  final locationRepository = const LocationRepository();
  CameraController? camera;
  bool initializing = true;
  bool processing = false;
  bool loadingMarker = false;
  String? error;
  ArucoRecognitionResult? result;
  HospitalLocation? matchedLocation;
  Uint8List? markerPreview;
  int selectedMarkerId = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
    _loadMarkerPreview();
  }

  Future<void> _loadMarkerPreview() async {
    setState(() => loadingMarker = true);
    final image = await recognizer.generateMarkerPng(selectedMarkerId);
    if (!mounted) return;
    setState(() {
      markerPreview = image;
      loadingMarker = false;
    });
  }

  Future<void> _initializeCamera() async {
    setState(() {
      initializing = true;
      error = null;
    });
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        throw CameraException('NoCamera', 'No camera is available.');
      }
      final next = CameraController(cameras.first, ResolutionPreset.medium,
          enableAudio: false);
      await next.initialize();
      if (!mounted) {
        await next.dispose();
        return;
      }
      await camera?.dispose();
      setState(() {
        camera = next;
        initializing = false;
      });
    } on CameraException catch (exception) {
      if (!mounted) {
        return;
      }
      setState(() {
        initializing = false;
        error = switch (exception.code) {
          'CameraAccessDenied' ||
          'CameraAccessDeniedWithoutPrompt' =>
            riwaqText(
              'تم رفض إذن الكاميرا. فعّل الإذن من إعدادات الجهاز ثم أعد المحاولة.',
              'Camera permission was denied. Enable it in device settings and retry.',
            ),
          'NoCamera' =>
            riwaqText('لا توجد كاميرا متاحة.', 'No camera is available.'),
          _ => riwaqText(
              'تعذر تشغيل الكاميرا. تحقق من الإذن أو أعد المحاولة.',
              'The camera could not start. Check permission and retry.',
            ),
        };
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          initializing = false;
          error = riwaqText(
            'تعذر تشغيل الكاميرا. تحقق من الإذن أو أعد المحاولة.',
            'The camera could not start. Check permission and retry.',
          );
        });
      }
    }
  }

  Future<void> _captureAndRecognize() async {
    final activeCamera = camera;
    if (activeCamera == null ||
        !activeCamera.value.isInitialized ||
        processing) {
      return;
    }
    setState(() {
      processing = true;
      error = null;
      result = null;
      matchedLocation = null;
    });
    XFile? capture;
    try {
      capture = await activeCamera.takePicture();
      final recognition =
          await recognizer.recognizeBytes(await capture.readAsBytes());
      if (!mounted) {
        return;
      }
      final locationId = recognition.status == ArucoRecognitionStatus.recognized
          ? recognition.locationId
          : null;
      final location = locationRepository.byId(locationId);
      applyArucoRecognitionToLocation(
        result: recognition,
        repository: locationRepository,
      );
      setState(() {
        result = recognition;
        matchedLocation = location;
        processing = false;
      });
    } on CameraException catch (exception) {
      if (mounted) {
        setState(() {
          processing = false;
          error = exception.code.contains('AccessDenied')
              ? riwaqText(
                  'إذن الكاميرا غير متاح. راجع إعدادات الجهاز.',
                  'Camera permission is unavailable. Check device settings.',
                )
              : riwaqText(
                  'تعذر التقاط الصورة. حاول مرة أخرى.',
                  'Could not capture an image. Please retry.',
                );
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          processing = false;
          error = riwaqText(
            'تعذرت معالجة الصورة. حاول مرة أخرى.',
            'Could not process the image. Please retry.',
          );
        });
      }
    } finally {
      if (capture != null) {
        try {
          await File(capture.path).delete();
        } catch (_) {/* Temporary cache cleanup is best-effort. */}
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final activeCamera = camera;
    if (activeCamera == null || !activeCamera.value.isInitialized) return;
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      activeCamera.dispose();
      camera = null;
    } else if (state == AppLifecycleState.resumed) {
      _initializeCamera();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    camera?.dispose();
    super.dispose();
  }

  String _currentPlaceName() {
    final current =
        locationRepository.byId(RiwaqLocationState.instance.currentLocationId);
    return current == null
        ? riwaqText('غير محدد', 'Not set')
        : riwaqPlaceName(current.id, current.nameAr);
  }

  String _currentSourceName() =>
      switch (RiwaqLocationState.instance.currentLocationSource) {
        RiwaqLocationSource.visualMarker =>
          riwaqText('علامة ArUco تقريبية', 'Approximate ArUco marker'),
        RiwaqLocationSource.gpsApproximate =>
          riwaqText('GPS خارجي تقريبي', 'Approximate outdoor GPS'),
        RiwaqLocationSource.simulated =>
          riwaqText('اختيار تجريبي يدوي', 'Manual simulated selection'),
      };

  Widget _markerGuide() => Container(
        margin: const EdgeInsets.only(top: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: RiwaqColors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: RiwaqColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              riwaqText('علامات تجريبية للخريطة', 'Sample map markers'),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              riwaqText(
                'اختر علامة لعرضها وطباعتها للاختبار. ارتباط العلامات بالمواقع تصوري فقط ولم يُتحقق منه ميدانيًا.',
                'Select a marker to display and print for testing. Marker-to-place links are conceptual and have not been verified on site.',
              ),
              style: TextStyle(
                  fontSize: 12, color: RiwaqColors.muted, height: 1.45),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final landmark in arucoLandmarks)
                  ChoiceChip(
                    label: Text(
                      '#${landmark.markerId} · ${riwaqPlaceName(
                        landmark.locationId,
                        locationRepository.byId(landmark.locationId)?.nameAr ??
                            landmark.locationId,
                      )}',
                    ),
                    selected: selectedMarkerId == landmark.markerId,
                    onSelected: (_) {
                      setState(() => selectedMarkerId = landmark.markerId);
                      _loadMarkerPreview();
                    },
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Center(
              child: loadingMarker
                  ? const Padding(
                      padding: EdgeInsets.all(28),
                      child: CircularProgressIndicator(),
                    )
                  : markerPreview != null
                      ? Image.memory(
                          markerPreview!,
                          width: 220,
                          height: 220,
                          filterQuality: FilterQuality.none,
                          errorBuilder: (_, __, ___) => Text(riwaqText(
                            'تعذر عرض العلامة التجريبية.',
                            'Could not display the sample marker.',
                          )),
                        )
                      : Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: Text(
                            riwaqText(
                              'توليد العلامات والتعرّف عليها متاح على Android فقط.',
                              'Marker generation and recognition are available on Android only.',
                            ),
                            textAlign: TextAlign.center,
                            style: TextStyle(color: RiwaqColors.muted),
                          ),
                        ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
            children: [
              Text(
                riwaqText(
                  'وجّه الكاميرا نحو علامة ArUco تجريبية ثم التقط صورة. تُعالج الصورة محليًا على Android.',
                  'Point the camera at a sample ArUco marker and capture it. The image is processed locally on Android.',
                ),
                style: TextStyle(color: RiwaqColors.muted),
              ),
              const SizedBox(height: 14),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: AspectRatio(
                  aspectRatio: 4 / 3,
                  child: initializing
                      ? const ColoredBox(
                          color: Colors.black87,
                          child: Center(
                              child: CircularProgressIndicator(
                                  color: Colors.white)))
                      : camera != null && camera!.value.isInitialized
                          ? CameraPreview(camera!)
                          : ColoredBox(
                              color: Colors.black87,
                              child: Center(
                                  child: Padding(
                                      padding: const EdgeInsets.all(20),
                                      child: Text(
                                          error ??
                                              riwaqText(
                                                'الكاميرا غير متاحة.',
                                                'Camera is unavailable.',
                                              ),
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                              color: Colors.white))))),
                ),
              ),
              const SizedBox(height: 12),
              if (error != null)
                Text(error!, style: const TextStyle(color: Colors.red)),
              Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: camera == null || processing
                        ? null
                        : _captureAndRecognize,
                    icon: processing
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.camera_alt_outlined),
                    label: Text(
                      processing
                          ? riwaqText('جارٍ تحليل الصورة', 'Analyzing image')
                          : riwaqText('التقاط وتحليل', 'Capture and analyze'),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton(
                    tooltip:
                        riwaqText('إعادة تشغيل الكاميرا', 'Restart camera'),
                    onPressed: initializing ? null : _initializeCamera,
                    icon: const Icon(Icons.refresh)),
              ]),
              if (result != null)
                _RecognitionCard(
                    result: result!,
                    location: matchedLocation,
                    onOpenMap: widget.onOpenMap),
              Container(
                margin: const EdgeInsets.only(top: 14),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: RiwaqColors.surface,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  riwaqText(
                    'مصدر الموقع الحالي: ${_currentSourceName()} · ${_currentPlaceName()}',
                    'Current location source: ${_currentSourceName()} · ${_currentPlaceName()}',
                  ),
                  style: const TextStyle(fontSize: 12),
                ),
              ),
              _markerGuide(),
              const SizedBox(height: 12),
              Text(
                riwaqText(
                  'هذا نموذج تجريبي: العلامات والمواقع والمسارات بيانات تصورية غير متحقق منها. مؤشر جودة التعرف ليس قياسًا لدقة الموقع، ولا تُرفع الصور أو تُحفظ.',
                  'Prototype only: markers, places, and routes are conceptual and unverified. The recognition-quality indicator is not a location-accuracy measurement. Images are not uploaded or saved.',
                ),
                style: TextStyle(
                    fontSize: 12, color: RiwaqColors.muted, height: 1.5),
              ),
            ]),
      );
}

class _RecognitionCard extends StatelessWidget {
  const _RecognitionCard(
      {required this.result, required this.location, required this.onOpenMap});
  final ArucoRecognitionResult result;
  final HospitalLocation? location;
  final VoidCallback onOpenMap;

  @override
  Widget build(BuildContext context) {
    final placeName = location == null
        ? null
        : riwaqPlaceName(location!.id, location!.nameAr);
    final floorName = location == null
        ? null
        : riwaqText(
            switch (location!.floor) {
              0 => 'الأرضي',
              1 => 'الأول',
              2 => 'الثاني',
              _ => 'الدور ${location!.floor}',
            },
            switch (location!.floor) {
              0 => 'Ground floor',
              1 => 'First floor',
              2 => 'Second floor',
              _ => 'Floor ${location!.floor}',
            },
          );
    final (title, detail) = switch (result.status) {
      ArucoRecognitionStatus.recognized when location != null => (
          riwaqText(
            'تم التعرف على علامة خريطة تجريبية',
            'Sample map marker recognized',
          ),
          riwaqText(
            'العلامة #${result.markerId} مرتبطة بـ $placeName · $floorName. هذا تحديد لعقدة تجريبية وليس قياسًا دقيقًا للموقع.',
            'Marker #${result.markerId} is linked to $placeName · $floorName. This selects a simulated map node; it is not a precise position measurement.',
          ),
        ),
      ArucoRecognitionStatus.noMarker => (
          riwaqText('لم يتم العثور على علامة', 'No marker found'),
          riwaqText(
            'لم يتغير موقعك الحالي. أظهر علامة تجريبية بوضوح وحاول مجددًا.',
            'Your current location was not changed. Show a sample marker clearly and try again.',
          ),
        ),
      ArucoRecognitionStatus.unknownMarker => (
          riwaqText('علامة غير مرتبطة بالخريطة', 'Marker is not mapped'),
          riwaqText(
            'تم العثور على العلامة #${result.markerId}، لكنها غير مرتبطة بعقدة معروفة. لم يتغير موقعك.',
            'Marker #${result.markerId} was found, but it is not linked to a known map node. Your location was not changed.',
          ),
        ),
      ArucoRecognitionStatus.lowQuality => (
          riwaqText('العلامة غير واضحة بما يكفي', 'Marker is not clear enough'),
          riwaqText(
            'لم تجتز العلامة #${result.markerId} حد حجم وجودة الصورة؛ لم يتغير موقعك.',
            'Marker #${result.markerId} did not meet the image-size and quality thresholds. Your location was not changed.',
          ),
        ),
      ArucoRecognitionStatus.unsupported => (
          riwaqText(
              'التعرّف غير متاح على هذا الجهاز', 'Recognition unavailable'),
          riwaqText(
            'يحتاج فحص ArUco إلى نسخة Android التي تتضمن OpenCV. استخدم اختيار الموقع اليدوي أو GPS التقريبي.',
            'ArUco scanning requires the Android build with OpenCV. Use manual location selection or approximate GPS instead.',
          ),
        ),
      ArucoRecognitionStatus.error => (
          riwaqText('تعذر تحليل العلامة', 'Could not analyze marker'),
          riwaqText(
            'لم يتغير موقعك. حاول التقاط صورة أخرى.',
            'Your location was not changed. Capture another image and retry.',
          ),
        ),
      _ => (
          riwaqText('لم يتم تحديد الموقع', 'Location not changed'),
          riwaqText(
            'لم تتوفر مطابقة موثوقة؛ لم يتغير موقعك.',
            'No reliable match was available; your location was not changed.',
          ),
        ),
    };
    return Container(
        margin: const EdgeInsets.only(top: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: RiwaqColors.surface,
            borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title,
              style: TextStyle(
                  fontWeight: FontWeight.w900, color: RiwaqColors.primaryDark)),
          const SizedBox(height: 6),
          Text(detail),
          if (result.qualityScore != null)
            Text(
              riwaqText(
                'مؤشر جودة الصورة: ${(result.qualityScore! * 100).round()}% · تقدير هندسي تقريبي وليس احتمالًا أو دقة موقع.',
                'Image-quality indicator: ${(result.qualityScore! * 100).round()}% · a geometric heuristic, not a probability or location accuracy.',
              ),
              style: TextStyle(fontSize: 11, color: RiwaqColors.muted),
            ),
          if (location != null)
            Padding(
                padding: const EdgeInsets.only(top: 10),
                child: FilledButton.icon(
                    onPressed: onOpenMap,
                    icon: const Icon(Icons.map_outlined),
                    label: Text(riwaqText('افتح الخريطة الافتراضية',
                        'Open the conceptual map')))),
        ]));
  }
}
