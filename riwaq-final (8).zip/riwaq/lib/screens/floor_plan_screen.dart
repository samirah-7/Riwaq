import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/repositories/doctor_repository.dart';
import '../data/hospital_floor_plan_data.dart';
import '../l10n/riwaq_text.dart';
import '../models/hospital_floor_plan.dart';
import '../models/navigation_instruction.dart';
import '../services/approximate_gps_service.dart';
import '../services/hospital_floor_plan_editor.dart';
import '../services/hospital_route_service.dart';
import '../services/route_instruction_service.dart';
import '../services/location_provider.dart';
import '../services/location_state.dart';
import '../services/riwaq_local_store.dart';
import '../theme/app_theme.dart';
import '../widgets/hospital_plan_2d.dart';
import '../widgets/hospital_model_3d.dart';

/// Both renderers consume a single selection, route and architectural registry.
class FloorPlanScreen extends StatefulWidget {
  const FloorPlanScreen(
      {super.key,
      required this.onOpenMap,
      required this.destinationLocationId,
      this.localizationProvider,
      this.gpsService = const GeolocatorApproximateGpsService()});
  final ValueChanged<String> onOpenMap;
  final String? destinationLocationId;
  final IndoorLocalizationProvider? localizationProvider;
  final ApproximateGpsService gpsService;
  @override
  State<FloorPlanScreen> createState() => _FloorPlanScreenState();
}

enum _NavigationStatus { idle, active, paused, cancelled, completed }

class _FloorImportChange {
  const _FloorImportChange({
    required this.floor,
    required this.added,
    required this.removed,
    required this.updated,
    required this.edgeChanges,
  });

  final HospitalFloorPlan floor;
  final List<FloorPlanPlace> added;
  final List<FloorPlanPlace> removed;
  final List<FloorPlanPlace> updated;
  final int edgeChanges;
}

class _MapSearchResult {
  const _MapSearchResult({
    required this.value,
    required this.place,
    required this.label,
    required this.subtitle,
    required this.searchableText,
  });

  final String value;
  final FloorPlanPlace place;
  final String label;
  final String subtitle;
  final String searchableText;
}

class _FloorPlanScreenState extends State<FloorPlanScreen> {
  Color get _mapStatusText => RiwaqColors.muted;
  Color get _mapStartText => RiwaqColors.primaryDark;

  final _demo = DemoLocationProvider();
  final _instructionService = const RouteInstructionService();
  late final IndoorLocalizationProvider _indoor;
  String _floorId = 'FIRST', _query = '';
  bool _threeD = false;
  bool _allowStairs = true, _allowElevators = true;
  String? _mobilitySaveError;
  var _mobilitySaveAttempt = 0;
  final _search = TextEditingController();
  String? _observedCurrentId;
  String? _observedDestinationId;
  RiwaqLocationSource _observedCurrentSource = RiwaqLocationSource.simulated;
  ApproximateGpsResult? _gpsResult;
  String? _navigationStartId;
  HospitalRoute? _navigationRoute;
  List<NavigationInstruction> _navigationInstructions = const [];
  var _navigationStepIndex = 0;
  var _navigationStatus = _NavigationStatus.idle;
  List<FloorPlanPlace> get _places =>
      [for (final floor in hospitalFloorPlans) ...floor.selectablePlaces];
  List<_MapSearchResult> get _mapSearchResults => [
        for (final place in _places)
          _MapSearchResult(
            value: place.id,
            place: place,
            label: _placeName(place),
            subtitle: _displayFloorName(place.floorId),
            searchableText:
                '${place.nameAr} ${_placeName(place)} ${_floorName(place.floorId)} ${place.keywords.join(' ')}',
          ),
        for (final doctor in const DoctorRepository().getAll())
          if (findHospitalPlace(doctor.locationId) case final place?)
            _MapSearchResult(
              value: 'doctor:${doctor.id}',
              place: place,
              label: riwaqLocalizedValue(doctor.name),
              subtitle:
                  '${riwaqLocalizedValue(doctor.specialty)} · ${_displayFloorName(place.floorId)}',
              searchableText:
                  '${doctor.name} ${riwaqLocalizedValue(doctor.name)} ${doctor.specialty} ${riwaqLocalizedValue(doctor.specialty)} ${doctor.departmentId} ${place.nameAr} ${_placeName(place)}',
            ),
      ];

  String _placeName(FloorPlanPlace place) => riwaqPlaceName(
        place.mapLocationId ?? place.id,
        place.nameAr,
      );

  String _displayFloorName(String floorId) => riwaqFloorName(
        floorId,
        _floorName(floorId),
      );

  String _floorTransitionDirectionLabel(
    int index,
    ({FloorPlanPlace from, FloorPlanPlace to}) transition,
  ) {
    final mode = transition.from.category == FloorPlaceCategory.elevator
        ? riwaqText('المصعد', 'elevator')
        : riwaqText('السلالم', 'stairs');
    return riwaqText(
      'الانتقال ${index + 1}: استخدم $mode من ${_displayFloorName(transition.from.floorId)} إلى ${_displayFloorName(transition.to.floorId)}.',
      'Transition ${index + 1}: Take the $mode from ${_displayFloorName(transition.from.floorId)} to ${_displayFloorName(transition.to.floorId)}.',
    );
  }

  List<_FloorImportChange> _summarizeFloorPlanChanges(
    List<HospitalFloorPlan> proposed,
  ) {
    final changes = <_FloorImportChange>[];
    for (final floor in proposed) {
      final current = hospitalFloorPlans.firstWhere(
        (item) => item.id == floor.id,
      );
      final currentPlaces = {
        for (final place in current.places) place.id: place
      };
      final proposedPlaces = {
        for (final place in floor.places) place.id: place
      };
      final added = <FloorPlanPlace>[];
      final removed = <FloorPlanPlace>[];
      final updated = <FloorPlanPlace>[];

      for (final place in floor.places) {
        final previous = currentPlaces[place.id];
        if (previous == null) {
          added.add(place);
        } else if (_placeSignature(previous) != _placeSignature(place)) {
          updated.add(place);
        }
      }
      for (final place in current.places) {
        if (!proposedPlaces.containsKey(place.id)) removed.add(place);
      }

      final currentEdges = current.connections.map(_edgeSignature).toSet();
      final proposedEdges = floor.connections.map(_edgeSignature).toSet();
      final edgeChanges = currentEdges.difference(proposedEdges).length +
          proposedEdges.difference(currentEdges).length;
      if (added.isNotEmpty ||
          removed.isNotEmpty ||
          updated.isNotEmpty ||
          edgeChanges > 0) {
        changes.add(_FloorImportChange(
          floor: floor,
          added: added,
          removed: removed,
          updated: updated,
          edgeChanges: edgeChanges,
        ));
      }
    }
    return changes;
  }

  String _placeSignature(FloorPlanPlace place) => jsonEncode([
        place.floorId,
        place.nameAr,
        place.category.name,
        place.descriptionAr,
        place.x,
        place.y,
        place.mapLocationId,
        place.connections,
        place.bounds == null
            ? null
            : [
                place.bounds!.left,
                place.bounds!.top,
                place.bounds!.width,
                place.bounds!.height,
              ],
        place.zone.name,
        place.verticalConnectionId,
        place.keywords,
      ]);

  String _edgeSignature(FloorPlanConnection edge) =>
      '${edge.fromId}|${edge.toId}|${edge.type.name}';

  Future<bool> _reviewPrototypeMapImport(
    BuildContext dialogContext,
    String fileName,
    List<HospitalFloorPlan> proposed,
  ) async {
    final changes = _summarizeFloorPlanChanges(proposed);
    final confirmed = await showDialog<bool>(
      context: dialogContext,
      builder: (reviewContext) => AlertDialog(
        title: Text(riwaqText('مراجعة تغييرات المخطط', 'Review map changes')),
        content: SizedBox(
          width: 560,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(reviewContext).height * .58,
            ),
            child: ListView(
              shrinkWrap: true,
              children: [
                Text(riwaqText('الملف: $fileName', 'File: $fileName')),
                const SizedBox(height: 8),
                Text(
                  'ستُستبدل بيانات الأدوار والمواقع المتغيرة فقط. الأدوار الأخرى ستبقى كما هي.',
                  style: TextStyle(height: 1.4),
                ),
                const SizedBox(height: 12),
                if (changes.isEmpty)
                  Text(riwaqText('لم تُكتشف تغييرات على الأدوار أو المواقع.',
                      'No floor or location changes were found.'))
                else
                  for (final change in changes) ...[
                    Text(
                      riwaqFloorName(change.floor.id, change.floor.nameAr),
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Text(
                      riwaqText(
                        'مواقع جديدة: ${change.added.length} · محذوفة: ${change.removed.length} · معدّلة: ${change.updated.length}',
                        'Added places: ${change.added.length} · Removed: ${change.removed.length} · Updated: ${change.updated.length}',
                      ),
                    ),
                    for (final place in change.added)
                      Text('＋ ${_placeName(place)} (${place.id})'),
                    for (final place in change.removed)
                      Text('− ${_placeName(place)} (${place.id})'),
                    for (final place in change.updated)
                      Text(riwaqText(
                          'تعديل: ${_placeName(place)} (${place.id})',
                          'Updated: ${_placeName(place)} (${place.id})')),
                    if (change.edgeChanges > 0)
                      Text(riwaqText(
                        'تغييرات روابط المسارات: ${change.edgeChanges}',
                        'Route connection changes: ${change.edgeChanges}',
                      )),
                    const SizedBox(height: 10),
                  ],
                Text(
                  'تنبيه: البيانات والروابط محاكاة وغير متحقق منها، للاختبار المحلي فقط.',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: RiwaqColors.orange,
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            key: const ValueKey('cancel-floor-plan-import'),
            onPressed: () => Navigator.pop(reviewContext, false),
            child: Text(riwaqText('إلغاء', 'Cancel')),
          ),
          FilledButton(
            key: const ValueKey('confirm-floor-plan-import'),
            onPressed: () => Navigator.pop(reviewContext, true),
            child: Text(riwaqText('تأكيد الاستبدال', 'Confirm replacement')),
          ),
        ],
      ),
    );
    return confirmed == true;
  }

  @override
  void initState() {
    super.initState();
    _indoor =
        widget.localizationProvider ?? UnavailableIndoorLocationProvider();
    final mobilityPreferences = RiwaqLocalStore.instance;
    _allowStairs = mobilityPreferences.allowStairs;
    _allowElevators = mobilityPreferences.allowElevators;
    mobilityPreferences.addListener(_handleMobilityPreferencesChanged);
    _floorId =
        findHospitalPlace(widget.destinationLocationId)?.floorId ?? 'FIRST';
    final locationState = RiwaqLocationState.instance;
    _observedCurrentId = locationState.currentLocationId;
    _observedDestinationId = locationState.destinationLocationId;
    _observedCurrentSource = locationState.currentLocationSource;
    locationState.addListener(_handleLocationStateChanged);
  }

  @override
  void didUpdateWidget(covariant FloorPlanScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.destinationLocationId != widget.destinationLocationId) {
      _floorId =
          findHospitalPlace(widget.destinationLocationId)?.floorId ?? _floorId;
      _observedDestinationId = widget.destinationLocationId;
      _clearNavigationSession();
    }
  }

  @override
  void dispose() {
    RiwaqLocalStore.instance.removeListener(_handleMobilityPreferencesChanged);
    RiwaqLocationState.instance.removeListener(_handleLocationStateChanged);
    _search.dispose();
    super.dispose();
  }

  void _handleMobilityPreferencesChanged() {
    final preferences = RiwaqLocalStore.instance;
    final stairsChanged = _allowStairs != preferences.allowStairs;
    final elevatorsChanged = _allowElevators != preferences.allowElevators;
    if (!stairsChanged && !elevatorsChanged) return;

    setState(() {
      _allowStairs = preferences.allowStairs;
      _allowElevators = preferences.allowElevators;
      _clearNavigationSession();
    });
  }

  void _handleLocationStateChanged() {
    final state = RiwaqLocationState.instance;
    final currentChanged = state.currentLocationId != _observedCurrentId;
    final destinationChanged =
        state.destinationLocationId != _observedDestinationId;
    final sourceChanged = state.currentLocationSource != _observedCurrentSource;
    if (!currentChanged && !destinationChanged && !sourceChanged) return;

    final navigationStatus = _navigationStatus;
    final shouldRecalculate = navigationStatus == _NavigationStatus.active ||
        navigationStatus == _NavigationStatus.paused;
    _observedCurrentId = state.currentLocationId;
    _observedDestinationId = state.destinationLocationId;
    _observedCurrentSource = state.currentLocationSource;
    if (!currentChanged && !destinationChanged) {
      setState(() {});
      return;
    }
    final changedPlace = findHospitalPlace(
      currentChanged ? state.currentLocationId : state.destinationLocationId,
    );
    if (changedPlace != null) _floorId = changedPlace.floorId;
    if (shouldRecalculate) {
      _recalculateNavigationFromSharedLocation(navigationStatus);
    } else {
      _clearNavigationSession();
    }
    if (mounted) setState(() {});
  }

  void _recalculateNavigationFromSharedLocation(
    _NavigationStatus previousStatus,
  ) {
    final state = RiwaqLocationState.instance;
    final start = findHospitalPlace(state.currentLocationId);
    final destination = findHospitalPlace(
        state.destinationLocationId ?? widget.destinationLocationId);
    if (start == null || destination == null) {
      _clearNavigationSession();
      return;
    }

    final search = HospitalRouteService().findRouteResult(
      startLocationId: start.id,
      destinationLocationId: destination.id,
      preferences: MobilityRoutePreferences(
        allowStairs: _allowStairs,
        allowElevators: _allowElevators,
      ),
    );
    final route = search.route;
    if (route == null) {
      _clearNavigationSession();
      return;
    }

    _navigationRoute = route;
    _navigationStartId = start.id;
    _navigationInstructions = _instructionService.build(route);
    _navigationStepIndex = 0;
    _navigationStatus = _navigationInstructions.isEmpty
        ? _NavigationStatus.completed
        : previousStatus;
  }

  void _clearNavigationSession() {
    _navigationStartId = null;
    _navigationRoute = null;
    _navigationInstructions = const [];
    _navigationStepIndex = 0;
    _navigationStatus = _NavigationStatus.idle;
  }

  void _setSimulatedLocation(FloorPlanPlace place) {
    final id = place.mapLocationId ?? place.id;
    // Update before notifying listeners so route-step progress is preserved.
    _observedCurrentId = id;
    _demo.setCurrentLocation(id);
  }

  void _startNavigation(HospitalRoute route) {
    final instructions = _instructionService.build(route);
    setState(() {
      _navigationRoute = route;
      _navigationStartId = route.places.first.id;
      _navigationInstructions = instructions;
      _navigationStepIndex = 0;
      _navigationStatus = instructions.isEmpty
          ? _NavigationStatus.completed
          : _NavigationStatus.active;
    });
  }

  void _pauseNavigation() =>
      setState(() => _navigationStatus = _NavigationStatus.paused);

  void _resumeNavigation() =>
      setState(() => _navigationStatus = _NavigationStatus.active);

  void _cancelNavigation() =>
      setState(() => _navigationStatus = _NavigationStatus.cancelled);

  void _restartNavigation() {
    final route = _navigationRoute;
    final startId = _navigationStartId;
    if (route == null || startId == null) return;
    final start = findHospitalPlace(startId);
    if (start == null) return;
    _setSimulatedLocation(start);
    setState(() {
      _floorId = start.floorId;
      _navigationStepIndex = 0;
      _navigationStatus = _navigationInstructions.isEmpty
          ? _NavigationStatus.completed
          : _NavigationStatus.active;
    });
  }

  void _advanceNavigation() {
    final route = _navigationRoute;
    final index = _navigationStepIndex;
    if (route == null ||
        index >= _navigationInstructions.length ||
        _navigationStatus != _NavigationStatus.active) {
      return;
    }
    final instruction = _navigationInstructions[index];
    final place = route.places[instruction.toIndex];
    _setSimulatedLocation(place);
    setState(() {
      _floorId = place.floorId;
      _navigationStepIndex++;
      if (_navigationStepIndex >= _navigationInstructions.length) {
        _navigationStatus = _NavigationStatus.completed;
      }
    });
  }

  void _previousNavigationStep() {
    final route = _navigationRoute;
    final index = _navigationStepIndex;
    if (route == null || index == 0) return;
    final previous = _navigationInstructions[index - 1];
    final place = route.places[previous.fromIndex];
    _setSimulatedLocation(place);
    setState(() {
      _floorId = place.floorId;
      _navigationStepIndex--;
      _navigationStatus = _NavigationStatus.active;
    });
  }

  String _floorName(String id) =>
      hospitalFloorPlans.firstWhere((f) => f.id == id).nameAr;

  Future<void> _setAllowStairs(bool allow) async {
    setState(() {
      _allowStairs = allow;
      _clearNavigationSession();
    });
    await _saveMobilityPreference(
      () => RiwaqLocalStore.instance.setAllowStairs(allow),
    );
  }

  Future<void> _setAllowElevators(bool allow) async {
    setState(() {
      _allowElevators = allow;
      _clearNavigationSession();
    });
    await _saveMobilityPreference(
      () => RiwaqLocalStore.instance.setAllowElevators(allow),
    );
  }

  Future<void> _resetMobilityPreferences() async {
    setState(() {
      _allowStairs = true;
      _allowElevators = true;
      _clearNavigationSession();
    });
    await _saveMobilityPreference(
      RiwaqLocalStore.instance.resetMobilityPreferences,
    );
  }

  Future<void> _saveMobilityPreference(Future<bool> Function() save) async {
    final attempt = ++_mobilitySaveAttempt;
    final saved = await save();
    if (!mounted || attempt != _mobilitySaveAttempt) return;
    setState(() {
      _mobilitySaveError = saved
          ? null
          : riwaqText(
              'تعذر حفظ تفضيلات المسار على هذا الجهاز. ستظل الخيارات مطبقة لهذه الجلسة فقط.',
              'Route preferences could not be saved on this device. These choices apply only for this session.',
            );
    });
  }

  Future<void> _importPrototypeMapFile(
    BuildContext dialogContext,
    TextEditingController controller,
  ) async {
    try {
      final selection = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['json'],
        withData: true,
      );
      if (selection == null) return;
      final file = selection.files.single;
      final bytes = file.bytes;
      if (bytes == null) {
        throw StateError(
          riwaqText('تعذر قراءة محتوى الملف المحدد.',
              'Could not read the selected file.'),
        );
      }

      final proposed = HospitalFloorPlanEditor.decodeAndValidate(
        utf8.decode(bytes),
      );
      if (!dialogContext.mounted) return;
      final confirmed = await _reviewPrototypeMapImport(
        dialogContext,
        file.name,
        proposed,
      );
      if (!confirmed || !dialogContext.mounted) return;

      await HospitalFloorPlanEditor.saveValidated(proposed);
      if (!dialogContext.mounted) return;
      controller.text = HospitalFloorPlanEditor.exportJson();
      Navigator.pop(dialogContext, true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(riwaqText(
              'تم التحقق من ${file.name} وحفظه محلياً',
              'Validated ${file.name} and saved it locally.',
            )),
          ),
        );
      }
    } catch (error) {
      if (dialogContext.mounted) {
        ScaffoldMessenger.of(dialogContext).showSnackBar(
          SnackBar(
            content: Text(riwaqText(
              'لم يُستورد الملف؛ بقي المخطط الحالي دون تغيير: $error',
              'Import failed; the current map was kept unchanged: $error',
            )),
            duration: const Duration(seconds: 7),
          ),
        );
      }
    }
  }

  Future<void> _downloadPrototypeMap(TextEditingController controller) async {
    final fileName =
        'riwaq-simulated-floor-plan-${DateTime.now().toIso8601String().split('T').first}.json';
    try {
      final path = await FilePicker.saveFile(
        dialogTitle: riwaqText('تنزيل نسخة JSON من المخطط التجريبي',
            'Download simulated map JSON'),
        fileName: fileName,
        type: FileType.custom,
        allowedExtensions: const ['json'],
        bytes: utf8.encode(controller.text),
      );
      if (!mounted || (path == null && !kIsWeb)) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(riwaqText(
              'بدأ تنزيل نسخة JSON من المخطط', 'Map JSON download started.')),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(riwaqText('تعذر تنزيل نسخة المخطط: $error',
              'Could not download the map copy: $error')),
        ),
      );
    }
  }

  Future<void> _editPrototypeMap() async {
    final controller = TextEditingController(
      text: HospitalFloorPlanEditor.exportJson(),
    );
    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(riwaqText(
            'تعديل بيانات المخطط التجريبي', 'Edit simulated map data')),
        content: SizedBox(
          width: 760,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(dialogContext).height * .68,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  riwaqText(
                    'حرّر المواقع والروابط بصيغة JSON ثم احفظ. عند تعديل دور، استبدل قائمة مواقع ذلك الدور وروابطه كاملة. يمكن ترك الأدوار الأخرى دون تغيير. تُرفض المعرفات المفقودة والروابط بين الأدوار قبل الحفظ.',
                    'Edit locations and connections as JSON, then save. When changing a floor, replace that floor’s complete place and connection lists. Other floors may remain unchanged. Missing IDs and cross-floor links are rejected.',
                  ),
                  style: TextStyle(fontSize: 12, height: 1.5),
                ),
                const SizedBox(height: 8),
                Text(
                  riwaqText(
                    'تنبيه: البيانات والروابط محاكاة وغير متحقق منها، للاختبار المحلي فقط.',
                    'Locations and links are simulated, unverified, and for local testing only.',
                  ),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: RiwaqColors.orange,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    OutlinedButton.icon(
                      key: const ValueKey('import-floor-plan-json-file'),
                      onPressed: () => _importPrototypeMapFile(
                        dialogContext,
                        controller,
                      ),
                      icon: const Icon(Icons.file_open_outlined, size: 17),
                      label: Text(riwaqText('استيراد ملف JSON', 'Import JSON')),
                    ),
                    OutlinedButton.icon(
                      key: const ValueKey('download-floor-plan-json'),
                      onPressed: () => _downloadPrototypeMap(controller),
                      icon: const Icon(Icons.download_outlined, size: 17),
                      label:
                          Text(riwaqText('تنزيل نسخة JSON', 'Download JSON')),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Flexible(
                  child: TextField(
                    key: const ValueKey('floor-plan-json-editor'),
                    controller: controller,
                    minLines: 14,
                    maxLines: 24,
                    expands: false,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 11,
                    ),
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'JSON',
                      alignLabelWithHint: true,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: controller.text));
              if (dialogContext.mounted) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  SnackBar(
                    content: Text(riwaqText('نُسخت البيانات إلى الحافظة',
                        'Data copied to clipboard.')),
                  ),
                );
              }
            },
            icon: const Icon(Icons.copy, size: 17),
            label: Text(riwaqText('نسخ JSON', 'Copy JSON')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(riwaqText('إلغاء', 'Cancel')),
          ),
          FilledButton.icon(
            key: const ValueKey('save-floor-plan-json'),
            onPressed: () async {
              try {
                await HospitalFloorPlanEditor.importAndSave(controller.text);
                if (dialogContext.mounted) Navigator.pop(dialogContext, true);
              } catch (error) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    SnackBar(
                      content: Text(riwaqText('لم تُحفظ البيانات: $error',
                          'The data was not saved: $error')),
                      duration: const Duration(seconds: 6),
                    ),
                  );
                }
              }
            },
            icon: const Icon(Icons.save_outlined, size: 17),
            label: Text(riwaqText('تحقق واحفظ', 'Validate and save')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (saved == true && mounted) setState(() {});
  }

  Future<void> _resetPrototypeMap() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
            riwaqText('إعادة المخطط الأصلي؟', 'Restore the original map?')),
        content: Text(riwaqText(
          'سيُحذف التعديل المحلي الحالي وتُستعاد بيانات الخريطة التجريبية المرفقة بالتطبيق.',
          'Current local edits will be removed and the bundled simulated map will be restored.',
        )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(riwaqText('إلغاء', 'Cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(riwaqText('استعادة', 'Restore')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await HospitalFloorPlanEditor.resetToDefaults();
    if (mounted) setState(() {});
  }

  String _normalize(String text) => text
      .toLowerCase()
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll(RegExp('[ًٌٍَُِّْ]'), '');
  void _select(FloorPlanPlace place) {
    widget.onOpenMap(place.mapLocationId ?? place.id);
    setState(() {
      _floorId = place.floorId;
      _query = '';
      _search.clear();
    });
  }

  Future<void> _myLocation() async {
    final fix = await _indoor.requestLocation();
    if (!mounted) return;
    if (fix != null) {
      if (!PredictionLocalizationProvider().receive(fix)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(riwaqText(
              'رُفض تقدير الموقع: البيانات قديمة أو الثقة / هوية الموقع غير صالحة.',
              'Location estimate rejected: the data is stale or its confidence or location ID is invalid.',
            )),
          ),
        );
        return;
      }
      final place = findHospitalPlace(fix.locationId)!;
      final floor = hospitalFloorPlans.firstWhere((f) => f.id == place.floorId);
      RiwaqLocationState.instance.setCurrent(
          locationId: place.mapLocationId ?? place.id,
          floor: floor.level,
          prediction: fix,
          source: RiwaqLocationSource.visualMarker);
      setState(() => _floorId = place.floorId);
      return;
    }

    final result = await widget.gpsService.request();
    if (!mounted) return;
    setState(() => _gpsResult = result);
    if (result.status == ApproximateGpsStatus.available &&
        result.accuracyMeters != null) {
      RiwaqLocationState.instance
          .setApproximateGps(accuracyMeters: result.accuracyMeters!);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(riwaqText(
          'تم الحصول على GPS تقريبي خارجياً فقط. لا توجد إحداثيات موثقة لربطه بهذه الخريطة؛ اختر نقطة بداية تجريبية يدوياً.',
          'Approximate outdoor GPS is available, but no room coordinates are verified. Choose a simulated start manually.',
        )),
      ));
      return;
    }
    final message = switch (result.status) {
      ApproximateGpsStatus.serviceDisabled => riwaqText(
          'فعّل خدمات الموقع في الجهاز ثم حاول مجدداً.',
          'Enable location services on the device and try again.'),
      ApproximateGpsStatus.permissionDenied => riwaqText(
          'لم يُسمح بإذن الموقع. يمكنك اختيار نقطة بداية تجريبية يدوياً.',
          'Location permission was denied. You can choose a simulated start manually.'),
      ApproximateGpsStatus.permissionPermanentlyDenied => riwaqText(
          'إذن الموقع مرفوض نهائياً. غيّره من إعدادات التطبيق إذا رغبت.',
          'Location permission is blocked. Change it in app settings if you want to use GPS.'),
      ApproximateGpsStatus.timedOut => riwaqText(
          'انتهت مهلة GPS. اختر نقطة بداية تجريبية يدوياً.',
          'GPS timed out. Choose a simulated start manually.'),
      ApproximateGpsStatus.unavailable ||
      ApproximateGpsStatus.available =>
        riwaqText('تعذر الحصول على موقع GPS.', 'Could not get a GPS location.'),
    };
    final useEntrance = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(riwaqText(
            'الموقع الداخلي غير متاح', 'Indoor position unavailable')),
        content: Text(riwaqText(
          '$message لا توجد إحداثيات غرف موثقة لمطابقة GPS. يمكنك اختيار المدخل كبداية تجريبية فقط.',
          '$message No room coordinates are verified for GPS matching. You can use the entrance as a simulated start only.',
        )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(riwaqText('إغلاق', 'Close')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(
                riwaqText('استخدم المدخل التجريبي', 'Use simulated entrance')),
          ),
        ],
      ),
    );
    if (useEntrance == true && mounted) {
      _demo.setCurrentLocation('MAIN_ENTRANCE');
      setState(() => _floorId = 'GROUND');
    }
  }

  Future<void> _changeStart() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                riwaqText('تحريك البداية التجريبية', 'Move simulated start'),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              const SizedBox(height: 10),
              Text(riwaqText(
                'هذه محاكاة فقط. اختر نقطة صالحة عند مدخل غرفة أو مرفق لإعادة حساب المسار.',
                'This is a simulation. Choose a valid room or facility entrance to recalculate the route.',
              )),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                key: const ValueKey('demo-start-dropdown'),
                isExpanded: true,
                value: findHospitalPlace(_demo.currentLocationId)?.id,
                menuMaxHeight: 360,
                decoration: InputDecoration(
                    labelText:
                        riwaqText('نقطة البداية التجريبية', 'Simulated start')),
                items: [
                  for (final p in _places)
                    DropdownMenuItem(
                        value: p.id,
                        child: Text(
                            '${_placeName(p)} · ${_displayFloorName(p.floorId)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis))
                ],
                onChanged: (id) => Navigator.pop(context, id),
              ),
              const SizedBox(height: 24),
            ]),
      )),
    );
    if (selected != null && mounted) {
      _demo.setCurrentLocation(selected);
      setState(() => _floorId = findHospitalPlace(selected)!.floorId);
    }
  }

  Widget _navigationPanel(
    HospitalRoute route,
    String routeAvailabilityMessage,
  ) {
    final activeRoute = _navigationRoute;
    final instructions = _navigationInstructions;
    final status = _navigationStatus;
    final canRestart = activeRoute != null &&
        _navigationStartId != null &&
        status != _NavigationStatus.idle;
    final currentInstruction = (_navigationStepIndex < instructions.length)
        ? instructions[_navigationStepIndex]
        : null;
    final maneuverIcon = switch (currentInstruction?.maneuver) {
      NavigationManeuver.turnLeft => Icons.turn_left_rounded,
      NavigationManeuver.turnRight => Icons.turn_right_rounded,
      NavigationManeuver.turnAround => Icons.u_turn_left_rounded,
      NavigationManeuver.floorTransition => Icons.elevator_outlined,
      _ => Icons.straight_rounded,
    };

    return Card(
      key: const ValueKey('navigation-panel'),
      margin: const EdgeInsets.only(top: 10),
      color: RiwaqColors.surface,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: RiwaqColors.border),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              riwaqText('توجيه تجريبي خطوة بخطوة',
                  'Step-by-step simulated directions'),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Semantics(
              key: const ValueKey('route-availability-announcement'),
              container: true,
              liveRegion: true,
              label: routeAvailabilityMessage,
              child: ExcludeSemantics(
                child: Text(
                  routeAvailabilityMessage,
                  key: const ValueKey('route-summary'),
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            if (route.places.first.id == route.places.last.id)
              Text(
                riwaqText(
                  'البداية والوجهة في النقطة نفسها.',
                  'The start and destination are the same place.',
                ),
                style: const TextStyle(fontSize: 11),
              ),
            for (final entry in route.floorTransitions.asMap().entries)
              TextButton.icon(
                key: ValueKey('route-floor-transition-${entry.key + 1}'),
                onPressed: () =>
                    setState(() => _floorId = entry.value.to.floorId),
                icon: Icon(
                  entry.value.from.category == FloorPlaceCategory.elevator
                      ? Icons.elevator_outlined
                      : Icons.stairs_outlined,
                  size: 17,
                ),
                label: Text(
                  riwaqText(
                    'انتقل عبر ${entry.value.from.category == FloorPlaceCategory.elevator ? 'المصعد' : 'السلالم'} إلى ${_displayFloorName(entry.value.to.floorId)} · من ${_displayFloorName(entry.value.from.floorId)}',
                    'Take the ${entry.value.from.category == FloorPlaceCategory.elevator ? 'elevator' : 'stairs'} to ${_displayFloorName(entry.value.to.floorId)} from ${_displayFloorName(entry.value.from.floorId)}',
                  ),
                  semanticsLabel:
                      _floorTransitionDirectionLabel(entry.key, entry.value),
                  style: const TextStyle(fontSize: 10),
                ),
              ),
            const SizedBox(height: 4),
            Text(
              riwaqText(
                'هذه المسارات محاكاة وغير متحقق منها؛ لا تستخدم للتوجيه الفعلي.',
                'These routes are simulated and unverified; do not use them for real navigation.',
              ),
              key: const ValueKey('map-simulation-warning'),
              style: TextStyle(fontSize: 12, color: _mapStatusText),
            ),
            if (status == _NavigationStatus.active ||
                status == _NavigationStatus.paused) ...[
              const Divider(height: 18),
              if (status == _NavigationStatus.paused)
                Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: Text(
                    riwaqText(
                        'التوجيه متوقف مؤقتاً.', 'Directions are paused.'),
                    style: TextStyle(fontSize: 12, color: _mapStatusText),
                  ),
                ),
              if (currentInstruction != null) ...[
                Text(
                  riwaqText(
                    'الخطوة ${_navigationStepIndex + 1} من ${instructions.length} · المتبقي ${instructions.length - _navigationStepIndex}',
                    'Step ${_navigationStepIndex + 1} of ${instructions.length} · ${instructions.length - _navigationStepIndex} remaining',
                  ),
                  key: const ValueKey('navigation-progress'),
                  style: TextStyle(
                    fontSize: 11,
                    color: RiwaqColors.primaryDark,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 5),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(maneuverIcon, color: RiwaqColors.primaryDark),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Semantics(
                        liveRegion: true,
                        child: Text(
                          riwaqText(currentInstruction.textAr,
                              currentInstruction.textEn),
                          key: const ValueKey('navigation-current-instruction'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ] else
                Text(
                  riwaqText('أنت عند الوجهة التجريبية.',
                      'You have reached the simulated destination.'),
                  key: const ValueKey('navigation-arrived'),
                ),
            ] else if (status == _NavigationStatus.completed) ...[
              const Divider(height: 18),
              Text(
                instructions.isEmpty
                    ? riwaqText(
                        'البداية والوجهة في الموقع نفسه.',
                        'The start and destination are the same place.',
                      )
                    : riwaqText(
                        'اكتمل المسار التجريبي ووصلت إلى الوجهة.',
                        'The simulated route is complete.',
                      ),
                key: const ValueKey('navigation-arrived'),
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ] else if (status == _NavigationStatus.paused) ...[
              const Divider(height: 18),
              Text(
                  riwaqText('التوجيه متوقف مؤقتاً.', 'Directions are paused.')),
            ] else if (status == _NavigationStatus.cancelled) ...[
              const Divider(height: 18),
              Text(riwaqText('أُلغي التوجيه التجريبي.',
                  'Simulated directions cancelled.')),
            ] else ...[
              const Divider(height: 18),
              Text(riwaqText('ابدأ التوجيه من نقطة البداية الحالية.',
                  'Start directions from the current map start.')),
            ],
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                if (status == _NavigationStatus.idle ||
                    status == _NavigationStatus.cancelled)
                  FilledButton.icon(
                    key: const ValueKey('navigation-start'),
                    onPressed: () => _startNavigation(route),
                    icon: const Icon(Icons.navigation_outlined, size: 17),
                    label: Text(riwaqText('ابدأ التوجيه', 'Start directions')),
                  ),
                if (status == _NavigationStatus.active)
                  OutlinedButton.icon(
                    key: const ValueKey('navigation-pause'),
                    onPressed: _pauseNavigation,
                    icon: const Icon(Icons.pause_outlined, size: 17),
                    label: Text(riwaqText('إيقاف مؤقت', 'Pause')),
                  ),
                if (status == _NavigationStatus.paused)
                  FilledButton.icon(
                    key: const ValueKey('navigation-resume'),
                    onPressed: _resumeNavigation,
                    icon: const Icon(Icons.play_arrow_rounded, size: 17),
                    label: Text(riwaqText('استئناف', 'Resume')),
                  ),
                if (status == _NavigationStatus.active ||
                    status == _NavigationStatus.paused)
                  OutlinedButton.icon(
                    key: const ValueKey('navigation-cancel'),
                    onPressed: _cancelNavigation,
                    icon: const Icon(Icons.stop_outlined, size: 17),
                    label: Text(riwaqText('إلغاء', 'Cancel')),
                  ),
                if (canRestart)
                  OutlinedButton.icon(
                    key: const ValueKey('navigation-restart'),
                    onPressed: _restartNavigation,
                    icon: const Icon(Icons.restart_alt, size: 17),
                    label: Text(riwaqText('إعادة البدء', 'Restart')),
                  ),
                if (status == _NavigationStatus.active &&
                    currentInstruction != null)
                  FilledButton.icon(
                    key: const ValueKey('navigation-next-step'),
                    onPressed: _advanceNavigation,
                    icon: Icon(
                        RiwaqLocalStore.instance.languageCode == 'ar'
                            ? Icons.arrow_back_rounded
                            : Icons.arrow_forward_rounded,
                        size: 17),
                    label: Text(riwaqText('الخطوة التالية', 'Next step')),
                  ),
                if (status == _NavigationStatus.active &&
                    _navigationStepIndex > 0)
                  OutlinedButton.icon(
                    key: const ValueKey('navigation-previous-step'),
                    onPressed: _previousNavigationStep,
                    icon: Icon(
                        RiwaqLocalStore.instance.languageCode == 'ar'
                            ? Icons.arrow_forward_rounded
                            : Icons.arrow_back_rounded,
                        size: 17),
                    label: Text(riwaqText('الخطوة السابقة', 'Previous step')),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shared = RiwaqLocationState.instance;
    final start = findHospitalPlace(shared.currentLocationId) ??
        findHospitalPlace('MAIN_ENTRANCE')!;
    final destination = findHospitalPlace(shared.destinationLocationId) ??
        findHospitalPlace('EYE_CLINIC')!;
    final floor = hospitalFloorPlans.firstWhere((f) => f.id == _floorId);
    final routeSearch = HospitalRouteService().findRouteResult(
      startLocationId: start.id,
      destinationLocationId: destination.id,
      preferences: MobilityRoutePreferences(
        allowStairs: _allowStairs,
        allowElevators: _allowElevators,
      ),
    );
    final route = routeSearch.route;
    final routeAvailabilityMessage = route == null
        ? switch (routeSearch.failureReason) {
            RouteFailureReason.unknownLocation => riwaqText(
                'تعذر تحديد نقطة البداية أو الوجهة في المخطط.',
                'The map could not identify the start or destination.'),
            RouteFailureReason.excludedByMobilityPreferences => riwaqText(
                'لا يتوفر مسار يطابق تفضيلات الحركة المحددة. جرّب السماح بالسلالم أو المصعد.',
                'No route matches the selected mobility preferences. Allow stairs or elevators and try again.'),
            _ => riwaqText('لا يوجد مسار متصل مسجل بين هاتين النقطتين.',
                'There is no connected route between these locations.'),
          }
        : riwaqText(
            'مسار محاكاة من ${_placeName(start)} إلى ${_placeName(destination)}',
            'Simulated route from ${_placeName(start)} to ${_placeName(destination)}',
          );
    final searchResults = _mapSearchResults;
    final query = _normalize(_query);
    final filtered = searchResults.where((result) {
      if (query.isEmpty) return !result.value.startsWith('doctor:');
      return result.value == destination.id ||
          _normalize(result.searchableText).contains(query);
    }).toList();
    final savedId = destination.mapLocationId ?? destination.id;
    final saved = RiwaqLocalStore.instance.isSaved(savedId);
    final currentLocationLabel = switch (shared.currentLocationSource) {
      RiwaqLocationSource.simulated =>
        '${riwaqText('البداية التجريبية', 'Simulated start')}: ${_placeName(start)} · ${_displayFloorName(start.floorId)}',
      RiwaqLocationSource.visualMarker =>
        '${riwaqText('تقدير بصري تجريبي', 'Prototype visual estimate')}: ${_placeName(start)} · ${_displayFloorName(start.floorId)}',
      RiwaqLocationSource.gpsApproximate => riwaqText(
          'GPS تقريبي خارجياً (دقة نحو ${(_gpsResult?.accuracyMeters ?? shared.approximateGpsAccuracyMeters ?? 0).round()} م)؛ نقطة البداية على الخريطة ما زالت يدوية.',
          'Approx. outdoor GPS (about ${(_gpsResult?.accuracyMeters ?? shared.approximateGpsAccuracyMeters ?? 0).round()} m accuracy); the map start remains manual.',
        ),
    };
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text(
        riwaqText('الخريطة', 'Hospital map'),
        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19),
      ),
      const SizedBox(height: 5),
      Text(
        riwaqText(
          'خريطة ومسارات تجريبية غير متحقق منها، وليست للتوجيه الفعلي.',
          'This map and its routes are simulated and unverified; not for real navigation.',
        ),
        key: const ValueKey('map-simulation-intro'),
        style: TextStyle(color: _mapStatusText, fontSize: 12, height: 1.6),
      ),
      const SizedBox(height: 14),
      TextField(
        key: const ValueKey('map-search'),
        controller: _search,
        decoration: InputDecoration(
            hintText: riwaqText('ابحث عن طبيب أو قسم أو مرفق',
                'Search doctors, departments, facilities'),
            prefixIcon: const Icon(Icons.search),
            suffixIcon: _query.isEmpty
                ? null
                : IconButton(
                    tooltip: riwaqText('مسح البحث', 'Clear search'),
                    onPressed: () => setState(() {
                          _query = '';
                          _search.clear();
                        }),
                    icon: const Icon(Icons.close))),
        onChanged: (text) => setState(() => _query = text),
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        key: ValueKey(
            'destination-dropdown-${destination.id}-${_query.isEmpty}'),
        value: destination.id,
        isExpanded: true,
        menuMaxHeight: 340,
        decoration:
            InputDecoration(labelText: riwaqText('وجهتك', 'Destination')),
        items: [
          for (final result in filtered)
            DropdownMenuItem(
              value: result.value,
              child: Text(
                '${result.label} · ${result.subtitle}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            )
        ],
        onChanged: (value) {
          if (value == null) return;
          final selected = searchResults
              .where((result) => result.value == value)
              .firstOrNull;
          if (selected != null) _select(selected.place);
        },
      ),
      if (_query.isNotEmpty)
        Text(
          riwaqText('نتائج البحث: ${filtered.length}',
              'Search results: ${filtered.length}'),
          style: TextStyle(fontSize: 12, color: _mapStatusText),
        ),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 4, children: [
        OutlinedButton.icon(
            onPressed: _myLocation,
            icon: const Icon(Icons.my_location, size: 17),
            label: Text(riwaqText('موقعي', 'My location'))),
        TextButton.icon(
            key: const ValueKey('change-demo-start'),
            onPressed: _changeStart,
            icon: const Icon(Icons.edit_location_alt_outlined, size: 17),
            label: Text(riwaqText('اختيار نقطة البداية', 'Choose map start'))),
      ]),
      Text(currentLocationLabel,
          key: const ValueKey('demo-start-label'),
          style: TextStyle(fontSize: 12, color: _mapStartText)),
      const SizedBox(height: 10),
      Wrap(spacing: 6, runSpacing: 4, children: [
        for (final f in hospitalFloorPlans)
          ChoiceChip(
              label: Text(riwaqFloorName(f.id, f.nameAr)),
              selected: floor.id == f.id,
              onSelected: (_) => setState(() => _floorId = f.id)),
      ]),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: [
          ButtonSegment(
              value: false,
              label: Text(riwaqText('مخطط 2D', '2D plan')),
              icon: const Icon(Icons.map_outlined)),
          ButtonSegment(
              value: true,
              label: Text(riwaqText('نموذج 3D', '3D model')),
              icon: const Icon(Icons.view_in_ar_outlined)),
        ],
        selected: {_threeD},
        onSelectionChanged: (v) => setState(() => _threeD = v.single),
      ),
      ExpansionTile(
        key: const ValueKey('advanced-map-options'),
        tilePadding: EdgeInsets.zero,
        title: Text(riwaqText('خيارات إضافية', 'More map options')),
        leading: const Icon(Icons.tune_rounded),
        children: [
          Wrap(spacing: 8, runSpacing: 4, children: [
            Semantics(
              key: const ValueKey('route-avoid-stairs-semantics'),
              label: riwaqText('السلالم', 'Stairs'),
              value: _allowStairs
                  ? riwaqText('مسموح', 'Allowed')
                  : riwaqText('متجنب', 'Avoided'),
              toggled: !_allowStairs,
              liveRegion: true,
              onTap: () => _setAllowStairs(!_allowStairs),
              child: ExcludeSemantics(
                child: FilterChip(
                  key: const ValueKey('route-avoid-stairs'),
                  avatar: const Icon(Icons.stairs_outlined, size: 17),
                  label: Text(riwaqText('تجنب السلالم', 'Avoid stairs')),
                  selected: !_allowStairs,
                  onSelected: (avoid) => _setAllowStairs(!avoid),
                ),
              ),
            ),
            Semantics(
              key: const ValueKey('route-avoid-elevators-semantics'),
              label: riwaqText('المصاعد', 'Elevators'),
              value: _allowElevators
                  ? riwaqText('مسموح', 'Allowed')
                  : riwaqText('متجنب', 'Avoided'),
              toggled: !_allowElevators,
              liveRegion: true,
              onTap: () => _setAllowElevators(!_allowElevators),
              child: ExcludeSemantics(
                child: FilterChip(
                  key: const ValueKey('route-avoid-elevators'),
                  avatar: const Icon(Icons.elevator_outlined, size: 17),
                  label: Text(riwaqText('تجنب المصاعد', 'Avoid elevators')),
                  selected: !_allowElevators,
                  onSelected: (avoid) => _setAllowElevators(!avoid),
                ),
              ),
            ),
            OutlinedButton.icon(
              key: const ValueKey('reset-route-preferences'),
              onPressed: _resetMobilityPreferences,
              icon: const Icon(Icons.restart_alt, size: 17),
              label: Text(riwaqText(
                  'السماح بالسلالم والمصاعد', 'Allow stairs and elevators')),
            ),
          ]),
          if (_mobilitySaveError != null) ...[
            const SizedBox(height: 8),
            Semantics(
              liveRegion: true,
              child: Text(
                _mobilitySaveError!,
                key: const ValueKey('mobility-preference-save-error'),
                style: const TextStyle(
                  color: Color(0xFF9A3D20),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              OutlinedButton.icon(
                key: const ValueKey('edit-prototype-map'),
                onPressed: _editPrototypeMap,
                icon: const Icon(Icons.edit_note, size: 17),
                label: Text(
                    riwaqText('تعديل بيانات المخطط', 'Edit prototype map')),
              ),
              TextButton.icon(
                key: const ValueKey('reset-prototype-map'),
                onPressed: _resetPrototypeMap,
                icon: const Icon(Icons.restart_alt, size: 17),
                label: Text(riwaqText(
                    'استعادة النسخة الأصلية', 'Restore original map')),
              ),
            ],
          ),
        ],
      ),
      const SizedBox(height: 12),
      if (route != null)
        _navigationPanel(route, routeAvailabilityMessage)
      else
        Semantics(
          key: const ValueKey('route-availability-announcement'),
          container: true,
          liveRegion: true,
          label: routeAvailabilityMessage,
          child: ExcludeSemantics(
            child: Text(
              routeAvailabilityMessage,
              key: const ValueKey('route-unavailable'),
              style: TextStyle(color: _mapStatusText),
            ),
          ),
        ),
      const SizedBox(height: 8),
      if (_threeD)
        HospitalModel3D(
          floor: floor,
          route: route,
          startId: start.id,
          destinationId: destination.id,
          onSelect: _select,
          onFloorSelect: (id) => setState(() => _floorId = id),
        )
      else
        HospitalPlan2D(
          key: ValueKey(floor.id),
          floor: floor,
          route: route,
          startId: start.id,
          destinationId: destination.id,
          onSelect: _select,
        ),
      const SizedBox(height: 12),
      Wrap(
        key: const ValueKey('map-marker-legend'),
        spacing: 12,
        runSpacing: 5,
        children: [
          _MapLegendItem(
            key: const ValueKey('map-legend-start'),
            icon: Icons.flag_rounded,
            color: _mapStartText,
            label: riwaqText('بداية المسار والممرات', 'Start and corridors'),
          ),
          _MapLegendItem(
            key: const ValueKey('map-legend-destination'),
            icon: Icons.place_rounded,
            color: const Color(0xFF9A4B00),
            label: riwaqText('الوجهة', 'Destination'),
          ),
          _MapLegendItem(
            key: const ValueKey('map-legend-floor-change'),
            icon: Icons.swap_vert_rounded,
            color: _mapStatusText,
            label: riwaqText('تغيير الدور', 'Floor transition'),
          ),
        ],
      ),
      const SizedBox(height: 8),
      Container(
        key: const ValueKey('destination-details'),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: RiwaqColors.mint, borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.location_on, color: Color(0xFF9A4B00)),
            const SizedBox(width: 6),
            Expanded(
                child: Text(_placeName(destination),
                    style: const TextStyle(fontWeight: FontWeight.w800))),
            IconButton(
                visualDensity: VisualDensity.compact,
                constraints:
                    const BoxConstraints.tightFor(width: 36, height: 36),
                iconSize: 19,
                tooltip: saved
                    ? riwaqText(
                        'إزالة من المواقع المحفوظة', 'Remove saved location')
                    : riwaqText('حفظ الموقع', 'Save location'),
                onPressed: () => RiwaqLocalStore.instance.toggleSaved(savedId),
                icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border,
                    color: RiwaqColors.primary)),
          ]),
        ]),
      ),
    ]);
  }
}

class _MapLegendItem extends StatelessWidget {
  const _MapLegendItem({
    super.key,
    required this.icon,
    required this.color,
    required this.label,
  });

  final IconData icon;
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 15, color: color),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            label,
            key: ValueKey('map-legend-label-$label'),
            style: TextStyle(
              fontSize: 12,
              color: RiwaqColors.muted,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

