import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../services/riwaq_local_store.dart';
import '../theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.onOpenRecentVisits,
    required this.onOpenSavedLocations,
    required this.onOpenNotifications,
    required this.onOpenSettings,
    required this.onOpenHelp,
  });

  final VoidCallback onOpenRecentVisits;
  final VoidCallback onOpenSavedLocations;
  final VoidCallback onOpenNotifications;
  final VoidCallback onOpenSettings;
  final VoidCallback onOpenHelp;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;

  @override
  void initState() {
    super.initState();
    final store = RiwaqLocalStore.instance;
    _nameController = TextEditingController(
        text: store.profileName == 'زائر رِواق' ? '' : store.profileName);
    _phoneController = TextEditingController(text: store.profilePhone);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;
    await RiwaqLocalStore.instance.saveProfile(
      name: _nameController.text,
      phone: _phoneController.text,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(riwaqText('تم حفظ بياناتك على هذا الجهاز.',
            'Your details were saved on this device.')),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
                color: RiwaqColors.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: RiwaqColors.border)),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                        labelText: riwaqText('الاسم', 'Name'),
                        prefixIcon: Icon(Icons.person_outline_rounded)),
                    validator: (value) =>
                        (value == null || value.trim().length < 2)
                            ? riwaqText('أدخل اسماً من حرفين على الأقل.',
                                'Enter a name with at least two characters.')
                            : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                        labelText: riwaqText(
                            'رقم الهاتف (اختياري)', 'Phone number (optional)'),
                        prefixIcon: Icon(Icons.phone_outlined)),
                    validator: (value) {
                      final phone = value?.trim() ?? '';
                      if (phone.isNotEmpty &&
                          !RegExp(r'^\+?[0-9]{9,15}$').hasMatch(phone)) {
                        return riwaqText(
                          'أدخل رقم هاتف صحيحاً أو اترك الحقل فارغاً.',
                          'Enter a valid phone number or leave it blank.',
                        );
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _saveProfile,
                      icon: const Icon(Icons.save_outlined),
                      label: Text(riwaqText('حفظ المعلومات', 'Save details')),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    riwaqText(
                      'تُحفظ هذه المعلومات محلياً على جهازك فقط، ولا يوجد حساب أو مزامنة سحابية.',
                      'This information is stored only on this device; there is no account or cloud sync.',
                    ),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: RiwaqColors.muted, fontSize: 11, height: 1.45),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(riwaqText('اختصارات الحساب', 'Account shortcuts'),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: RiwaqColors.text)),
          const SizedBox(height: 8),
          _ProfileAction(
              icon: Icons.history_rounded,
              title: riwaqText('آخر الزيارات', 'Recent visits'),
              onTap: widget.onOpenRecentVisits),
          _ProfileAction(
              icon: Icons.bookmark_border_rounded,
              title: riwaqText('العناوين المحفوظة', 'Saved locations'),
              onTap: widget.onOpenSavedLocations),
          _ProfileAction(
              icon: Icons.notifications_none_rounded,
              title: riwaqText('الإشعارات', 'Notifications'),
              onTap: widget.onOpenNotifications),
          _ProfileAction(
              icon: Icons.settings_outlined,
              title: riwaqText('الإعدادات', 'Settings'),
              onTap: widget.onOpenSettings),
          _ProfileAction(
              icon: Icons.help_outline_rounded,
              title: riwaqText('المساعدة والدعم', 'Help and support'),
              onTap: widget.onOpenHelp),
          const SizedBox(height: 14),
          Center(
              child: Text(
                  riwaqText('رِواق · البيانات المعروضة تجريبية',
                      'Riwaq · sample information'),
                  style: TextStyle(color: RiwaqColors.muted, fontSize: 11))),
        ],
      );
}

class _ProfileAction extends StatelessWidget {
  const _ProfileAction(
      {required this.icon, required this.title, required this.onTap});

  final IconData icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        leading: Icon(icon, color: RiwaqColors.primary),
        title: Text(title,
            style: TextStyle(
                fontWeight: FontWeight.w700, color: RiwaqColors.text)),
        trailing: Icon(Icons.chevron_left_rounded, color: RiwaqColors.muted),
        onTap: onTap,
      );
}
