import 'package:flutter/material.dart';

import '../data/repositories/location_repository.dart';
import '../l10n/riwaq_text.dart';
import '../models/hospital_location.dart';
import '../services/riwaq_local_store.dart';
import '../theme/app_theme.dart';

class SavedLocationsScreen extends StatelessWidget {
  const SavedLocationsScreen({super.key, required this.onOpenMap});

  final ValueChanged<String?> onOpenMap;

  Future<void> _showAddLocationSheet(BuildContext context) async {
    final store = RiwaqLocalStore.instance;
    final allLocations = const LocationRepository().getAll();
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
          children: [
            Text(riwaqText('اختر موقعاً لحفظه', 'Choose a location to save'),
                style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    color: RiwaqColors.text)),
            const SizedBox(height: 8),
            for (final location
                in allLocations.where((item) => !store.isSaved(item.id)))
              ListTile(
                leading: const Icon(Icons.location_on_outlined,
                    color: RiwaqColors.primary),
                title: Text(riwaqPlaceName(location.id, location.nameAr)),
                subtitle: Text(riwaqFloorName(
                    location.floor == 0
                        ? 'GROUND'
                        : location.floor == 1
                            ? 'FIRST'
                            : 'SECOND',
                    _floorName(location.floor))),
                onTap: () async {
                  await store.toggleSaved(location.id);
                  if (sheetContext.mounted) Navigator.of(sheetContext).pop();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(riwaqText(
                          'تم حفظ ${riwaqPlaceName(location.id, location.nameAr)}',
                          'Saved ${riwaqPlaceName(location.id, location.nameAr)}',
                        )),
                      ),
                    );
                  }
                },
              ),
            if (allLocations.every((item) => store.isSaved(item.id)))
              Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                    riwaqText('تم حفظ جميع المواقع المتاحة.',
                        'All available locations are saved.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: RiwaqColors.muted)),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = RiwaqLocalStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final saved = const LocationRepository()
            .getAll()
            .where((item) => store.isSaved(item.id))
            .toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
          children: [
            Row(
              children: [
                Expanded(
                    child: Text(
                        riwaqText(
                          'احتفظ بوجهاتك المتكررة لتصل إليها بسرعة في زيارتك القادمة.',
                          'Save frequent destinations for quick access on your next visit.',
                        ),
                        style: TextStyle(color: RiwaqColors.muted))),
                IconButton.filledTonal(
                  tooltip: riwaqText('إضافة موقع محفوظ', 'Add saved location'),
                  onPressed: () => _showAddLocationSheet(context),
                  icon: const Icon(Icons.add_location_alt_outlined),
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (saved.isEmpty)
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                    color: RiwaqColors.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: RiwaqColors.border)),
                child: Column(
                  children: [
                    Icon(Icons.bookmark_add_outlined,
                        size: 34, color: RiwaqColors.primary),
                    SizedBox(height: 10),
                    Text(
                        riwaqText('لا توجد مواقع محفوظة بعد',
                            'No saved locations yet'),
                        style: TextStyle(
                            color: RiwaqColors.text,
                            fontWeight: FontWeight.w800)),
                    SizedBox(height: 4),
                    Text(
                        riwaqText('استخدم زر الإضافة لحفظ عيادة أو خدمة.',
                            'Use the add button to save a clinic or service.'),
                        textAlign: TextAlign.center,
                        style:
                            TextStyle(color: RiwaqColors.muted, fontSize: 12)),
                  ],
                ),
              ),
            for (final location in saved)
              _SavedLocationCard(location: location, onOpenMap: onOpenMap),
          ],
        );
      },
    );
  }
}

class _SavedLocationCard extends StatelessWidget {
  const _SavedLocationCard({required this.location, required this.onOpenMap});

  final HospitalLocation location;
  final ValueChanged<String?> onOpenMap;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsetsDirectional.only(
              start: 15, top: 10, bottom: 10, end: 8),
          child: Row(
            children: [
              CircleAvatar(
                  backgroundColor: RiwaqColors.mint,
                  child:
                      Icon(Icons.bookmark_rounded, color: RiwaqColors.primary)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(riwaqPlaceName(location.id, location.nameAr),
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: RiwaqColors.text)),
                    const SizedBox(height: 4),
                    Text(
                        riwaqText(
                            'الدور ${_floorName(location.floor)}',
                            riwaqFloorName(
                                location.floor == 0
                                    ? 'GROUND'
                                    : location.floor == 1
                                        ? 'FIRST'
                                        : 'SECOND',
                                _floorName(location.floor))),
                        style:
                            TextStyle(color: RiwaqColors.muted, fontSize: 12)),
                  ],
                ),
              ),
              IconButton(
                tooltip: riwaqText('افتح على الخريطة', 'Open on map'),
                onPressed: () => onOpenMap(location.id),
                icon: const Icon(Icons.directions_outlined,
                    color: RiwaqColors.primary),
              ),
              IconButton(
                tooltip: riwaqText('إزالة من المحفوظات', 'Remove from saved'),
                onPressed: () async {
                  await RiwaqLocalStore.instance.toggleSaved(location.id);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(riwaqText(
                          'تمت إزالة ${riwaqPlaceName(location.id, location.nameAr)}',
                          'Removed ${riwaqPlaceName(location.id, location.nameAr)}',
                        )),
                      ),
                    );
                  }
                },
                icon: Icon(Icons.bookmark_remove_outlined,
                    color: RiwaqColors.muted),
              ),
            ],
          ),
        ),
      );
}

String _floorName(int floor) => floor == 0
    ? 'الأرضي'
    : floor == 1
        ? 'الأول'
        : floor == 2
            ? 'الثاني'
            : '$floor';
