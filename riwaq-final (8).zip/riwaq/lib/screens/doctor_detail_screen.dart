import 'package:flutter/material.dart';

import '../data/repositories/doctor_repository.dart';
import '../data/repositories/location_repository.dart';
import '../data/specialty_data.dart';
import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';

class DoctorDetailScreen extends StatelessWidget {
  const DoctorDetailScreen({
    super.key,
    required this.doctorId,
    required this.onOpenMap,
  });

  final String doctorId;
  final ValueChanged<String?> onOpenMap;

  @override
  Widget build(BuildContext context) {
    final doctor = const DoctorRepository().byId(doctorId);
    if (doctor == null) {
      return _DetailMessage(
          message: riwaqText('تعذر العثور على بيانات الطبيب.', 'Doctor details not found.'));
    }
    final specialty =
        specialties.where((item) => item.id == doctor.specialtyId).firstOrNull;
    final floorName = doctor.floor == 0
        ? 'الأرضي'
        : doctor.floor == 1
            ? 'الأول'
            : doctor.floor == 2
                ? 'الثاني'
                : '${doctor.floor}';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
      children: [
        Center(
          child: CircleAvatar(
            radius: 40,
            backgroundColor: RiwaqColors.mint,
            child: Text(
              doctor.initials,
              style: TextStyle(
                  color: RiwaqColors.primaryDark,
                  fontSize: 22,
                  fontWeight: FontWeight.w800),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Text(riwaqLocalizedValue(doctor.name),
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 21,
                fontWeight: FontWeight.w900,
                color: RiwaqColors.text)),
        const SizedBox(height: 5),
        Text(riwaqLocalizedValue(doctor.specialty),
            textAlign: TextAlign.center,
            style: TextStyle(color: RiwaqColors.muted)),
        const SizedBox(height: 24),
        _DetailRow(
            icon: Icons.medical_services_outlined,
            label: riwaqText('التخصص', 'Specialty'),
            value: riwaqLocalizedValue(specialty?.nameAr ?? doctor.specialty)),
        _DetailRow(
            icon: Icons.schedule_rounded,
            label: riwaqText('التوفر المسجل', 'Listed availability'),
            value: riwaqLocalizedValue(doctor.availability)),
        _DetailRow(
          icon: Icons.location_on_outlined,
          label: riwaqText('العيادة', 'Clinic'),
          value:
              '${riwaqPlaceName(doctor.locationId, const LocationRepository().byId(doctor.locationId)?.nameAr ?? specialty?.nameAr ?? doctor.specialty)} · ${riwaqText('الدور $floorName', riwaqFloorName(doctor.floor == 0 ? 'GROUND' : doctor.floor == 1 ? 'FIRST' : 'SECOND', floorName))}',
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => onOpenMap(doctor.locationId),
          icon: const Icon(Icons.directions_outlined),
          label: Text(riwaqText('اعرض العيادة على الخريطة', 'Open clinic on map')),
        ),
        const SizedBox(height: 10),
        Text(
          riwaqText(
            'معلومات الطبيب والمواعيد بيانات توضيحية محلية، وليست حجزاً مؤكداً.',
            'Doctor and appointment details are local examples, not confirmed bookings.',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: RiwaqColors.muted, fontSize: 12, height: 1.5),
        ),
      ],
    );
  }
}

class _DetailMessage extends StatelessWidget {
  const _DetailMessage({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(message,
              textAlign: TextAlign.center,
              style: TextStyle(color: RiwaqColors.muted)),
        ),
      );
}

class _DetailRow extends StatelessWidget {
  const _DetailRow(
      {required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: RiwaqColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: RiwaqColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: RiwaqColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: TextStyle(color: RiwaqColors.muted, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(value,
                      style: TextStyle(
                          color: RiwaqColors.text,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        ),
      );
}
