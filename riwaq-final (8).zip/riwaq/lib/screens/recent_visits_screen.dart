import 'package:flutter/material.dart';

import '../data/mock_data.dart';
import '../l10n/riwaq_text.dart';
import '../data/repositories/location_repository.dart';
import '../theme/app_theme.dart';

class RecentVisitsScreen extends StatelessWidget {
  const RecentVisitsScreen({
    super.key,
    required this.onOpenMap,
    required this.onOpenDoctor,
  });

  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String> onOpenDoctor;

  @override
  Widget build(BuildContext context) {
    if (recentVisits.isEmpty) {
      return Center(
          child: Text(riwaqText('ستظهر زياراتك هنا بعد استخدامها.',
              'Your visits will appear here after you use them.'),
              style: TextStyle(color: RiwaqColors.muted)));
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
      children: [
        Text(riwaqText(
            'يمكنك الرجوع بسرعة إلى الأماكن التي زرتها سابقاً.',
            'Quickly return to places you visited before.'),
            style: TextStyle(color: RiwaqColors.muted)),
        const SizedBox(height: 14),
        for (final visit in recentVisits)
          Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => onOpenMap(visit.locationId),
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: RiwaqColors.mint,
                      child: Icon(Icons.history_rounded,
                          color: RiwaqColors.primaryDark),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                    Text(riwaqLocalizedValue(visit.title),
                              style: TextStyle(
                                  color: RiwaqColors.text,
                                  fontWeight: FontWeight.w800)),
                          const SizedBox(height: 3),
                          Text(riwaqLocalizedValue(visit.subtitle),
                               style: TextStyle(
                                  color: RiwaqColors.muted, fontSize: 12)),
                          const SizedBox(height: 4),
                          Text(
                            '${riwaqLocalizedValue(visit.date)} · ${riwaqPlaceName(visit.locationId, const LocationRepository().byId(visit.locationId)?.nameAr ?? visit.locationId)}',
                            style: TextStyle(
                                color: RiwaqColors.muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    if (visit.doctorId != null)
                      IconButton(
                      tooltip: riwaqText('عرض الطبيب', 'View doctor'),
                        onPressed: () => onOpenDoctor(visit.doctorId!),
                        icon: const Icon(Icons.person_search_outlined,
                            color: RiwaqColors.primary),
                      )
                    else
                      Icon(Icons.chevron_left_rounded,
                          color: RiwaqColors.muted),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
