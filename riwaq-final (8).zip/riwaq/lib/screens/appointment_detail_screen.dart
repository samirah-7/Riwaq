import 'package:flutter/material.dart';

import '../data/repositories/appointment_repository.dart';
import '../data/repositories/doctor_repository.dart';
import '../data/repositories/location_repository.dart';
import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';

class AppointmentDetailScreen extends StatelessWidget {
  const AppointmentDetailScreen({
    super.key,
    required this.appointmentId,
    required this.onOpenMap,
    required this.onOpenDoctor,
  });

  final String appointmentId;
  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String> onOpenDoctor;

  @override
  Widget build(BuildContext context) {
    final appointment = const AppointmentRepository().byId(appointmentId);
    if (appointment == null) {
      return Center(
          child: Text(riwaqText('تعذر العثور على الموعد.', 'Appointment not found.'),
              style: TextStyle(color: RiwaqColors.muted)));
    }
    final doctor = const DoctorRepository().byId(appointment.doctorId);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
              color: RiwaqColors.mint, borderRadius: BorderRadius.circular(20)),
          child: Row(
            children: [
              Icon(Icons.calendar_month_rounded,
                  color: RiwaqColors.primaryDark, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(riwaqLocalizedValue(appointment.date),
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: RiwaqColors.text)),
                    const SizedBox(height: 4),
                    Text(riwaqLocalizedValue(appointment.time),
                        style: TextStyle(color: RiwaqColors.muted)),
                  ],
                ),
              ),
              Text(riwaqLocalizedValue(appointment.status),
                  style: TextStyle(
                      color: RiwaqColors.primaryDark,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Text(riwaqText('تفاصيل الموعد', 'Appointment details'),
            style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: RiwaqColors.text)),
        const SizedBox(height: 10),
        _AppointmentDetailRow(
            label: riwaqText('الطبيب', 'Doctor'),
            value: riwaqLocalizedValue(appointment.doctorName)),
        _AppointmentDetailRow(
            label: riwaqText('التخصص', 'Specialty'),
            value: riwaqLocalizedValue(appointment.specialty)),
        _AppointmentDetailRow(
          label: riwaqText('الموقع', 'Location'),
          value:
              riwaqPlaceName(
            appointment.locationId,
            const LocationRepository().byId(appointment.locationId)?.nameAr ??
                appointment.locationId,
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: () => onOpenMap(appointment.locationId),
          icon: const Icon(Icons.directions_outlined),
          label: Text(riwaqText('الوصول إلى العيادة', 'Open clinic on map')),
        ),
        if (doctor != null) ...[
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => onOpenDoctor(doctor.id),
            icon: const Icon(Icons.person_outline_rounded),
            label: Text(riwaqText('عرض ملف الطبيب', 'View doctor profile')),
          ),
        ],
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: RiwaqColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: RiwaqColors.border)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(riwaqText('تعديل أو إلغاء الموعد', 'Change or cancel appointment'),
                  style: TextStyle(
                      fontWeight: FontWeight.w800, color: RiwaqColors.text)),
              SizedBox(height: 5),
              Text(
                riwaqText(
                  'هذه النسخة تستخدم مواعيد تجريبية ولا تتصل بنظام حجز المستشفى؛ لا يمكن تعديل الموعد أو إلغاؤه من التطبيق.',
                  'This prototype uses sample appointments and is not connected to hospital booking; changes and cancellations are unavailable.',
                ),
                style: TextStyle(
                    color: RiwaqColors.muted, fontSize: 12, height: 1.5),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                      child: OutlinedButton(
                           onPressed: null,
                           child: Text(riwaqText('تعديل الموعد', 'Change appointment')))),
                  SizedBox(width: 8),
                  Expanded(
                      child: OutlinedButton(
                           onPressed: null,
                           child: Text(riwaqText('إلغاء الموعد', 'Cancel appointment')))),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AppointmentDetailRow extends StatelessWidget {
  const _AppointmentDetailRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            SizedBox(
                width: 92,
                child: Text(label,
                    style: TextStyle(color: RiwaqColors.muted))),
            Expanded(
                child: Text(value,
                    style: TextStyle(
                        color: RiwaqColors.text, fontWeight: FontWeight.w700))),
          ],
        ),
      );
}
