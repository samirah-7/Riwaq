import 'package:flutter/material.dart';

import '../data/hospital_floor_plan_data.dart';
import '../data/location_data.dart';
import '../services/location_state.dart';
import '../services/location_provider.dart';
import '../services/riwaq_local_store.dart';
import 'floor_plan_screen.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key, this.localizationProvider});
  final IndoorLocalizationProvider? localizationProvider;

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  @override
  void initState() {
    super.initState();
    final locationState = RiwaqLocationState.instance;
    if (locationState.currentLocationId == null) {
      locationState.setCurrent(locationId: 'MAIN_ENTRANCE', floor: 0);
    }
    if (locationState.destinationLocationId == null) {
      final defaultDestination = virtualLocations.firstWhere(
        (location) => location.id == 'EYE_CLINIC',
      );
      locationState.setDestination(
        locationId: defaultDestination.id,
        floor: defaultDestination.floor,
      );
    }
  }

  void _openRegisteredDestination(String id) {
    final location =
        virtualLocations.where((item) => item.id == id).firstOrNull;
    if (location != null) {
      RiwaqLocationState.instance
          .setDestination(locationId: location.id, floor: location.floor);
      return;
    }
    final place = findHospitalPlace(id);
    if (place == null) return;
    final floor =
        hospitalFloorPlans.firstWhere((item) => item.id == place.floorId);
    RiwaqLocationState.instance.setDestination(
      locationId: place.mapLocationId ?? place.id,
      floor: floor.level,
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge(
            [RiwaqLocalStore.instance, RiwaqLocationState.instance]),
        builder: (context, _) => SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
            children: [
              FloorPlanScreen(
                onOpenMap: _openRegisteredDestination,
                localizationProvider: widget.localizationProvider,
                destinationLocationId:
                    RiwaqLocationState.instance.destinationLocationId,
              ),
            ],
          ),
        ),
      );
}
