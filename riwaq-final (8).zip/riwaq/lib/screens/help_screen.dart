import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';

class HelpScreen extends StatefulWidget {
  const HelpScreen({super.key});

  @override
  State<HelpScreen> createState() => _HelpScreenState();
}

class _HelpScreenState extends State<HelpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _messageController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(riwaqText(
          'النموذج صحيح، لكن لا يوجد اتصال بخدمة الدعم؛ لم يتم إرسال رسالتك.',
          'The message is valid, but support is not connected; it was not sent.',
        )),
        duration: Duration(seconds: 4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
        children: [
          Text(riwaqText('أسئلة شائعة', 'Frequently asked questions'),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: RiwaqColors.text)),
          const SizedBox(height: 8),
          _HelpQuestion(
            question: riwaqText('هل الخريطة تعرض مساراً حقيقياً؟',
                'Does the map show a real route?'),
            answer: riwaqText(
              'لا. المسار محسوب على شبكة تجريبية لمخطط توضيحي، وليس إرشاداً فعلياً. يبدأ الموقع الافتراضي من المدخل الرئيسي، ويمكن تغيير نقطة البداية يدوياً.',
              'No. Routes use a simulated network on an illustrative plan, not real directions. The default start is the main entrance, and you can change it manually.',
            ),
          ),
          _HelpQuestion(
            question:
                riwaqText('هل المواعيد مؤكدة؟', 'Are appointments confirmed?'),
            answer: riwaqText(
              'لا. بيانات الأطباء والمواعيد محلية لأغراض العرض، ولا تتصل بنظام حجز المستشفى.',
              'No. Doctor and appointment details are local examples and are not connected to hospital booking.',
            ),
          ),
          _HelpQuestion(
            question: riwaqText('هل يرسل المساعد أسئلتي إلى الإنترنت؟',
                'Does the assistant send my questions online?'),
            answer: riwaqText(
              'عند اتصال المساعد بالخدمة، تُرسل الرسائل الأخيرة لمعالجة الرد. عند تعذر الاتصال، يستخدم التطبيق رداً محلياً محدوداً.',
              'When connected, recent messages are sent to the assistant service to prepare a reply. If it is unavailable, the app uses a limited local fallback.',
            ),
          ),
          const SizedBox(height: 18),
          Text(riwaqText('تواصل مع الدعم', 'Contact support'),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: RiwaqColors.text)),
          const SizedBox(height: 5),
          Text(
              riwaqText(
                  'يمكنك تجهيز رسالة، لكن الإرسال غير متاح في هذه النسخة.',
                  'You can prepare a message, but sending is unavailable in this version.'),
              style: TextStyle(color: RiwaqColors.muted, fontSize: 12)),
          const SizedBox(height: 12),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      labelText: riwaqText('بريدك الإلكتروني (اختياري)',
                          'Email address (optional)'),
                      prefixIcon: Icon(Icons.mail_outline_rounded)),
                  validator: (value) {
                    final email = value?.trim() ?? '';
                    if (email.isNotEmpty &&
                        !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
                            .hasMatch(email)) {
                      return riwaqText('أدخل بريداً إلكترونياً صحيحاً.',
                          'Enter a valid email address.');
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _messageController,
                  minLines: 3,
                  maxLines: 5,
                  maxLength: 500,
                  decoration: InputDecoration(
                      labelText:
                          riwaqText('كيف يمكننا مساعدتك؟', 'How can we help?'),
                      alignLabelWithHint: true),
                  validator: (value) =>
                      (value == null || value.trim().length < 10)
                          ? riwaqText('اكتب ١٠ أحرف على الأقل.',
                              'Enter at least 10 characters.')
                          : null,
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _submit,
                    icon: const Icon(Icons.send_outlined),
                    label:
                        Text(riwaqText('تحقق من الرسالة', 'Validate message')),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
}

class _HelpQuestion extends StatelessWidget {
  const _HelpQuestion({required this.question, required this.answer});

  final String question;
  final String answer;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ExpansionTile(
          title: Text(question,
              style: TextStyle(
                  fontWeight: FontWeight.w700, color: RiwaqColors.text)),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          children: [
            Text(answer,
                style: TextStyle(color: RiwaqColors.muted, height: 1.5))
          ],
        ),
      );
}
