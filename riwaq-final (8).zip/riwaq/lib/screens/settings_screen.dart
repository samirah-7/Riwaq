import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../services/riwaq_local_store.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.onOpenHelp});

  final VoidCallback onOpenHelp;

  @override
  Widget build(BuildContext context) {
    final store = RiwaqLocalStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
        children: [
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading:
                const Icon(Icons.language_rounded, color: RiwaqColors.primary),
            title: Text(riwaqText('لغة التطبيق', 'App language')),
            subtitle: Text(riwaqText(
                'اختر العربية أو الإنجليزية', 'Choose Arabic or English')),
            trailing: DropdownButton<String>(
              value: store.languageCode,
              underline: const SizedBox.shrink(),
              items: const [
                DropdownMenuItem(value: 'ar', child: Text('العربية')),
                DropdownMenuItem(value: 'en', child: Text('English')),
              ],
              onChanged: (value) {
                if (value != null) store.setLanguageCode(value);
              },
            ),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            value: store.darkMode,
            onChanged: store.setDarkMode,
            title: Text(riwaqText('المظهر الداكن', 'Dark theme')),
            subtitle: Text(riwaqText('تطبيق المظهر الداكن على الشاشات.',
                'Use the dark appearance throughout the app.')),
            secondary: const Icon(Icons.dark_mode_outlined,
                color: RiwaqColors.primary),
          ),
          const Divider(height: 28),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            value: store.notificationsEnabled,
            onChanged: store.setNotificationsEnabled,
            title: Text(riwaqText('الإشعارات', 'Notifications')),
            subtitle: Text(riwaqText(
                'إظهار تذكيرات ومعلومات رِواق على هذا الجهاز.',
                'Show Riwaq reminders and information on this device.')),
            secondary: const Icon(Icons.notifications_active_outlined,
                color: RiwaqColors.primary),
          ),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            value: store.appointmentRemindersEnabled,
            onChanged: store.notificationsEnabled
                ? store.setAppointmentRemindersEnabled
                : null,
            title: Text(riwaqText('تذكيرات المواعيد', 'Appointment reminders')),
            subtitle: Text(
              store.notificationsEnabled
                  ? riwaqText('إعداد محلي؛ لا يرسل إشعارات فعلية حالياً.',
                      'Local setting; notifications are not sent yet.')
                  : riwaqText(
                      'فعّل الإشعارات أولاً.', 'Enable notifications first.'),
            ),
            secondary: const Icon(Icons.event_note_outlined,
                color: RiwaqColors.primary),
          ),
          Divider(color: RiwaqColors.border, height: 28),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: const Icon(Icons.privacy_tip_outlined,
                color: RiwaqColors.primary),
            title: Text(riwaqText('الخصوصية والبيانات', 'Privacy and data')),
            subtitle: Text(riwaqText('تعرف على ما يُحفظ على هذا الجهاز.',
                'See what is saved on this device.')),
            trailing:
                Icon(Icons.chevron_left_rounded, color: RiwaqColors.muted),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: riwaqText('رِواق', 'Riwaq'),
              applicationVersion: '1.0.0',
              children: [
                Text(riwaqText(
                    'هذا النموذج يحفظ المواقع والإعدادات والملف الشخصي محلياً. لا يوجد تسجيل دخول أو مزامنة أو اتصال بقاعدة بيانات مستشفى.',
                    'This prototype stores saved places, settings, and profile information locally. It has no sign-in, sync, or hospital database connection.')),
              ],
            ),
          ),
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: const Icon(Icons.help_outline_rounded,
                color: RiwaqColors.primary),
            title: Text(riwaqText('المساعدة والدعم', 'Help and support')),
            trailing:
                Icon(Icons.chevron_left_rounded, color: RiwaqColors.muted),
            onTap: onOpenHelp,
          ),
          const SizedBox(height: 20),
          Center(
            child: Text(
              riwaqText('رِواق 1.0.0 · نسخة تجريبية محلية',
                  'Riwaq 1.0.0 · Local prototype'),
              style: TextStyle(color: RiwaqColors.muted, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}
