import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/assistant_response.dart';
import '../l10n/riwaq_text.dart';
import '../services/ai/ai_provider.dart';
import '../services/ai/ai_service.dart';
import '../services/location_state.dart';
import '../data/location_data.dart';
import '../theme/app_theme.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen(
      {super.key,
      required this.onOpenMap,
      required this.onOpenDoctors,
      required this.onOpenAppointments,
      required this.onOpenDoctorDetails});
  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String?> onOpenDoctors;
  final VoidCallback onOpenAppointments;
  final ValueChanged<String> onOpenDoctorDetails;
  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _ChatEntry {
  const _ChatEntry(this.text, {this.user = false, this.response});
  final String text;
  final bool user;
  final AssistantResponse? response;
}

class _AssistantScreenState extends State<AssistantScreen> {
  final controller = TextEditingController();
  final scrollController = ScrollController();
  AiService ai = AiService();
  final messages = <_ChatEntry>[_welcomeMessage()];
  bool loading = false;
  String? failedInput;

  static _ChatEntry _welcomeMessage() => _ChatEntry(
        riwaqText(
          'أهلاً! أنا رِواق، مساعد يساعدك في العثور على الخدمات والعيادات ومواعيدك التجريبية.',
          'Hello, I’m Riwaq. I can help you find services, clinics, and demo appointments.',
        ),
        response: AssistantResponse(
            intent: AssistantIntent.general, message: '', confidence: 1),
      );

  void _newConversation() {
    if (loading) return;
    setState(() {
      ai = AiService();
      messages
        ..clear()
        ..add(_welcomeMessage());
      failedInput = null;
    });
    _scrollToEnd();
  }

  Future<void> _clearConversation() async {
    if (loading) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(riwaqText('مسح المحادثة؟', 'Clear this conversation?')),
        content: Text(riwaqText(
            'سيتم حذف الرسائل الظاهرة من هذه المحادثة على الجهاز.',
            'Visible messages in this conversation will be removed from this device.')),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: Text(riwaqText('إبقاء الرسائل', 'Keep messages'))),
          FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: Text(riwaqText('مسح', 'Clear'))),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() {
      ai = AiService();
      messages.clear();
      failedInput = null;
    });
  }

  Future<void> send([String? preset]) async {
    final value = (preset ?? controller.text).trim();
    if (value.isEmpty || loading) return;
    final previousTurns = messages.skip(1).map((entry) {
      final content =
          entry.user ? entry.text : entry.response?.message ?? entry.text;
      return AiChatTurn(
        role: entry.user ? 'user' : 'assistant',
        content: content,
      );
    }).toList(growable: false);
    final history = previousTurns.length > 8
        ? previousTurns.sublist(previousTurns.length - 8)
        : previousTurns;
    final currentLocationId = RiwaqLocationState.instance.currentLocationId;
    final destinationId = RiwaqLocationState.instance.destinationLocationId;
    setState(() {
      messages.add(_ChatEntry(value, user: true));
      loading = true;
      failedInput = null;
      controller.clear();
    });
    _scrollToEnd();
    try {
      final response = await ai.respond(
        value,
        history: history,
        currentLocationId: currentLocationId,
        destinationId: destinationId,
      );
      if (!mounted) return;
      setState(() {
        messages.add(_ChatEntry(response.message, response: response));
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        failedInput = value;
      });
    }
    _scrollToEnd();
  }

  void _scrollToEnd() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scrollController.hasClients) {
          scrollController.animateTo(scrollController.position.maxScrollExtent,
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOut);
        }
      });

  void _perform(String action, AssistantResponse response) {
    switch (action) {
      case 'call_emergency':
        _callEmergency();
        break;
      case 'view_doctors':
        widget.onOpenDoctors(response.specialtyId);
        break;
      case 'view_appointments':
        widget.onOpenAppointments();
        break;
      case 'view_details':
        if (response.doctorIds.isNotEmpty) {
          widget.onOpenDoctorDetails(response.doctorIds.first);
        }
        break;
      case 'open_map':
        final origin = response.originId;
        if (response.originWasSpecified && origin != null) {
          final origins = virtualLocations.where((location) => location.id == origin);
          if (origins.isNotEmpty) {
            final location = origins.first;
            RiwaqLocationState.instance.setCurrent(
              locationId: location.id,
              floor: location.floor,
            );
          }
        }
        final destination = response.destinationId;
        if (destination != null) {
          final matches = virtualLocations.where((l) => l.id == destination);
          if (matches.isNotEmpty) {
            final loc = matches.first;
            RiwaqLocationState.instance
                .setDestination(locationId: loc.id, floor: loc.floor);
          }
        }
        widget.onOpenMap(destination);
        break;
    }
  }

  Future<void> _callEmergency() async {
    var launched = false;
    try {
      launched = await launchUrl(Uri(scheme: 'tel', path: '997'));
    } catch (_) {
      launched = false;
    }
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(riwaqText('تعذر فتح الاتصال. اتصل بالإسعاف على 997.',
              'Could not open the dialer. Call emergency services at 997.'))));
    }
  }

  @override
  void dispose() {
    controller.dispose();
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(18, 2, 18, 0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  riwaqText(
                    'معلومات صحية عامة فقط دون تشخيص أو وصف علاج؛ بيانات المستشفى تجريبية. يستخدم المساعد قواعد محلية ولا يتصل بخدمة خارجية.',
                    'General information only, not diagnosis or treatment. Hospital data is sample data; this assistant uses local rules and does not contact an external service.',
                  ),
                  style: TextStyle(color: RiwaqColors.muted, fontSize: 11),
                ),
              ),
              PopupMenuButton<String>(
                tooltip: riwaqText('إدارة المحادثة', 'Conversation options'),
                enabled: !loading,
                onSelected: (value) {
                  if (value == 'new') _newConversation();
                  if (value == 'clear') _clearConversation();
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                      value: 'new',
                      child:
                          Text(riwaqText('محادثة جديدة', 'New conversation'))),
                  PopupMenuItem(
                      value: 'clear',
                      child: Text(
                          riwaqText('مسح المحادثة', 'Clear conversation'))),
                ],
                icon: const Icon(Icons.more_horiz_rounded),
              ),
            ],
          ),
        ),
        Expanded(
            child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.all(18),
                children: [
              ...messages.map((m) => Align(
                  alignment: m.user
                      ? AlignmentDirectional.centerEnd
                      : AlignmentDirectional.centerStart,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 310),
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        color:
                            m.user
                                ? Theme.of(context).colorScheme.primary
                                : RiwaqColors.surface,
                        borderRadius: BorderRadius.circular(18),
                        border: m.user
                            ? null
                            : Border.all(color: RiwaqColors.border)),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(m.text,
                              style: TextStyle(
                                  height: 1.5,
                                  color: m.user
                                       ? Theme.of(context).colorScheme.onPrimary
                                      : RiwaqColors.text)),
                          if (m.response != null &&
                              m.response!.actions.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Wrap(
                                spacing: 6,
                                runSpacing: 4,
                                children: m.response!.actions
                                    .map((action) => _ActionChip(
                                        action: action,
                                        onTap: () =>
                                            _perform(action, m.response!)))
                                    .toList()),
                          ],
                          if (m.response != null &&
                              m.response!.doctorIds.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            _ActionChip(
                                action: 'view_details',
                                onTap: () =>
                                    _perform('view_details', m.response!)),
                          ]
                        ]),
                  ))),
              if (loading)
                const Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                        padding: EdgeInsets.all(10),
                        child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2)))),
              if (failedInput != null)
                Row(children: [
                  Expanded(
                      child: Text(
                          riwaqText('تعذر إعداد الرد. حاول مرة أخرى.',
                              'Could not prepare a reply. Try again.'),
                          style: TextStyle(color: RiwaqColors.muted))),
                  TextButton(
                      onPressed: () => send(failedInput),
                      child: Text(riwaqText('إعادة المحاولة', 'Try again')))
                ]),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _Suggestion(
                    label: riwaqText(
                        'وين عيادة العيون؟', 'Where is the eye clinic?'),
                    onTap: () => send(riwaqText(
                        'وين عيادة العيون؟', 'Where is the eye clinic?'))),
                _Suggestion(
                    label: riwaqText('أبحث عن طبيب أسنان', 'Find a dentist'),
                    onTap: () => send(
                        riwaqText('أبحث عن طبيب أسنان', 'Find a dentist'))),
                _Suggestion(
                    label: riwaqText(
                        'ما مواعيدي القادمة؟', 'My next appointments'),
                    onTap: () => send(riwaqText(
                        'ما مواعيدي القادمة؟', 'My next appointments'))),
                _Suggestion(
                    label: riwaqText('وين الصيدلية؟', 'Where is the pharmacy?'),
                    onTap: () => send(
                        riwaqText('وين الصيدلية؟', 'Where is the pharmacy?'))),
                _Suggestion(
                    label: riwaqText(
                        'كيف أصل للأشعة؟', 'How do I get to radiology?'),
                    onTap: () => send(riwaqText('كيف أوصل لقسم الأشعة؟',
                        'How do I get to radiology?'))),
              ]),
            ])),
        Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
            child: Row(children: [
              Expanded(
                  child: TextField(
                      controller: controller,
                      onSubmitted: (_) => send(),
                      textInputAction: TextInputAction.send,
                      decoration: InputDecoration(
                          hintText: riwaqText('اكتب سؤالك هنا...',
                              'Type your question here...'),
                          isDense: true))),
              const SizedBox(width: 8),
              IconButton.filled(
                  onPressed: loading ? null : () => send(),
                  icon: const Icon(Icons.send_rounded),
                  style: IconButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Theme.of(context).colorScheme.onPrimary,
                  )),
            ])),
      ]);
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.action, required this.onTap});
  final String action;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final label = switch (action) {
      'call_emergency' =>
        riwaqText('اتصال بالإسعاف 997', 'Call emergency services 997'),
      'view_doctors' => riwaqText('عرض الأطباء', 'View doctors'),
      'view_appointments' => riwaqText('مواعيدي', 'Appointments'),
      'open_map' => riwaqText('الوصول إلى الموقع', 'Open location on map'),
      'view_details' => riwaqText('عرض التفاصيل', 'View details'),
      _ => action
    };
    return ActionChip(
        label: Text(label, style: const TextStyle(fontSize: 11)),
        onPressed: onTap,
        side: BorderSide(color: RiwaqColors.border));
  }
}

class _Suggestion extends StatelessWidget {
  const _Suggestion({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ActionChip(
      label: Text(label, style: const TextStyle(fontSize: 11)),
      onPressed: onTap,
      side: BorderSide(color: RiwaqColors.border),
      backgroundColor: RiwaqColors.surface);
}
