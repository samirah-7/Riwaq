import 'package:flutter/material.dart';

import '../data/repositories/doctor_repository.dart';
import '../data/specialty_data.dart';
import '../l10n/riwaq_text.dart';
import '../services/ai/arabic_text.dart';
import '../theme/app_theme.dart';

class DoctorsScreen extends StatefulWidget {
  const DoctorsScreen({
    super.key,
    this.initialSpecialtyId,
    required this.onOpenMap,
    required this.onOpenDoctorDetails,
  });

  final String? initialSpecialtyId;
  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String> onOpenDoctorDetails;

  @override
  State<DoctorsScreen> createState() => _DoctorsScreenState();
}

class _DoctorsScreenState extends State<DoctorsScreen> {
  final _searchController = TextEditingController();
  String query = '';
  String? specialtyId;

  @override
  void initState() {
    super.initState();
    specialtyId = widget.initialSpecialtyId;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final normalizedQuery = normalizeArabic(query);
    final filtered = const DoctorRepository().getAll().where((doctor) {
      final matchesSpecialty =
          specialtyId == null || doctor.specialtyId == specialtyId;
      final searchable = normalizeArabic(
          '${doctor.name} ${riwaqLocalizedValue(doctor.name)} ${doctor.specialty} ${riwaqLocalizedValue(doctor.specialty)} ${doctor.departmentId}');
      return matchesSpecialty &&
          (normalizedQuery.isEmpty || searchable.contains(normalizedQuery));
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
      children: [
        Text(riwaqText(
            'ابحث بالاسم أو التخصص، ثم افتح ملف الطبيب أو موقع العيادة.',
            'Search by name or specialty, then open the doctor profile or clinic location.'),
            style: TextStyle(color: RiwaqColors.muted)),
        const SizedBox(height: 14),
        TextField(
          controller: _searchController,
          onChanged: (value) => setState(() => query = value),
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search_rounded),
            hintText: riwaqText('ابحث باسم الطبيب أو التخصص', 'Search doctors or specialties'),
            suffixIcon: query.isEmpty
                ? null
                : IconButton(
                     tooltip: riwaqText('مسح البحث', 'Clear search'),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => query = '');
                    },
                    icon: const Icon(Icons.close_rounded),
                  ),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 7,
          runSpacing: 5,
          children: [
            ChoiceChip(
                label: Text(riwaqText('الكل', 'All')),
                selected: specialtyId == null,
                onSelected: (_) => setState(() => specialtyId = null)),
            ...specialties.map(
              (specialty) => ChoiceChip(
                label: Text(riwaqLocalizedValue(specialty.nameAr)),
                selected: specialtyId == specialty.id,
                onSelected: (_) => setState(() => specialtyId = specialty.id),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (filtered.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
                color: RiwaqColors.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: RiwaqColors.border)),
            child: Column(
              children: [
                Icon(Icons.person_search_outlined,
                    color: RiwaqColors.muted, size: 32),
                SizedBox(height: 8),
                Text(riwaqText('لا توجد نتائج مطابقة', 'No matching doctors'),
                    style: TextStyle(
                        fontWeight: FontWeight.w800, color: RiwaqColors.text)),
                SizedBox(height: 4),
                Text(riwaqText('جرّب اسماً أو تخصصاً آخر.',
                    'Try another name or specialty.'),
                    style: TextStyle(color: RiwaqColors.muted, fontSize: 12)),
              ],
            ),
          ),
        for (final doctor in filtered)
          Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => widget.onOpenDoctorDetails(doctor.id),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: RiwaqColors.mint,
                      child: Text(riwaqLocalizedValue(doctor.initials),
                          style: TextStyle(
                              color: RiwaqColors.primaryDark,
                              fontWeight: FontWeight.w800)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(riwaqLocalizedValue(doctor.name),
                              style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: RiwaqColors.text)),
                          const SizedBox(height: 4),
                          Text(riwaqLocalizedValue(doctor.specialty),
                               style: TextStyle(
                                  color: RiwaqColors.muted, fontSize: 12)),
                          const SizedBox(height: 6),
                          Text(riwaqLocalizedValue(doctor.availability),
                               style: TextStyle(
                                  color: RiwaqColors.primaryDark,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text(riwaqText(
                              'الدور ${_floorName(doctor.floor)}',
                              riwaqFloorName(
                                  doctor.floor == 0
                                      ? 'GROUND'
                                      : doctor.floor == 1
                                          ? 'FIRST'
                                          : 'SECOND',
                                  _floorName(doctor.floor))),
                               style: TextStyle(
                                  color: RiwaqColors.muted, fontSize: 11)),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 4,
                            children: [
                              TextButton(
                                onPressed: () =>
                                    widget.onOpenDoctorDetails(doctor.id),
                                child: Text(riwaqText('التفاصيل', 'Details')),
                              ),
                              TextButton.icon(
                                onPressed: () =>
                                    widget.onOpenMap(doctor.locationId),
                                icon: const Icon(Icons.directions_outlined,
                                    size: 16),
                                label: Text(riwaqText('موقع العيادة', 'Clinic location')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        const SizedBox(height: 6),
        Text(
          riwaqText(
            'التوفر المعروض عينة محلية، وليس جدول مواعيد مباشراً.',
            'Availability is sample data, not a live schedule.',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: RiwaqColors.muted, fontSize: 11),
        ),
      ],
    );
  }
}

String _floorName(int floor) => floor == 0
    ? 'الأرضي'
    : floor == 1
        ? 'الأول'
        : floor == 2
            ? 'الثاني'
            : '$floor';
