import 'package:flutter/material.dart';

import '../data/mock_data.dart';
import '../l10n/riwaq_text.dart';
import '../models/app_notification.dart';
import '../services/riwaq_local_store.dart';
import '../theme/app_theme.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({
    super.key,
    required this.onOpenMap,
    required this.onOpenAppointment,
  });

  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String> onOpenAppointment;

  @override
  Widget build(BuildContext context) {
    final store = RiwaqLocalStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final notifications = appNotifications
            .where((item) => !store.dismissedNotificationIds.contains(item.id))
            .toList();
        final unread = notifications
            .where((item) => !store.readNotificationIds.contains(item.id))
            .length;
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 28),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    unread == 0
                        ? riwaqText(
                            'لا توجد إشعارات جديدة.', 'No new notifications.')
                        : riwaqText(
                            'لديك $unread إشعارات غير مقروءة.',
                            'You have $unread unread notifications.',
                          ),
                    style: TextStyle(color: RiwaqColors.muted),
                  ),
                ),
                if (notifications.isNotEmpty)
                  PopupMenuButton<String>(
                    tooltip: riwaqText('خيارات الإشعارات', 'Notification options'),
                    onSelected: (value) async {
                      if (value == 'read') {
                        await store.markNotificationsRead(
                            notifications.map((item) => item.id));
                      } else {
                        await store.dismissNotifications(
                            notifications.map((item) => item.id));
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(
                          value: 'read',
                          child: Text(
                              riwaqText('تعليم الكل كمقروء', 'Mark all as read'))),
                      PopupMenuItem(
                          value: 'clear',
                          child: Text(
                              riwaqText('مسح الإشعارات', 'Clear notifications'))),
                    ],
                    icon: const Icon(Icons.more_horiz_rounded),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (notifications.isEmpty)
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                    color: RiwaqColors.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: RiwaqColors.border)),
                child: Column(
                  children: [
                    Icon(Icons.notifications_off_outlined,
                        size: 36, color: RiwaqColors.muted),
                    SizedBox(height: 10),
                    Text(riwaqText('لا توجد إشعارات', 'No notifications'),
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: RiwaqColors.text)),
                    SizedBox(height: 4),
                    Text(riwaqText(
                        'ستظهر هنا التذكيرات والمعلومات المهمة.',
                        'Reminders and important updates will appear here.'),
                        textAlign: TextAlign.center,
                        style:
                            TextStyle(color: RiwaqColors.muted, fontSize: 12)),
                  ],
                ),
              ),
            for (final notification in notifications)
              _NotificationCard(
                notification: notification,
                isRead: store.readNotificationIds.contains(notification.id),
                onOpen: () async {
                  await store.markNotificationRead(notification.id);
                  if (!context.mounted) return;
                  if (notification.appointmentId != null) {
                    onOpenAppointment(notification.appointmentId!);
                  } else if (notification.locationId != null) {
                    onOpenMap(notification.locationId);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(riwaqText(
                            'تم تعليم الإشعار كمقروء.',
                            'Notification marked as read.')),
                      ),
                    );
                  }
                },
              ),
          ],
        );
      },
    );
  }
}

class _NotificationCard extends StatelessWidget {
  const _NotificationCard(
      {required this.notification, required this.isRead, required this.onOpen});

  final AppNotification notification;
  final bool isRead;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final icon = switch (notification.kind) {
      AppNotificationKind.appointment => Icons.calendar_month_outlined,
      AppNotificationKind.location => Icons.place_outlined,
      AppNotificationKind.general => Icons.info_outline_rounded,
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onOpen,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor:
                    isRead ? RiwaqColors.background : RiwaqColors.mint,
                child: Icon(icon,
                    color:
                        isRead ? RiwaqColors.muted : RiwaqColors.primaryDark),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: Text(riwaqLocalizedValue(notification.title),
                                style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: RiwaqColors.text))),
                        if (!isRead)
                          const CircleAvatar(
                              radius: 4, backgroundColor: RiwaqColors.primary),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(riwaqLocalizedValue(notification.message),
                        style: TextStyle(
                            color: RiwaqColors.muted,
                            fontSize: 12,
                            height: 1.45)),
                    const SizedBox(height: 7),
                    Text(riwaqLocalizedValue(notification.dateLabel),
                        style: TextStyle(
                            color: RiwaqColors.muted, fontSize: 10)),
                  ],
                ),
              ),
              const SizedBox(width: 4),
              Icon(Icons.chevron_left_rounded, color: RiwaqColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}
