import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../data/location_data.dart';
import '../data/repositories/appointment_repository.dart';
import '../models/appointment.dart';
import '../services/ai/arabic_text.dart';
import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';
import '../widgets/section_title.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.onOpenMap,
    required this.onOpenDoctors,
    required this.onOpenAssistant,
    required this.onOpenAppointments,
    required this.onOpenVision,
    required this.onOpenAppointmentDetails,
    required this.onOpenRecentVisits,
    required this.onOpenSavedLocations,
  });

  final ValueChanged<String?> onOpenMap;
  final ValueChanged<String?> onOpenDoctors;
  final VoidCallback onOpenAssistant;
  final VoidCallback onOpenAppointments;
  final VoidCallback onOpenVision;
  final ValueChanged<String> onOpenAppointmentDetails;
  final VoidCallback onOpenRecentVisits;
  final VoidCallback onOpenSavedLocations;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final normalizedQuery = normalizeArabic(_query);
    final matches = normalizedQuery.isEmpty
        ? const []
        : virtualLocations.where((location) {
            final searchable = normalizeArabic(
                '${location.nameAr} ${riwaqPlaceName(location.id, location.nameAr)} ${location.keywords.join(' ')}');
            return searchable.contains(normalizedQuery);
          }).toList();
    final nextAppointment = const AppointmentRepository().getAll().firstOrNull;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
      children: [
        Text(
          riwaqText('نتمنى لك زيارة ميسّرة', 'Wishing you an easy visit'),
          style: Theme.of(context)
              .textTheme
              .bodyMedium
              ?.copyWith(color: RiwaqColors.muted),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _searchController,
          textInputAction: TextInputAction.search,
          onChanged: (value) => setState(() => _query = value),
          onSubmitted: (_) {
            if (matches.isNotEmpty) widget.onOpenMap(matches.first.id);
          },
          decoration: InputDecoration(
            prefixIcon: Padding(
              padding: const EdgeInsets.all(13),
              child: SvgPicture.asset('assets/images/26c04.svg',
                  width: 19, height: 19),
            ),
            hintText: riwaqText('ابحث عن عيادة أو خدمة', 'Search clinics and services'),
            suffixIcon: _query.isEmpty
                ? null
                : IconButton(
                    tooltip: riwaqText('مسح البحث', 'Clear search'),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _query = '');
                    },
                    icon: const Icon(Icons.close_rounded),
                  ),
          ),
        ),
        if (_query.trim().isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 6),
            decoration: BoxDecoration(
                color: RiwaqColors.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: RiwaqColors.border)),
            child: matches.isEmpty
                ? Padding(
                    padding: EdgeInsets.all(14),
                    child: Text(
                        riwaqText(
                          'لا توجد وجهة مطابقة. جرّب اسم عيادة أو خدمة أخرى.',
                          'No matching destination. Try another clinic or service.',
                        ),
                        style: TextStyle(color: RiwaqColors.muted)),
                  )
                : Column(
                    children: [
                      for (final location in matches)
                        ListTile(
                          dense: true,
                          leading: const Icon(Icons.location_on_outlined,
                              color: RiwaqColors.primary),
                          title: Text(riwaqPlaceName(location.id, location.nameAr)),
                           trailing: Icon(Icons.chevron_left_rounded,
                              color: RiwaqColors.muted),
                          onTap: () => widget.onOpenMap(location.id),
                        ),
                    ],
                  ),
          ),
        const SizedBox(height: 18),
        if (nextAppointment != null)
          _UpcomingAppointmentCard(
            appointment: nextAppointment,
            onOpenDetails: () =>
                widget.onOpenAppointmentDetails(nextAppointment.id),
            onOpenMap: () => widget.onOpenMap(nextAppointment.locationId),
          ),
        const SizedBox(height: 22),
        SectionTitle(title: riwaqText('الخدمات السريعة', 'Quick services')),
        const SizedBox(height: 12),
        LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 380;
            final columns = compact
                ? 1
                : constraints.maxWidth >= 1000
                    ? 4
                    : constraints.maxWidth >= 640
                        ? 3
                        : 2;
            final services = [
              _ServiceTile(
                icon: Icons.map_outlined,
                title: riwaqText('اعثر على موقع', 'Find a location'),
                subtitle: riwaqText('العيادات والخدمات', 'Clinics and services'),
                onTap: () => widget.onOpenMap(null),
                assetPath: 'assets/images/19cc2.svg',
                compact: compact,
              ),
              _ServiceTile(
                icon: Icons.medical_services_outlined,
                title: riwaqText('ابحث عن طبيب', 'Find a doctor'),
                subtitle: riwaqText('التخصصات والتوفر', 'Specialties and availability'),
                onTap: () => widget.onOpenDoctors(null),
                assetPath: 'assets/images/6ce54.svg',
                compact: compact,
              ),
              _ServiceTile(
                icon: Icons.smart_toy_outlined,
                title: riwaqText('اسأل رِواق', 'Ask Riwaq'),
                subtitle: riwaqText('مساعد محلي', 'Local assistant'),
                onTap: widget.onOpenAssistant,
                tint: const Color(0xFFE6F5E8),
                assetPath: 'assets/images/ba31d.svg',
                compact: compact,
              ),
              _ServiceTile(
                icon: Icons.calendar_month_outlined,
                title: riwaqText('مواعيدي', 'Appointments'),
                subtitle: riwaqText('تفاصيل الزيارة', 'Visit details'),
                onTap: widget.onOpenAppointments,
                assetPath: 'assets/images/d8410.svg',
                compact: compact,
              ),
              _ServiceTile(
                icon: Icons.camera_alt_outlined,
                title: riwaqText('التعرّف البصري', 'Visual recognition'),
                subtitle: riwaqText('تحقق من معلم مسجل', 'Check a registered marker'),
                onTap: widget.onOpenVision,
                tint: const Color(0xFFEAF1FB),
                compact: compact,
              ),
            ];
            return GridView.builder(
              itemCount: services.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                mainAxisExtent: compact ? 80 : 126,
              ),
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) => services[index],
            );
          },
        ),
        const SizedBox(height: 22),
        SectionTitle(title: riwaqText('وصول سريع', 'Quick access')),
        const SizedBox(height: 12),
        LayoutBuilder(
          builder: (context, constraints) {
            final tiles = [
              _QuickAccessTile(
                icon: Icons.history_rounded,
                title: riwaqText('آخر الزيارات', 'Recent visits'),
                subtitle: riwaqText(
                    'ارجع إلى عيادة أو قسم زرته سابقاً',
                    'Return to a clinic or department you visited'),
                onTap: widget.onOpenRecentVisits,
                tint: const Color(0xFFEAF1FB),
                assetPath: 'assets/images/cfa92.svg',
              ),
              _QuickAccessTile(
                icon: Icons.bookmark_border_rounded,
                title: riwaqText('العناوين المحفوظة', 'Saved locations'),
                subtitle: riwaqText(
                    'احتفظ بالوجهات التي تحتاج إليها',
                    'Keep the places you need close by'),
                onTap: widget.onOpenSavedLocations,
                tint: const Color(0xFFF2EAFB),
                assetPath: 'assets/images/c6428.svg',
              ),
            ];
            if (constraints.maxWidth >= 600) {
              return GridView.builder(
                itemCount: tiles.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  mainAxisExtent: 92,
                ),
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) => tiles[index],
              );
            }
            return Column(
              children: [
                tiles[0],
                const SizedBox(height: 10),
                tiles[1],
              ],
            );
          },
        ),
        const SizedBox(height: 18),
        Text(
          riwaqText(
            'المواعيد والوجهات المعروضة بيانات تجريبية، والخريطة الحالية توضيحية.',
            'Appointments and destinations are sample data; the map is illustrative.',
          ),
          textAlign: TextAlign.center,
          style: TextStyle(color: RiwaqColors.muted, fontSize: 11, height: 1.5),
        ),
      ],
    );
  }
}

class _UpcomingAppointmentCard extends StatelessWidget {
  const _UpcomingAppointmentCard({
    required this.appointment,
    required this.onOpenDetails,
    required this.onOpenMap,
  });

  final Appointment appointment;
  final VoidCallback onOpenDetails;
  final VoidCallback onOpenMap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          color: scheme.primary,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.calendar_today_rounded,
                    color: scheme.onPrimary, size: 17),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    riwaqText('موعدك القادم', 'Your next appointment'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: scheme.onPrimary, fontWeight: FontWeight.w700),
                  ),
                ),
                Spacer(),
                Icon(Icons.verified_outlined,
                    color: scheme.onPrimary.withAlpha(190), size: 18),
                SizedBox(width: 4),
                Text(riwaqText('تجريبي', 'Demo'),
                    style: TextStyle(
                        color: scheme.onPrimary.withAlpha(190), fontSize: 11)),
              ],
            ),
            const SizedBox(height: 13),
            Text(riwaqLocalizedValue(appointment.doctorName),
                style: TextStyle(
                    color: scheme.onPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
                '${riwaqLocalizedValue(appointment.specialty)} · ${riwaqLocalizedValue(appointment.date)}',
                style: TextStyle(color: scheme.onPrimary)),
            const SizedBox(height: 12),
            LayoutBuilder(
              builder: (context, constraints) {
                final timeLabel = Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.access_time_rounded,
                        color: scheme.onPrimary.withAlpha(190), size: 16),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(riwaqLocalizedValue(appointment.time),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                       style: TextStyle(color: scheme.onPrimary)),
                    ),
                  ],
                );
                final details = TextButton(
                  onPressed: onOpenDetails,
                  style: TextButton.styleFrom(foregroundColor: scheme.onPrimary),
                  child: Text(riwaqText('التفاصيل', 'Details')),
                );
                final map = IconButton(
                  tooltip: riwaqText('افتح موقع الموعد', 'Open appointment location'),
                  onPressed: onOpenMap,
                  icon: Icon(Icons.directions_outlined,
                      color: scheme.onPrimary),
                );
                if (constraints.maxWidth < 380) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      timeLabel,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [details, map],
                      ),
                    ],
                  );
                }
                return Row(
                  children: [
                    timeLabel,
                    const Spacer(),
                    details,
                    map,
                  ],
                );
              },
            ),
          ],
        ),
      );
  }
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
     this.tint,
    this.assetPath,
    this.compact = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color? tint;
  final String? assetPath;
  final bool compact;

  @override
  Widget build(BuildContext context) => Material(
        color: RiwaqColors.surface,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: RiwaqColors.border)),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final mark = Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      color: tint ?? RiwaqColors.mint,
                      borderRadius: BorderRadius.circular(12)),
                  child: assetPath == null
                      ? Icon(icon, size: 22, color: RiwaqColors.primaryDark)
                      : SvgPicture.asset(assetPath!,
                          width: 23,
                          height: 23,
                          placeholderBuilder: (_) => Icon(icon,
                              size: 22, color: RiwaqColors.primaryDark)),
                );
                final copy = Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: RiwaqColors.text,
                            fontWeight: FontWeight.w800,
                            fontSize: 13)),
                    const SizedBox(height: 3),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: RiwaqColors.muted, fontSize: 10)),
                  ],
                );
                if (compact || constraints.maxWidth < 175) {
                  return Row(
                    children: [
                      mark,
                      const SizedBox(width: 12),
                      Expanded(child: copy),
                    ],
                  );
                }
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [mark, copy],
                );
              },
            ),
          ),
        ),
      );
}

class _QuickAccessTile extends StatelessWidget {
  const _QuickAccessTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    required this.tint,
    this.assetPath,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color tint;
  final String? assetPath;

  @override
  Widget build(BuildContext context) => Material(
        color: RiwaqColors.surface,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          borderRadius: BorderRadius.circular(17),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                border: Border.all(color: RiwaqColors.border)),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 23,
                  backgroundColor: tint,
                  child: assetPath == null
                      ? Icon(icon, color: RiwaqColors.primaryDark)
                      : SvgPicture.asset(assetPath!,
                          width: 23,
                          height: 23,
                          placeholderBuilder: (_) =>
                              Icon(icon, color: RiwaqColors.primaryDark)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontWeight: FontWeight.w800,
                              color: RiwaqColors.text)),
                      const SizedBox(height: 4),
                      Text(subtitle,
                           style: TextStyle(
                              color: RiwaqColors.muted, fontSize: 11)),
                    ],
                  ),
                ),
                SvgPicture.asset('assets/images/c0fdd.svg',
                    width: 22,
                    height: 10,
                    placeholderBuilder: (_) => const Icon(
                        Icons.chevron_left_rounded,
                        color: RiwaqColors.primary)),
              ],
            ),
          ),
        ),
      );
}
