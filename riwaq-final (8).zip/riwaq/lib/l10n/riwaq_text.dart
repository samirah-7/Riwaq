import '../services/riwaq_local_store.dart';

String riwaqText(String arabic, String english) =>
    RiwaqLocalStore.instance.languageCode == 'en' ? english : arabic;

String riwaqPlaceName(String id, String arabic, {String? languageCode}) {
  if ((languageCode ?? RiwaqLocalStore.instance.languageCode) != 'en') {
    return arabic;
  }
  final knownName = _placeNamesEn[id];
  if (knownName != null) return knownName;
  if (arabic.startsWith('مخرج الطوارئ')) {
    return arabic.replaceFirst('مخرج الطوارئ', 'Emergency exit');
  }
  return riwaqLocalizedValue(arabic, languageCode: languageCode);
}

String riwaqLocalizedValue(String value, {String? languageCode}) {
  if ((languageCode ?? RiwaqLocalStore.instance.languageCode) != 'en') {
    return value;
  }
  return _commonValuesEn[value] ?? value;
}

String riwaqPlaceDescription(
  String id,
  String arabic, {
  String? languageCode,
}) {
  if ((languageCode ?? RiwaqLocalStore.instance.languageCode) != 'en') {
    return arabic;
  }
  return _placeDescriptionsEn[id] ??
      _commonValuesEn[arabic] ??
      'Conceptual location; not field-verified.';
}

String riwaqFloorName(String floorId, String arabic, {String? languageCode}) {
  if ((languageCode ?? RiwaqLocalStore.instance.languageCode) != 'en') {
    return arabic;
  }
  return switch (floorId) {
    'GROUND' => 'Ground floor',
    'FIRST' => 'First floor',
    'SECOND' => 'Second floor',
    _ => arabic,
  };
}

const _placeNamesEn = <String, String>{
  'G_RECEPTION': 'Main reception',
  'RECEPTION': 'Main reception',
  'G_EMERGENCY': 'Emergency department',
  'EMERGENCY': 'Emergency department',
  'G_PHARMACY': 'Pharmacy',
  'PHARMACY': 'Pharmacy',
  'G_RADIOLOGY': 'Radiology',
  'RADIOLOGY': 'Radiology',
  'G_LABORATORY': 'Laboratory',
  'LABORATORY': 'Laboratory',
  'G_ADMINISTRATION': 'Administration',
  'F_OPHTHALMOLOGY': 'Eye clinic',
  'EYE_CLINIC': 'Eye clinic',
  'F_DENTAL': 'Dental clinic',
  'DENTAL_CLINIC': 'Dental clinic',
  'F_INTERNAL_MEDICINE': 'Internal medicine clinics',
  'INTERNAL_MEDICINE': 'Internal medicine clinics',
  'F_DERMATOLOGY': 'Dermatology clinic',
  'DERMATOLOGY': 'Dermatology clinic',
  'F_CAFETERIA': 'Cafeteria',
  'S_INPATIENT': 'Inpatient ward',
  'S_OBSTETRICS': 'Obstetrics and gynecology',
  'S_SURGERY': 'Surgery',
  'S_NURSERY': 'Nursery',
  'G_MAIN_ENTRANCE': 'Main entrance',
  'MAIN_ENTRANCE': 'Main entrance',
  'G_EMERGENCY_ENTRANCE': 'Emergency entrance',
  'EMERGENCY_ENTRANCE': 'Emergency entrance',
  'G_AMBULANCE_ENTRANCE': 'Ambulance entrance',
  'AMBULANCE_ENTRANCE': 'Ambulance entrance',
  'G_OUTDOOR_PATH': 'Outdoor path',
  'G_GARDEN': 'Hospital garden',
  'COMMON_ELEVATOR_B': 'Elevators, group B',
  'COMMON_STAIRCASE_B': 'Stairs, group B',
  'GROUND_COMMON_ELEVATOR_B': 'Elevators, group B',
  'FIRST_COMMON_ELEVATOR_B': 'Elevators, group B',
  'SECOND_COMMON_ELEVATOR_B': 'Elevators, group B',
  'GROUND_COMMON_STAIRCASE_B': 'Stairs, group B',
  'FIRST_COMMON_STAIRCASE_B': 'Stairs, group B',
  'SECOND_COMMON_STAIRCASE_B': 'Stairs, group B',
};

const _placeDescriptionsEn = <String, String>{
  'MAIN_ENTRANCE':
      'Simulated starting point; the app does not detect the visitor here.',
  'G_MAIN_ENTRANCE':
      'Simulated starting point; the app does not detect the visitor here.',
  'G_EMERGENCY_ENTRANCE': 'Conceptual emergency entrance; not field-verified.',
  'EMERGENCY_ENTRANCE': 'Conceptual emergency entrance; not field-verified.',
  'G_AMBULANCE_ENTRANCE':
      'Conceptual ambulance entrance; not field-verified.',
  'AMBULANCE_ENTRANCE': 'Conceptual ambulance entrance; not field-verified.',
  'G_OUTDOOR_PATH': 'Illustrative outdoor path.',
  'OUTDOOR_PATH': 'Illustrative outdoor path.',
  'G_GARDEN': 'Illustrative garden connected to the entrance.',
  'GARDEN': 'Illustrative garden connected to the entrance.',
};

const _commonValuesEn = <String, String>{
  'تقاطع ممر': 'Corridor junction',
  'المصاعد - المجموعة ب': 'Elevators, group B',
  'السلالم ب': 'Stairs, group B',
  'مخرج الطوارئ': 'Emergency exit',
  'د. نورة العتيبي': 'Dr. Noura Al-Otaibi',
  'د. أحمد الحربي': 'Dr. Ahmed Al-Harbi',
  'د. سارة الغامدي': 'Dr. Sarah Al-Ghamdi',
  'طب العيون': 'Ophthalmology',
  'طب الأسنان': 'Dentistry',
  'طب الأسرة': 'Family medicine',
  'الأمراض الجلدية': 'Dermatology',
  'أمراض القلب': 'Cardiology',
  'جراحة العظام': 'Orthopedics',
  'متاحة اليوم · ١١:٣٠ ص': 'Available today · 11:30 AM',
  'أقرب موعد · غداً ٩:٠٠ ص': 'Next available · Tomorrow, 9:00 AM',
  'متاحة اليوم · ١:٠٠ م': 'Available today · 1:00 PM',
  'الأحد، ١٥ نوفمبر': 'Sunday, Nov 15',
  'الثلاثاء، ١٧ نوفمبر': 'Tuesday, Nov 17',
  'الأحد، ٨ نوفمبر': 'Sunday, Nov 8',
  'الأربعاء، ٤ نوفمبر': 'Wednesday, Nov 4',
  'الاثنين، ٢ نوفمبر': 'Monday, Nov 2',
  '١١:٣٠ صباحاً': '11:30 AM',
  '٩:٠٠ صباحاً': '9:00 AM',
  'اليوم': 'Today',
  'أمس': 'Yesterday',
  'قبل يومين': 'Two days ago',
  'عيادة العيون': 'Eye clinic',
  'عيادة الأسنان': 'Dental clinic',
  'الاستقبال': 'Reception',
  'د. نورة العتيبي · طب العيون':
      'Dr. Noura Al-Otaibi · Ophthalmology',
  'د. أحمد الحربي · طب الأسنان': 'Dr. Ahmed Al-Harbi · Dentistry',
  'استعلامات المستشفى': 'Hospital information desk',
  'تذكير بموعدك': 'Appointment reminder',
  'موعدك مع د. نورة العتيبي يوم الأحد، ١٥ نوفمبر الساعة ١١:٣٠ صباحاً.':
      'Your appointment with Dr. Noura Al-Otaibi is Sunday, Nov 15 at 11:30 AM.',
  'معلومة عن الزيارة': 'Visit information',
  'عيادة العيون في الدور الأول. يمكنك فتح الخريطة لمعرفة موقعها.':
      'The eye clinic is on the first floor. Open the map to see its location.',
  'مرحباً بك في رِواق': 'Welcome to Riwaq',
  'استخدم البحث أو المساعد المحلي للعثور على العيادات والخدمات.':
      'Use search or the local assistant to find clinics and services.',
  'مؤكد': 'Confirmed',
  'قادم': 'Upcoming',
  'زائر رِواق': 'Riwaq visitor',
};
