import 'package:flutter/material.dart';
import 'app.dart';
import 'services/hospital_floor_plan_editor.dart';
import 'services/riwaq_local_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await RiwaqLocalStore.instance.initialize();
  await HospitalFloorPlanEditor.restore();
  runApp(const RiwaqApp());
}
