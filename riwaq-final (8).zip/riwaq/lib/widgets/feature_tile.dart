import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class FeatureTile extends StatelessWidget {
  const FeatureTile(
      {super.key,
      required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap,
      this.tint});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color? tint;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: RiwaqColors.surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: RiwaqColors.border)),
          child: Row(children: [
            Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                    color: tint ?? RiwaqColors.mint,
                    borderRadius: BorderRadius.circular(14)),
                child: Icon(icon, color: RiwaqColors.primaryDark)),
            const SizedBox(width: 12),
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(title,
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: RiwaqColors.text)),
                  const SizedBox(height: 4),
                  Text(subtitle,
                      style: TextStyle(
                          fontSize: 12, color: RiwaqColors.muted)),
                ])),
            Icon(Icons.chevron_left_rounded, color: RiwaqColors.muted),
          ]),
        ),
      );
}
