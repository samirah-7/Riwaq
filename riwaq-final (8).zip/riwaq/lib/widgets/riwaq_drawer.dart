import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';
import 'riwaq_brand_logo.dart';

enum RiwaqDrawerDestination {
  doctors,
  recentVisits,
  savedLocations,
  profile,
  notifications,
  settings,
  help,
}

class RiwaqDrawer extends StatelessWidget {
  const RiwaqDrawer({
    super.key,
    required this.onSelect,
    required this.selected,
    required this.displayName,
  });

  final ValueChanged<RiwaqDrawerDestination> onSelect;
  final RiwaqDrawerDestination? selected;
  final String displayName;

  @override
  Widget build(BuildContext context) {
    final items = <(RiwaqDrawerDestination, IconData, String)>[
      (
        RiwaqDrawerDestination.doctors,
        Icons.medical_services_outlined,
        'الأطباء والتخصصات'
      ),
      (
        RiwaqDrawerDestination.recentVisits,
        Icons.history_rounded,
        'آخر الزيارات'
      ),
      (
        RiwaqDrawerDestination.savedLocations,
        Icons.bookmark_border_rounded,
        'العناوين المحفوظة'
      ),
      (
        RiwaqDrawerDestination.profile,
        Icons.person_outline_rounded,
        'الملف الشخصي'
      ),
      (
        RiwaqDrawerDestination.notifications,
        Icons.notifications_none_rounded,
        'الإشعارات'
      ),
      (RiwaqDrawerDestination.settings, Icons.settings_outlined, 'الإعدادات'),
      (
        RiwaqDrawerDestination.help,
        Icons.help_outline_rounded,
        'المساعدة والدعم'
      ),
    ];
    return Drawer(
      width: 318,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
              child: Row(
                children: [
                  const RiwaqBrandLogo(size: 62),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          riwaqText('رِواق', 'Riwaq'),
                          style: TextStyle(
                            color: RiwaqColors.text,
                            fontSize: 21,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(displayName,
                            style: TextStyle(color: RiwaqColors.muted)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(color: RiwaqColors.border),
            Expanded(
              child: ListView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                children: [
                  for (final item in items)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: ListTile(
                        selected: selected == item.$1,
                        selectedTileColor: RiwaqColors.mint,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                        leading: Icon(item.$2,
                            color: selected == item.$1
                                ? RiwaqColors.primaryDark
                                : RiwaqColors.muted),
                        title: Text(
                            switch (item.$1) {
                              RiwaqDrawerDestination.doctors => riwaqText(
                                  'الأطباء والتخصصات',
                                  'Doctors and specialties'),
                              RiwaqDrawerDestination.recentVisits =>
                                riwaqText('آخر الزيارات', 'Recent visits'),
                              RiwaqDrawerDestination.savedLocations =>
                                riwaqText(
                                    'العناوين المحفوظة', 'Saved locations'),
                              RiwaqDrawerDestination.profile =>
                                riwaqText('الملف الشخصي', 'Profile'),
                              RiwaqDrawerDestination.notifications =>
                                riwaqText('الإشعارات', 'Notifications'),
                              RiwaqDrawerDestination.settings =>
                                riwaqText('الإعدادات', 'Settings'),
                              RiwaqDrawerDestination.help => riwaqText(
                                  'المساعدة والدعم', 'Help and support'),
                            },
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)),
                        trailing: Icon(Icons.chevron_left_rounded,
                            color: RiwaqColors.muted),
                        onTap: () {
                          Navigator.of(context).pop();
                          onSelect(item.$1);
                        },
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                riwaqText('رِواق · دليل الزيارة', 'Riwaq · Visit guide'),
                style: TextStyle(color: RiwaqColors.muted, fontSize: 11),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
