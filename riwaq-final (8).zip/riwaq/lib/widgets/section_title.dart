import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.action});
  final String title;
  final String? action;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Text(title,
              style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  color: RiwaqColors.text)),
          const Spacer(),
          if (action != null)
            Text(action!,
                style: const TextStyle(
                    color: RiwaqColors.primary, fontWeight: FontWeight.w700)),
        ],
      );
}
