import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/hospital_floor_plan_data.dart';
import '../l10n/riwaq_text.dart';
import '../models/hospital_floor_plan.dart';
import '../theme/app_theme.dart';

/// An illustrative architectural plan. Coordinates come exclusively from the
/// shared floor-plan definition; they are not surveyed dimensions.
class HospitalPlan2D extends StatefulWidget {
  const HospitalPlan2D({
    super.key,
    required this.floor,
    this.route,
    this.startId,
    this.destinationId,
    required this.onSelect,
  });

  final HospitalFloorPlan floor;
  final HospitalRoute? route;
  final String? startId;
  final String? destinationId;
  final ValueChanged<FloorPlanPlace> onSelect;

  @override
  State<HospitalPlan2D> createState() => _HospitalPlan2DState();
}

class _HospitalPlan2DState extends State<HospitalPlan2D> {
  static const double _minScale = 1;
  static const double _maxScale = 4.5;
  static const double _zoomFactor = 1.25;
  static const double _keyboardPanStep = 40;
  static const double _panBoundaryMargin = 70;

  String? _zoomAnnouncement;
  final TransformationController _transformController =
      TransformationController();
  final FocusNode _mapFocusNode = FocusNode(debugLabel: 'floor plan map');
  final FocusNode _zoomInFocusNode = FocusNode(debugLabel: 'map zoom in');
  final FocusNode _zoomOutFocusNode = FocusNode(debugLabel: 'map zoom out');
  final FocusNode _zoomResetFocusNode = FocusNode(debugLabel: 'map zoom reset');

  @override
  void dispose() {
    _transformController.dispose();
    _mapFocusNode.dispose();
    _zoomInFocusNode.dispose();
    _zoomOutFocusNode.dispose();
    _zoomResetFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 600.0;
        final desiredHeight = (width * 1.02).clamp(400.0, 760.0).toDouble();
        final height = constraints.hasBoundedHeight
            ? math.min(desiredHeight, constraints.maxHeight).toDouble()
            : desiredHeight;

        if (height <= 0 || width <= 0) return const SizedBox.shrink();

        final selectable = widget.floor.selectablePlaces;
        final routePlaces = widget.route?.placesOnFloor(widget.floor.id) ??
            const <FloorPlanPlace>[];
        final start = _resolvePlace(
          widget.startId ?? widget.route?.startLocationId,
          routePlaces,
        );
        final destination = _resolvePlace(
          widget.destinationId ?? widget.route?.destinationLocationId,
          routePlaces,
        );
        final transitions = _floorTransitionPlaces();

        return ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: const Color(0xFFFBFDFC),
              border: Border.all(color: RiwaqColors.border),
              borderRadius: BorderRadius.circular(18),
            ),
            child: SizedBox(
              width: width,
              height: height,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Listener(
                      onPointerDown: (_) => _mapFocusNode.requestFocus(),
                      child: Focus(
                        focusNode: _mapFocusNode,
                        onKeyEvent: (node, event) =>
                            _handleMapKeyEvent(event, Size(width, height)),
                        child: InteractiveViewer(
                          transformationController: _transformController,
                          minScale: _minScale,
                          maxScale: _maxScale,
                          panEnabled: true,
                          scaleEnabled: true,
                          boundaryMargin:
                              const EdgeInsets.all(_panBoundaryMargin),
                          child: SizedBox(
                            width: width,
                            height: height,
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Positioned.fill(
                                  child: CustomPaint(
                                    painter: _PlanPainter(
                                      floor: widget.floor,
                                      routePlaces: routePlaces,
                                    ),
                                  ),
                                ),
                                ..._buildRouteMarkers(
                                  routePlaces: routePlaces,
                                  start: start,
                                  destination: destination,
                                  transitions: transitions,
                                  width: width,
                                  height: height,
                                ),
                                ...selectable.map(
                                  (place) => _buildPlaceTarget(
                                    place,
                                    width,
                                    height,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 12,
                    bottom: 12,
                    child: _buildZoomControls(Size(width, height)),
                  ),
                  if (_zoomAnnouncement != null)
                    Positioned(
                      left: 1,
                      top: 1,
                      child: Semantics(
                        key: const ValueKey('map-zoom-announcement'),
                        container: true,
                        liveRegion: true,
                        label: _zoomAnnouncement,
                        child: const SizedBox(width: 1, height: 1),
                      ),
                    ),
                  Positioned(
                    top: 12,
                    right: 12,
                    child: IgnorePointer(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF9FDFC).withAlpha(245),
                          border: Border.all(color: RiwaqColors.border),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.architecture_rounded,
                              size: 14,
                              color: RiwaqColors.primaryDark,
                            ),
                            SizedBox(width: 6),
                            Text(
                              'مخطط تصوّري',
                              style: TextStyle(
                                fontSize: 10,
                                color: RiwaqColors.text,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildZoomControls(Size viewportSize) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFFF9FDFC).withAlpha(245),
        border: Border.all(color: RiwaqColors.border),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            key: const ValueKey('map-zoom-in'),
            focusNode: _zoomInFocusNode,
            tooltip: riwaqText('تكبير الخريطة', 'Zoom map in'),
            onPressed: () => _zoomBy(_zoomFactor, viewportSize),
            icon: const Icon(Icons.add),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            key: const ValueKey('map-zoom-out'),
            focusNode: _zoomOutFocusNode,
            tooltip: riwaqText('تصغير الخريطة', 'Zoom map out'),
            onPressed: () => _zoomBy(1 / _zoomFactor, viewportSize),
            icon: const Icon(Icons.remove),
            visualDensity: VisualDensity.compact,
          ),
          IconButton(
            key: const ValueKey('map-zoom-reset'),
            focusNode: _zoomResetFocusNode,
            tooltip: riwaqText('إعادة ضبط تكبير الخريطة', 'Reset map zoom'),
            onPressed: _resetZoom,
            icon: const Icon(Icons.center_focus_strong),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }

  void _zoomBy(double factor, Size viewportSize) {
    final current = _transformController.value;
    final currentScale = current.getMaxScaleOnAxis();
    final targetScale =
        (currentScale * factor).clamp(_minScale, _maxScale).toDouble();
    if (targetScale == currentScale) return;

    final appliedFactor = targetScale / currentScale;
    final center = Offset(viewportSize.width / 2, viewportSize.height / 2);
    _transformController.value = Matrix4.identity()
      ..translate(center.dx, center.dy)
      ..scale(appliedFactor)
      ..translate(-center.dx, -center.dy)
      ..multiply(current);
    _announceZoomScale(targetScale);
  }

  void _resetZoom() {
    _transformController.value = Matrix4.identity();
    _announceZoomScale(_minScale);
  }

  void _announceZoomScale(double scale) {
    setState(() {
      _zoomAnnouncement = 'مقياس الخريطة: ${(scale * 100).round()}٪';
    });
  }

  KeyEventResult _handleMapKeyEvent(KeyEvent event, Size viewportSize) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }

    final translation = switch (event.logicalKey) {
      LogicalKeyboardKey.arrowLeft => const Offset(-_keyboardPanStep, 0),
      LogicalKeyboardKey.arrowRight => const Offset(_keyboardPanStep, 0),
      LogicalKeyboardKey.arrowUp => const Offset(0, -_keyboardPanStep),
      LogicalKeyboardKey.arrowDown => const Offset(0, _keyboardPanStep),
      _ => null,
    };
    if (translation == null) return KeyEventResult.ignored;

    final current = _transformController.value;
    final scale = current.getMaxScaleOnAxis();
    final currentTranslation = current.getTranslation();
    final minX =
        viewportSize.width - (viewportSize.width + _panBoundaryMargin) * scale;
    final maxX = _panBoundaryMargin * scale;
    final minY = viewportSize.height -
        (viewportSize.height + _panBoundaryMargin) * scale;
    final maxY = _panBoundaryMargin * scale;
    final x = (currentTranslation.x + translation.dx).clamp(minX, maxX);
    final y = (currentTranslation.y + translation.dy).clamp(minY, maxY);

    if (x != currentTranslation.x || y != currentTranslation.y) {
      _transformController.value = current.clone()
        ..setEntry(0, 3, x)
        ..setEntry(1, 3, y);
    }
    return KeyEventResult.handled;
  }

  FloorPlanPlace? _resolvePlace(
    String? id,
    List<FloorPlanPlace> routePlaces,
  ) {
    if (id == null) return null;
    for (final place in [...widget.floor.places, ...routePlaces]) {
      if (place.id == id || place.mapLocationId == id) return place;
    }
    return null;
  }

  List<FloorPlanPlace> _floorTransitionPlaces() {
    final route = widget.route;
    if (route == null) return const [];
    final result = <FloorPlanPlace>[];
    for (final transition in route.floorTransitions) {
      if (transition.from.floorId == widget.floor.id &&
          transition.from.verticalConnectionId != null) {
        result.add(transition.from);
      }
      if (transition.to.floorId == widget.floor.id &&
          transition.to.verticalConnectionId != null) {
        result.add(transition.to);
      }
    }
    return result;
  }

  List<Widget> _buildRouteMarkers({
    required List<FloorPlanPlace> routePlaces,
    required FloorPlanPlace? start,
    required FloorPlanPlace? destination,
    required List<FloorPlanPlace> transitions,
    required double width,
    required double height,
  }) {
    final markers = <Widget>[];
    if (start != null && start.floorId == widget.floor.id) {
      markers
          .add(_marker(start, 'بداية', const Color(0xFF1F668F), width, height));
    }
    if (destination != null && destination.floorId == widget.floor.id) {
      markers.add(
        _marker(
          destination,
          'الوجهة',
          const Color(0xFF9A4B00),
          width,
          height,
        ),
      );
    }
    for (final place in transitions) {
      if (place.id != start?.id && place.id != destination?.id) {
        markers.add(
          _marker(
            place,
            'تغيير الدور',
            const Color(0xFF9A4B00),
            width,
            height,
            compact: true,
          ),
        );
      }
    }
    return markers;
  }

  Widget _marker(
    FloorPlanPlace place,
    String label,
    Color color,
    double width,
    double height, {
    bool compact = false,
  }) {
    final role = switch (label) {
      'بداية' => 'start',
      'الوجهة' => 'destination',
      _ => 'floor-transition',
    };
    final roleLabel = switch (role) {
      'start' => 'نقطة البداية',
      'destination' => 'نقطة الوجهة',
      _ => 'تغيير الدور',
    };
    final markerIcon = switch (role) {
      'start' => Icons.flag_rounded,
      'destination' => Icons.place_rounded,
      _ => Icons.swap_vert_rounded,
    };
    final x = place.x * width;
    final y = place.y * height;
    return Positioned(
      left: x - (compact ? 9 : 11),
      top: y - (compact ? 9 : 11),
      child: IgnorePointer(
        child: Semantics(
          key: ValueKey('route-marker-$role'),
          container: true,
          image: true,
          label: '$roleLabel: ${place.nameAr}',
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: compact ? 18 : 22,
                height: compact ? 18 : 22,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x33224455),
                      blurRadius: 5,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Icon(
                  key: ValueKey('route-marker-icon-$role'),
                  markerIcon,
                  size: compact ? 11 : 12,
                  color: Colors.white,
                ),
              ),
              if (!compact) ...[
                const SizedBox(width: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFBFDFC),
                    border: Border.all(color: color, width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x33224455),
                        blurRadius: 4,
                        offset: Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Text(
                    label,
                    key: ValueKey('route-marker-text-$role'),
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFF193B34),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeLabel(FloorPlanPlace place, {required int maxLines}) {
    return DecoratedBox(
      key: ValueKey('plan-place-label-backplate-${place.id}'),
      decoration: BoxDecoration(
        color: const Color(0xFFFDFEFD),
        border: Border.all(color: const Color(0xFF81958E), width: 0.75),
        borderRadius: BorderRadius.circular(4),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1F193B34),
            blurRadius: 2,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
        child: Text(
          riwaqPlaceName(place.mapLocationId ?? place.id, place.nameAr),
          key: ValueKey('plan-place-label-${place.id}'),
          maxLines: maxLines,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 10,
            height: 1.18,
            color: Color(0xFF193B34),
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceTarget(
    FloorPlanPlace place,
    double width,
    double height,
  ) {
    final bounds = place.bounds;
    if (bounds == null) {
      final left = (place.x * width - 48).clamp(0.0, width - 96);
      final top = (place.y * height - 61).clamp(0.0, height - 54);
      return Positioned(
        left: left,
        top: top,
        width: 96,
        height: 54,
        child: _placeButton(place, compact: false),
      );
    }
    return Positioned(
      left: bounds.left * width,
      top: bounds.top * height,
      width: bounds.width * width,
      height: bounds.height * height,
      child: _placeButton(place),
    );
  }

  Widget _placeButton(FloorPlanPlace place, {bool compact = true}) {
    return Semantics(
      key: ValueKey('plan-place-${place.id}'),
      button: true,
      label:
          '${riwaqPlaceName(place.mapLocationId ?? place.id, place.nameAr)}. ${place.descriptionAr}',
      child: Tooltip(
        message:
            '${riwaqPlaceName(place.mapLocationId ?? place.id, place.nameAr)} — ${place.descriptionAr}',
        waitDuration: const Duration(milliseconds: 500),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => widget.onSelect(place),
            splashColor: RiwaqColors.primary.withAlpha(26),
            highlightColor: RiwaqColors.primary.withAlpha(15),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
                child: LayoutBuilder(builder: (context, constraints) {
                  if (constraints.maxHeight < 40) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _iconFor(place.category),
                          size: 14,
                          color: _iconColor(place),
                        ),
                        const SizedBox(width: 4),
                        Flexible(child: _placeLabel(place, maxLines: 1)),
                      ],
                    );
                  }
                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _iconFor(place.category),
                        size: compact ? 15 : 18,
                        color: _iconColor(place),
                      ),
                      const SizedBox(height: 3),
                      Flexible(child: _placeLabel(place, maxLines: 2)),
                    ],
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }

  IconData _iconFor(FloorPlaceCategory category) {
    switch (category) {
      case FloorPlaceCategory.department:
        return Icons.medical_services_outlined;
      case FloorPlaceCategory.service:
        return Icons.miscellaneous_services_outlined;
      case FloorPlaceCategory.room:
        return Icons.meeting_room_outlined;
      case FloorPlaceCategory.corridor:
        return Icons.route_outlined;
      case FloorPlaceCategory.entrance:
        return Icons.login_rounded;
      case FloorPlaceCategory.restroom:
        return Icons.wc_rounded;
      case FloorPlaceCategory.prayerRoom:
        return Icons.self_improvement_rounded;
      case FloorPlaceCategory.stairs:
        return Icons.stairs_rounded;
      case FloorPlaceCategory.emergencyExit:
        return Icons.exit_to_app_rounded;
      case FloorPlaceCategory.elevator:
        return Icons.elevator_rounded;
      case FloorPlaceCategory.waitingArea:
        return Icons.chair_alt_outlined;
      case FloorPlaceCategory.garden:
        return Icons.park_outlined;
    }
  }

  Color _iconColor(FloorPlanPlace place) {
    if (place.category == FloorPlaceCategory.entrance) {
      return RiwaqColors.primaryDark;
    }
    if (place.category == FloorPlaceCategory.emergencyExit) {
      return const Color(0xFFB4654B);
    }
    return switch (place.zone) {
      PlanZone.public => const Color(0xFF548C7D),
      PlanZone.clinical => const Color(0xFF378C89),
      PlanZone.staff => const Color(0xFF778A82),
      PlanZone.service => const Color(0xFFB18452),
      PlanZone.outdoor => const Color(0xFF608A68),
    };
  }
}

class _PlanPainter extends CustomPainter {
  const _PlanPainter({
    required this.floor,
    required this.routePlaces,
  });

  final HospitalFloorPlan floor;
  final List<FloorPlanPlace> routePlaces;

  static const _wall = Color(0xFF52746A);
  static const _corridor = Color(0xFFEAF4F0);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()..color = const Color(0xFFFBFDFC),
    );

    _drawBuilding(canvas, size);
    _drawCorridors(canvas, size);
    _drawOutdoor(canvas, size);
    _drawRooms(canvas, size);
    _drawArchitecturalDetails(canvas, size);
    _drawRoute(canvas, size);
  }

  void _drawOutdoor(Canvas canvas, Size size) {
    final garden = floor.places.where(
      (place) => place.category == FloorPlaceCategory.garden,
    );
    for (final place in garden) {
      final bounds = place.bounds;
      if (bounds == null) continue;
      final r = _rect(bounds, size);
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(7)),
        Paint()..color = const Color(0xFFE9F2E6),
      );
      final border = Paint()
        ..color = const Color(0xFF8BA58C)
        ..strokeWidth = 1.3
        ..style = PaintingStyle.stroke;
      canvas.drawRRect(
        RRect.fromRectAndRadius(r, const Radius.circular(7)),
        border,
      );
      final seed = place.nameAr.codeUnits.fold<int>(0, (a, b) => a + b);
      for (var index = 0; index < 5; index++) {
        final px = r.left + r.width * (.12 + ((seed + index * 17) % 70) / 100);
        final py = r.top + r.height * (.28 + (index % 2) * .38);
        _drawTree(canvas, Offset(px, py), math.min(5.0, r.height * .12));
      }
    }

    final entrance = floor.places.cast<FloorPlanPlace?>().firstWhere(
          (place) => place?.category == FloorPlaceCategory.entrance,
          orElse: () => null,
        );
    final pathNode = floor.places.cast<FloorPlanPlace?>().firstWhere(
          (place) => place?.id.endsWith('OUTDOOR_PATH') ?? false,
          orElse: () => null,
        );
    final gardenPlace = garden.isEmpty ? null : garden.first;
    if (entrance != null && pathNode != null && gardenPlace != null) {
      final path = Path()
        ..moveTo(entrance.x * size.width, entrance.y * size.height)
        ..lineTo(pathNode.x * size.width, pathNode.y * size.height)
        ..lineTo(gardenPlace.x * size.width, gardenPlace.y * size.height);
      canvas.drawPath(
        path,
        Paint()
          ..color = const Color(0xFFD7E2D4)
          ..strokeWidth = math.max(7.0, size.width * .018)
          ..strokeCap = StrokeCap.round
          ..style = PaintingStyle.stroke,
      );
      canvas.drawPath(
        path,
        Paint()
          ..color = const Color(0xFF99AE98)
          ..strokeWidth = 1
          ..strokeCap = StrokeCap.round
          ..style = PaintingStyle.stroke,
      );
    }
  }

  void _drawTree(Canvas canvas, Offset center, double radius) {
    canvas.drawCircle(
      center,
      radius * 1.55,
      Paint()..color = const Color(0xFFCBDCC8),
    );
    canvas.drawCircle(
      center,
      radius,
      Paint()..color = const Color(0xFF77987B),
    );
    canvas.drawCircle(
      center,
      math.max(1, radius * .27),
      Paint()..color = const Color(0xFFE7F0E2),
    );
  }

  void _drawCorridors(Canvas canvas, Size size) {
    final fill = Paint()..color = _corridor;
    final edge = Paint()
      ..color = const Color(0xFFD8E7E1)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (final corridor in floor.corridors) {
      final r = _rect(corridor, size);
      canvas.drawRect(r, fill);
      canvas.drawRect(r, edge);
    }

    // Fine transverse floor joints establish a quiet architectural scale.
    final jointPaint = Paint()
      ..color = const Color(0xFFDDEBE5)
      ..strokeWidth = .65;
    final vertical = floor.corridors.where(
      (corridor) => corridor.height > corridor.width,
    );
    for (final corridor in vertical) {
      final r = _rect(corridor, size);
      for (var i = 1; i < 10; i++) {
        final y = r.top + r.height * i / 10;
        canvas.drawLine(
            Offset(r.left + 1, y), Offset(r.right - 1, y), jointPaint);
      }
    }
  }

  void _drawBuilding(Canvas canvas, Size size) {
    final r = _rect(hospitalBuildingBounds, size);
    final fill = Paint()..color = const Color(0xFFF5FAF8);
    canvas.drawRect(r, fill);

    final wall = Paint()
      ..color = _wall
      ..strokeWidth = math.max(3.2, size.width * .009)
      ..strokeCap = StrokeCap.square;
    final entrance = floor.places.cast<FloorPlanPlace?>().firstWhere(
          (place) => place?.category == FloorPlaceCategory.entrance,
          orElse: () => null,
        );
    final openingWidth = size.width * .052;
    final openingCenter = entrance?.x ?? -1;
    final gapLeft = openingCenter * size.width - openingWidth / 2;
    final gapRight = openingCenter * size.width + openingWidth / 2;

    canvas.drawLine(Offset(r.left, r.top), Offset(r.right, r.top), wall);
    canvas.drawLine(Offset(r.left, r.top), Offset(r.left, r.bottom), wall);
    canvas.drawLine(Offset(r.right, r.top), Offset(r.right, r.bottom), wall);
    if (entrance == null) {
      canvas.drawLine(
          Offset(r.left, r.bottom), Offset(r.right, r.bottom), wall);
    } else {
      canvas.drawLine(
          Offset(r.left, r.bottom), Offset(gapLeft, r.bottom), wall);
      canvas.drawLine(
          Offset(gapRight, r.bottom), Offset(r.right, r.bottom), wall);
      final doorWidth = openingWidth / 2;
      final leaf = Paint()
        ..color = _wall
        ..strokeWidth = math.max(1.8, size.width * .004);
      canvas.drawLine(
        Offset(gapLeft, r.bottom),
        Offset(gapLeft, r.bottom - doorWidth),
        leaf,
      );
      canvas.drawLine(
        Offset(gapRight, r.bottom),
        Offset(gapRight, r.bottom - doorWidth),
        leaf,
      );
      final arcPaint = Paint()
        ..color = const Color(0xFF8CA59D)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke;
      canvas.drawArc(
        Rect.fromCircle(
          center: Offset(gapLeft, r.bottom),
          radius: doorWidth,
        ),
        -math.pi / 2,
        math.pi / 2,
        false,
        arcPaint,
      );
      canvas.drawArc(
        Rect.fromCircle(
          center: Offset(gapRight, r.bottom),
          radius: doorWidth,
        ),
        math.pi,
        math.pi / 2,
        false,
        arcPaint,
      );
      canvas.drawLine(
        Offset(gapLeft, r.bottom + 1),
        Offset(gapRight, r.bottom + 1),
        Paint()
          ..color = const Color(0xFF8CA59D)
          ..strokeWidth = 1,
      );
    }
  }

  void _drawRooms(Canvas canvas, Size size) {
    final rooms = floor.places.where(
      (place) =>
          place.bounds != null &&
          place.category != FloorPlaceCategory.corridor &&
          place.category != FloorPlaceCategory.garden,
    );
    for (final place in rooms) {
      final r = _rect(place.bounds!, size);
      canvas.drawRect(r, Paint()..color = _zoneColor(place));
      _drawRoomWalls(canvas, r, place, size);
      if (place.id == 'G_RECEPTION' || place.nameAr.contains('استقبال')) {
        _drawReceptionDesk(canvas, r);
      } else if (place.category == FloorPlaceCategory.waitingArea) {
        _drawWaitingSeats(canvas, r);
      } else if (place.zone == PlanZone.staff) {
        _drawStaffFixtures(canvas, r);
      }
    }
  }

  Color _zoneColor(FloorPlanPlace place) {
    if (place.category == FloorPlaceCategory.emergencyExit) {
      return const Color(0xFFF8EEEA);
    }
    return switch (place.zone) {
      PlanZone.public => const Color(0xFFFBF5E9),
      PlanZone.clinical => const Color(0xFFE8F4F2),
      PlanZone.staff => const Color(0xFFF0F3EF),
      PlanZone.service => const Color(0xFFF4F1E8),
      PlanZone.outdoor => const Color(0xFFE9F2E6),
    };
  }

  void _drawRoomWalls(
    Canvas canvas,
    Rect r,
    FloorPlanPlace place,
    Size size,
  ) {
    final wall = Paint()
      ..color = _wall
      ..strokeWidth = math.max(2.6, size.width * .007)
      ..strokeCap = StrokeCap.square;
    final opening = math.min(r.width * .34, size.width * .052);
    final center = place.x * size.width;
    final left = (center - opening / 2).clamp(r.left, r.right);
    final right = (center + opening / 2).clamp(r.left, r.right);
    canvas.drawLine(Offset(r.left, r.top), Offset(r.right, r.top), wall);
    canvas.drawLine(Offset(r.left, r.top), Offset(r.left, r.bottom), wall);
    canvas.drawLine(Offset(r.right, r.top), Offset(r.right, r.bottom), wall);
    canvas.drawLine(Offset(r.left, r.bottom), Offset(left, r.bottom), wall);
    canvas.drawLine(Offset(right, r.bottom), Offset(r.right, r.bottom), wall);

    final doorWidth = right - left;
    if (doorWidth < 1) return;
    final swing = Paint()
      ..color = const Color(0xFF8CA59D)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    final leaf = Paint()
      ..color = _wall
      ..strokeWidth = math.max(1.4, size.width * .0035);
    canvas.drawLine(
      Offset(left, r.bottom),
      Offset(left, r.bottom - doorWidth),
      leaf,
    );
    canvas.drawArc(
      Rect.fromCircle(
        center: Offset(left, r.bottom),
        radius: doorWidth,
      ),
      -math.pi / 2,
      math.pi / 2,
      false,
      swing,
    );
  }

  void _drawReceptionDesk(Canvas canvas, Rect r) {
    final desk = Rect.fromLTWH(
      r.left + r.width * .12,
      r.top + r.height * .20,
      r.width * .43,
      r.height * .11,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(desk, const Radius.circular(3)),
      Paint()..color = const Color(0xFFB8D7CE),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(desk, const Radius.circular(3)),
      Paint()
        ..color = const Color(0xFF7EAAA0)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );
    canvas.drawLine(
      Offset(desk.left + desk.width * .12, desk.bottom - 2),
      Offset(desk.right - desk.width * .12, desk.bottom - 2),
      Paint()
        ..color = const Color(0xFF71998F)
        ..strokeWidth = 1,
    );
  }

  void _drawWaitingSeats(Canvas canvas, Rect r) {
    final seatPaint = Paint()..color = const Color(0xFFD5E6DF);
    final outline = Paint()
      ..color = const Color(0xFF92B2A7)
      ..strokeWidth = .8
      ..style = PaintingStyle.stroke;
    final seatWidth = math.min(r.width * .17, 12.0);
    final seatHeight = math.min(r.height * .14, 7.0);
    for (var row = 0; row < 2; row++) {
      for (var index = 0; index < 3; index++) {
        final x = r.left + r.width * (.61 + index * .11);
        final y = r.top + r.height * (.28 + row * .30);
        final seat = Rect.fromLTWH(x, y, seatWidth, seatHeight);
        canvas.drawRRect(
          RRect.fromRectAndRadius(seat, const Radius.circular(2)),
          seatPaint,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(seat, const Radius.circular(2)),
          outline,
        );
      }
    }
  }

  void _drawStaffFixtures(Canvas canvas, Rect r) {
    final fixture = Paint()
      ..color = const Color(0xFFDCE4DE)
      ..style = PaintingStyle.fill;
    final table = Rect.fromLTWH(
      r.left + r.width * .13,
      r.top + r.height * .20,
      r.width * .24,
      r.height * .12,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(table, const Radius.circular(2)),
      fixture,
    );
  }

  void _drawArchitecturalDetails(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = const Color(0xFFBDD0C9)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (final place in floor.places) {
      if (place.category == FloorPlaceCategory.garden) continue;
      if (place.category == FloorPlaceCategory.entrance) {
        final x = place.x * size.width;
        final y = place.y * size.height;
        canvas.drawLine(
          Offset(x - size.width * .024, y + 2),
          Offset(x + size.width * .024, y + 2),
          outline,
        );
      }
    }
  }

  void _drawRoute(Canvas canvas, Size size) {
    if (routePlaces.length < 2) return;
    final path = Path()
      ..moveTo(
          routePlaces.first.x * size.width, routePlaces.first.y * size.height);
    for (final place in routePlaces.skip(1)) {
      path.lineTo(place.x * size.width, place.y * size.height);
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.white.withAlpha(240)
        ..strokeWidth = math.max(8.0, size.width * .022)
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF287BB4)
        ..strokeWidth = math.max(4.5, size.width * .012)
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke,
    );
    for (final place in routePlaces) {
      canvas.drawCircle(
        Offset(place.x * size.width, place.y * size.height),
        math.max(3, size.width * .009),
        Paint()..color = const Color(0xFF287BB4),
      );
    }
  }

  Rect _rect(PlanRect rect, Size size) => Rect.fromLTWH(
        rect.left * size.width,
        rect.top * size.height,
        rect.width * size.width,
        rect.height * size.height,
      );

  @override
  bool shouldRepaint(covariant _PlanPainter oldDelegate) =>
      oldDelegate.floor != floor || oldDelegate.routePlaces != routePlaces;
}
