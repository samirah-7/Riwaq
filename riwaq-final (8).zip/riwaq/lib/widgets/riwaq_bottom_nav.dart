import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';

class RiwaqBottomNav extends StatelessWidget {
  const RiwaqBottomNav(
      {super.key, required this.currentIndex, required this.onTap});
  final int currentIndex;
  final ValueChanged<int> onTap;

  static const items = [
    (Icons.home_rounded, 'الرئيسية'),
    (Icons.map_outlined, 'الخريطة'),
    (Icons.calendar_month_outlined, 'مواعيدي'),
    (Icons.chat_bubble_outline_rounded, 'رِواق'),
  ];

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: RiwaqColors.surface,
          border: Border(top: BorderSide(color: RiwaqColors.border)),
        ),
        child: SafeArea(
          top: false,
          child: NavigationBar(
            height: 70,
            selectedIndex: currentIndex,
            onDestinationSelected: onTap,
            backgroundColor: RiwaqColors.surface,
            indicatorColor: RiwaqColors.mint,
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            destinations: items
                .map((item) => NavigationDestination(
                      icon: Icon(item.$1, size: 22),
                      label: switch (item.$2) {
                        'الرئيسية' => riwaqText('الرئيسية', 'Home'),
                        'الخريطة' => riwaqText('الخريطة', 'Map'),
                        'مواعيدي' => riwaqText('مواعيدي', 'Appointments'),
                        _ => riwaqText('رِواق', 'Riwaq'),
                      },
                    ))
                .toList(),
          ),
        ),
      );
}
