import 'dart:math' as math;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/hospital_floor_plan_data.dart';
import '../l10n/riwaq_text.dart';
import '../models/architectural_model.dart';
import '../models/hospital_floor_plan.dart';
import '../theme/app_theme.dart';

enum BuildingView { building, exploded, floor }

class HospitalModel3D extends StatefulWidget {
  const HospitalModel3D(
      {super.key,
      required this.floor,
      required this.onSelect,
      required this.onFloorSelect,
      this.route,
      this.destinationId,
      this.startId});
  final HospitalFloorPlan floor;
  final HospitalRoute? route;
  final String? destinationId, startId;
  final ValueChanged<FloorPlanPlace> onSelect;
  final ValueChanged<String> onFloorSelect;
  @override
  State<HospitalModel3D> createState() => _HospitalModel3DState();
}

class _HospitalModel3DState extends State<HospitalModel3D> {
  late final Future<ArchitecturalModel> _model = rootBundle
      .load('assets/hospital/riwaq_hospital.glb')
      .then(ArchitecturalModel.fromGlb);
  BuildingView _view = BuildingView.exploded;
  double _yaw = -.4, _pitch = .82, _zoom = 1, _scaleAtStart = 1;
  void _reset() => setState(() {
        _yaw = -.4;
        _pitch = .82;
        _zoom = 1;
      });
  void _zoomBy(double amount) =>
      setState(() => _zoom = (_zoom + amount).clamp(.55, 2.8));

  @override
  Widget build(BuildContext context) => Column(children: [
        Wrap(spacing: 6, runSpacing: 4, children: [
          for (final mode in BuildingView.values)
            ChoiceChip(
              label: Text(switch (mode) {
                BuildingView.building =>
                  riwaqText('المبنى كاملاً', 'Whole building'),
                BuildingView.exploded =>
                  riwaqText('الأدوار مفصولة', 'Floors separated'),
                BuildingView.floor =>
                  riwaqText('الدور المحدد', 'Selected floor'),
              }),
              selected: _view == mode,
              onSelected: (_) => setState(() {
                _view = mode;
                _zoom = 1;
              }),
            ),
        ]),
        const SizedBox(height: 8),
        Container(
          key: const ValueKey('hospital-3d-view'),
          decoration: BoxDecoration(
              color: RiwaqColors.modelCanvas,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: RiwaqColors.border)),
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            height: 500,
            child: FutureBuilder<ArchitecturalModel>(
              future: _model,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                      child: Text(riwaqText(
                    'تعذر تحميل النموذج الثلاثي الأبعاد: ${snapshot.error}',
                    'Could not load the 3D model: ${snapshot.error}',
                  )));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                return LayoutBuilder(builder: (context, constraints) {
                  final size =
                      Size(constraints.maxWidth, constraints.maxHeight);
                  final scene = HospitalSceneProjection(
                      snapshot.data!,
                      size,
                      _yaw,
                      _pitch,
                      _zoom,
                      _view,
                      widget.floor,
                      widget.destinationId);
                  return Stack(children: [
                    Positioned.fill(
                        child: Semantics(
                      label: riwaqText(
                        'نموذج مستشفى ثلاثي الأبعاد تفاعلي. اسحب للتدوير وقرّب بإصبعين.',
                        'Interactive 3D hospital model. Drag to rotate and pinch to zoom.',
                      ),
                      child: Listener(
                        onPointerSignal: (event) {
                          if (event is PointerScrollEvent) {
                            _zoomBy(-event.scrollDelta.dy * .002);
                          }
                        },
                        child: GestureDetector(
                          key: const ValueKey('hospital-3d-canvas'),
                          behavior: HitTestBehavior.opaque,
                          onScaleStart: (_) => _scaleAtStart = _zoom,
                          onScaleUpdate: (d) => setState(() {
                            _zoom = (_scaleAtStart * d.scale).clamp(.55, 2.8);
                            if (d.pointerCount == 1) {
                              _yaw += d.focalPointDelta.dx * .008;
                              _pitch = (_pitch + d.focalPointDelta.dy * .005)
                                  .clamp(.28, 1.35);
                            }
                          }),
                          onTapUp: (d) {
                            for (final face in scene._faces.reversed) {
                              if (!face.path.contains(d.localPosition)) {
                                continue;
                              }
                              final place =
                                  findHospitalPlace(face.part.placeId);
                              if (place != null) {
                                widget.onSelect(place);
                              } else {
                                widget.onFloorSelect(face.part.floorId);
                              }
                              break;
                            }
                          },
                          child: CustomPaint(
                              painter: _ModelPainter(scene, widget.route,
                                  widget.startId, widget.destinationId)),
                        ),
                      ),
                    )),
                    Positioned(
                        top: 10,
                        right: 10,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                              color: RiwaqColors.surface.withValues(alpha: .92),
                              borderRadius: BorderRadius.circular(8)),
                          child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Text(
                                  _view == BuildingView.floor
                                      ? riwaqFloorName(
                                          widget.floor.id, widget.floor.nameAr)
                                      : riwaqText('نموذج معماري • ٣ أدوار',
                                          'Architectural model • 3 floors'),
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: RiwaqColors.text))),
                        )),
                    Positioned(
                        left: 8,
                        bottom: 8,
                        child: Column(children: [
                          _control(riwaqText('تكبير النموذج', 'Zoom in'),
                              Icons.add, () => _zoomBy(.2)),
                          _control(riwaqText('تصغير النموذج', 'Zoom out'),
                              Icons.remove, () => _zoomBy(-.2)),
                          _control(
                              riwaqText('إعادة ضبط الكاميرا', 'Reset view'),
                              Icons.restart_alt,
                              _reset),
                        ])),
                    Positioned(
                        right: 10,
                        bottom: 10,
                        child: Text(
                            riwaqText(
                              'تدوير ${(_yaw * 180 / math.pi).round()}° • تقريب ${(_zoom * 100).round()}٪',
                              'Rotation ${(_yaw * 180 / math.pi).round()}° • zoom ${(_zoom * 100).round()}%',
                            ),
                            key: const ValueKey('model-camera-status'),
                            style: TextStyle(
                                fontSize: 10, color: RiwaqColors.muted))),
                  ]);
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
            riwaqText(
              'اسحب للتدوير • قرّب بإصبعين أو بعجلة الفأرة • اضغط على غرفة لاختيارها',
              'Drag to rotate • pinch or scroll to zoom • select a room by tapping it',
            ),
            style: TextStyle(fontSize: 10, color: RiwaqColors.muted)),
      ]);

  Widget _control(String label, IconData icon, VoidCallback onTap) => Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Material(
          color: RiwaqColors.surface,
          borderRadius: BorderRadius.circular(10),
          child: IconButton(
              tooltip: label, onPressed: onTap, icon: Icon(icon, size: 20))));
}

class _Face {
  _Face(this.path, this.depth, this.color, this.part);
  final Path path;
  final double depth;
  final Color color;
  final ArchitecturalPart part;
}

/// Shared projection math is public for precise picking and viewport-fit tests.
class HospitalSceneProjection {
  HospitalSceneProjection(this.model, this.size, this.yaw, this.pitch,
      this.zoom, this.view, this.floor, this.selectedId) {
    _fitScene();
    _faces = _makeFaces();
  }
  final ArchitecturalModel model;
  final Size size;
  final double yaw, pitch, zoom;
  final BuildingView view;
  final HospitalFloorPlan floor;
  final String? selectedId;
  late final List<_Face> _faces;
  late final double _fitScale;
  late final Offset _sceneCentre;

  ({Offset point, double depth}) _cameraPoint(ModelVertex v) {
    final x = v.x * math.cos(yaw) - v.z * math.sin(yaw);
    final z = v.x * math.sin(yaw) + v.z * math.cos(yaw);
    final centerY = view == BuildingView.exploded
        ? 3.32
        : view == BuildingView.floor
            ? floor.level * .72
            : .72;
    final y = v.y - centerY;
    final depth = z * math.cos(pitch) + y * math.sin(pitch);
    final perspective = 20 / (20 - depth);
    return (
      point: Offset(x * perspective,
          (z * math.sin(pitch) - y * math.cos(pitch)) * perspective),
      depth: depth
    );
  }

  void _fitScene() {
    final points = [
      for (final part in model.parts)
        if (view != BuildingView.floor || part.floorId == floor.id)
          for (final vertex in part.vertices)
            _cameraPoint(adjust(vertex, part.level)).point,
    ];
    final minX = points.map((p) => p.dx).reduce(math.min);
    final maxX = points.map((p) => p.dx).reduce(math.max);
    final minY = points.map((p) => p.dy).reduce(math.min);
    final maxY = points.map((p) => p.dy).reduce(math.max);
    _sceneCentre = Offset((minX + maxX) / 2, (minY + maxY) / 2);
    _fitScale = math.min(
        math.max(1, size.width - 48) / math.max(.01, maxX - minX),
        math.max(1, size.height - 64) / math.max(.01, maxY - minY));
  }

  ({Offset point, double depth}) project(ModelVertex v) {
    final raw = _cameraPoint(v);
    return (
      point: Offset(size.width / 2, size.height / 2) +
          (raw.point - _sceneCentre) * (_fitScale * zoom),
      depth: raw.depth
    );
  }

  ModelVertex adjust(ModelVertex v, int level) => ModelVertex(
      v.x, v.y + (view == BuildingView.exploded ? level * 2.6 : 0), v.z);
  ModelVertex pointFor(FloorPlanPlace p) {
    final level = hospitalFloorPlans.firstWhere((f) => f.id == p.floorId).level;
    return adjust(
        ModelVertex((p.x - .5) * 10, level * .72 + .13, (p.y - .5) * 10),
        level);
  }

  List<_Face> _makeFaces() {
    final batches = <({
      ArchitecturalPart part,
      List<_Face> faces,
      double depth,
      int layer
    })>[];
    for (final part in model.parts) {
      if (view == BuildingView.floor && part.floorId != floor.id) continue;
      final vertices = part.vertices.map((v) => adjust(v, part.level)).toList();
      final projected = vertices.map(project).toList();
      final partFaces = <_Face>[];
      for (var i = 0; i < part.indices.length; i += 3) {
        final ids = part.indices.sublist(i, i + 3);
        final a = vertices[ids[0]], b = vertices[ids[1]], c = vertices[ids[2]];
        final ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z;
        final vx = c.x - a.x, vy = c.y - a.y, vz = c.z - a.z;
        final nx = uy * vz - uz * vy,
            ny = uz * vx - ux * vz,
            nz = ux * vy - uy * vx;
        final norm = math.sqrt(nx * nx + ny * ny + nz * nz);
        final light = norm == 0
            ? .9
            : .72 + .24 * ny.abs() / norm + .04 * nz.abs() / norm;
        final selected = part.placeId != null && part.placeId == selectedId;
        final colors = selected && part.kind == 'room'
            ? <double>[.12, .67, .54, 1]
            : part.kind == 'slab' && part.floorId == floor.id
                ? <double>[.84, .94, .90, 1]
                : part.color;
        final color = Color.fromRGBO(
            (colors[0] * light * 255).round().clamp(0, 255),
            (colors[1] * light * 255).round().clamp(0, 255),
            (colors[2] * light * 255).round().clamp(0, 255),
            1);
        final path = Path()
          ..moveTo(projected[ids[0]].point.dx, projected[ids[0]].point.dy);
        for (final id in ids.skip(1)) {
          path.lineTo(projected[id].point.dx, projected[id].point.dy);
        }
        path.close();
        partFaces.add(_Face(
            path,
            ids.map((id) => projected[id].depth).reduce((a, b) => a + b) / 3,
            color,
            part));
      }
      partFaces.sort((a, b) => a.depth.compareTo(b.depth));
      batches.add((
        part: part,
        faces: partFaces,
        depth: projected.map((p) => p.depth).reduce((a, b) => a + b) /
            projected.length,
        layer: part.kind == 'slab'
            ? 0
            : part.kind == 'room'
                ? 1
                : 2,
      ));
    }
    // Architectural cutaway compositing: a slab's large triangles must never
    // cover its own room-floor meshes. Keep convex parts together and composite
    // floor surfaces before walls/furniture. Hit-testing uses this SAME order.
    batches.sort((a, b) {
      final level = a.part.level.compareTo(b.part.level);
      if (level != 0) return level;
      final layer = a.layer.compareTo(b.layer);
      return layer != 0 ? layer : a.depth.compareTo(b.depth);
    });
    return [for (final batch in batches) ...batch.faces];
  }
}

class _ModelPainter extends CustomPainter {
  _ModelPainter(this.scene, this.route, this.startId, this.destinationId);
  final HospitalSceneProjection scene;
  final HospitalRoute? route;
  final String? startId, destinationId;
  @override
  void paint(Canvas canvas, Size size) {
    final shadow = Paint()
      ..color = const Color(0x1320785F)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
    canvas.drawOval(
        Rect.fromCenter(
            center: Offset(size.width / 2, size.height * .82),
            width: size.width * .7,
            height: 35),
        shadow);
    for (final face in scene._faces) {
      canvas.drawPath(face.path, Paint()..color = face.color);
    }
    final places = route?.places ?? <FloorPlanPlace>[];
    for (var i = 1; i < places.length; i++) {
      final from = places[i - 1], to = places[i];
      if (scene.view == BuildingView.floor &&
          (from.floorId != scene.floor.id || to.floorId != scene.floor.id)) {
        continue;
      }
      final a = scene.project(scene.pointFor(from)).point;
      final b = scene.project(scene.pointFor(to)).point;
      final transition = from.floorId != to.floorId;
      canvas.drawLine(
          a,
          b,
          Paint()
            ..color = Colors.white
            ..strokeWidth = 7
            ..strokeCap = StrokeCap.round);
      final pen = Paint()
        ..color = transition ? RiwaqColors.orange : const Color(0xFF2173BD)
        ..strokeWidth = 3.5
        ..strokeCap = StrokeCap.round;
      if (transition) {
        for (var j = 0; j < 10; j += 2) {
          canvas.drawLine(Offset.lerp(a, b, j / 10)!,
              Offset.lerp(a, b, (j + 1) / 10)!, pen);
        }
      } else {
        canvas.drawLine(a, b, pen);
      }
    }
    for (final marker in [
      (id: startId, color: const Color(0xFF2173BD)),
      (id: destinationId, color: RiwaqColors.orange)
    ]) {
      final p = findHospitalPlace(marker.id);
      if (p == null ||
          (scene.view == BuildingView.floor && p.floorId != scene.floor.id)) {
        continue;
      }
      final pt = scene.project(scene.pointFor(p)).point;
      canvas.drawCircle(pt, 8, Paint()..color = Colors.white);
      canvas.drawCircle(pt, 5.5, Paint()..color = marker.color);
    }
    // Each level is identified in the 3D view without inventing extra rooms.
    if (scene.view == BuildingView.exploded) {
      for (final f in hospitalFloorPlans) {
        final pt = scene
            .project(scene.adjust(
                ModelVertex(-4.8, f.level * .72 + .1, -4.5), f.level))
            .point;
        final text = TextPainter(
            text: TextSpan(
                text: riwaqFloorName(f.id, f.nameAr),
                style: TextStyle(
                    fontFamily: '29LT Bukra',
                    fontSize: 10,
                    color: RiwaqColors.primaryDark,
                    fontWeight: FontWeight.bold)),
            textDirection: TextDirection.rtl)
          ..layout();
        text.paint(canvas, pt);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ModelPainter oldDelegate) => true;
}
