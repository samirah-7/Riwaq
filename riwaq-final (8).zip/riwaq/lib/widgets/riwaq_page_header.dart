import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';
import '../theme/app_theme.dart';
import 'riwaq_brand_logo.dart';

class RiwaqPageHeader extends StatelessWidget {
  const RiwaqPageHeader({
    super.key,
    required this.title,
    required this.onOpenMenu,
    required this.onOpenNotifications,
    this.onBack,
    this.subtitle,
    this.unreadCount = 0,
    this.showLogo = false,
  });

  final String title;
  final String? subtitle;
  final VoidCallback onOpenMenu;
  final VoidCallback onOpenNotifications;
  final VoidCallback? onBack;
  final int unreadCount;
  final bool showLogo;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          children: [
            IconButton(
              tooltip: riwaqText('فتح القائمة', 'Open menu'),
              onPressed: onOpenMenu,
              icon: const Icon(Icons.menu_rounded),
            ),
            if (onBack != null)
              IconButton(
                tooltip: riwaqText('رجوع', 'Back'),
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
              ),
            if (showLogo) ...[
              const RiwaqBrandLogo(size: 48),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: RiwaqColors.text,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: RiwaqColors.muted, fontSize: 11),
                    ),
                  ],
                ],
              ),
            ),
            IconButton(
              tooltip: riwaqText('الإشعارات', 'Notifications'),
              onPressed: onOpenNotifications,
              icon: Badge(
                isLabelVisible: unreadCount > 0,
                label: Text(unreadCount > 9 ? '9+' : '$unreadCount'),
                child: const Icon(Icons.notifications_none_rounded),
              ),
            ),
          ],
        ),
      );
}
