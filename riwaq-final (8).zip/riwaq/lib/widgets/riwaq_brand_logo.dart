import 'package:flutter/material.dart';

import '../l10n/riwaq_text.dart';

import '../theme/app_theme.dart';

/// Displays the supplied brand artwork; it is not recreated from text.
class RiwaqBrandLogo extends StatelessWidget {
  const RiwaqBrandLogo({super.key, this.size = 72});

  final double size;

  @override
  Widget build(BuildContext context) => Image.asset(
        'assets/images/riwaq_brand_board.png',
        width: size,
        height: size,
        fit: BoxFit.contain,
        semanticLabel:
            riwaqText('شعار رِواق · طريقك للرعاية', 'Riwaq logo · Your path to care'),
        errorBuilder: (context, error, stackTrace) => Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: RiwaqColors.mint,
            borderRadius: BorderRadius.circular(18),
          ),
          child: const Icon(Icons.local_hospital_rounded,
              color: RiwaqColors.primary),
        ),
      );
}
