import 'dart:async';

import 'package:geolocator/geolocator.dart';

enum ApproximateGpsStatus {
  available,
  serviceDisabled,
  permissionDenied,
  permissionPermanentlyDenied,
  timedOut,
  unavailable,
}

class ApproximateGpsResult {
  const ApproximateGpsResult(this.status, {this.accuracyMeters});

  final ApproximateGpsStatus status;
  final double? accuracyMeters;
}

abstract interface class ApproximateGpsService {
  Future<ApproximateGpsResult> request();
}

class GeolocatorApproximateGpsService implements ApproximateGpsService {
  const GeolocatorApproximateGpsService();

  @override
  Future<ApproximateGpsResult> request() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        return const ApproximateGpsResult(ApproximateGpsStatus.serviceDisabled);
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever) {
        return const ApproximateGpsResult(
            ApproximateGpsStatus.permissionPermanentlyDenied);
      }
      if (permission == LocationPermission.denied) {
        return const ApproximateGpsResult(
            ApproximateGpsStatus.permissionDenied);
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.low,
          timeLimit: Duration(seconds: 12),
        ),
      );
      return ApproximateGpsResult(
        ApproximateGpsStatus.available,
        accuracyMeters: position.accuracy,
      );
    } on TimeoutException {
      return const ApproximateGpsResult(ApproximateGpsStatus.timedOut);
    } on LocationServiceDisabledException {
      return const ApproximateGpsResult(ApproximateGpsStatus.serviceDisabled);
    } catch (_) {
      return const ApproximateGpsResult(ApproximateGpsStatus.unavailable);
    }
  }
}
