import '../../models/assistant_response.dart';
import 'arabic_text.dart';

/// Conservative local safety checks, kept independent of language providers.
class HealthSafetyRules {
  AssistantResponse? emergencyResponse(String input) {
    final text = normalizeArabic(input);
    if (!_isPotentialEmergency(text)) return null;
    return const AssistantResponse(
      intent: AssistantIntent.emergency,
      message:
          'قد تكون هذه حالة طارئة. اطلب المساعدة الطبية فوراً أو اتصل بالإسعاف على 997 في السعودية. لا أستطيع التشخيص أو وصف العلاج.',
      confidence: .99,
      actions: ['call_emergency'],
    );
  }

  bool isHealthRelated(String input) {
    final text = normalizeArabic(input);
    return _hasAny(text, const [
      'symptom',
      'health',
      'medical',
      'medicine',
      'medication',
      'treatment',
      'diagnosis',
      'breathing',
      'respiration',
      'headache',
      'fever',
      'temperature',
      'rash',
      'cough',
      'nausea',
      'pain',
      'sick',
      'مرض',
      'صحه',
      'طبي',
      'دواء',
      'علاج',
      'تشخيص',
      'اعراض',
      'صداع',
      'حمى',
      'حراره',
      'طفح',
      'سعال',
      'غثيان',
      'الم',
      'وجع',
      'مريض',
      'تنفس',
      'التنفس',
    ]);
  }

  bool _isPotentialEmergency(String text) {
    if (_hasAny(text, const [
      'severe bleeding',
      'heavy bleeding',
      'unconscious',
      'lost consciousness',
      'not breathing',
      'cannot breathe',
      'can t breathe',
      'trouble breathing',
      'difficulty breathing',
      'choking',
      'severe chest pain',
      'crushing chest pain',
      'stroke symptoms',
      'face drooping',
      'sudden weakness',
      'slurred speech',
      'seizure',
      'overdose',
      'poisoning',
      'severe allergic reaction',
      'i want to kill myself',
      'i might hurt myself',
      'حاله طارئه',
      'حاله طوارئ',
      'باختنق',
      'نزيف شديد',
      'فقد الوعي',
      'فاقد الوعي',
      'اغمي عليه',
      'مغمى عليه',
      'لا يستجيب',
      'لا يتنفس',
      'ما يتنفس',
      'لا يستطيع التنفس',
      'لا استطيع التنفس',
      'ما اقدر اتنفس',
      'ما يقدر يتنفس',
      'توقف التنفس',
      'اختناق',
      'اختنق',
      'يضيق نفسي',
      'ضيق التنفس',
      'صعوبه التنفس',
      'الم شديد في الصدر',
      'الم قوي في الصدر',
      'جلطه دماغيه',
      'سكتة دماغية',
      'اعوجاج الوجه',
      'ضعف مفاجئ',
      'تلعثم',
      'تشنج',
      'تسمم',
      'جرعه زائده',
      'حساسيه شديده',
      'اريد ايذاء نفسي',
      'أبي أؤذي نفسي',
    ])) {
      return true;
    }

    final chestPain = _hasAny(text, const [
      'chest pain',
      'pain in my chest',
      'chest hurts',
      'الم في الصدر',
      'الم صدري',
      'صدري يعور',
      'صدري يوجع',
    ]);
    final acuteChestSigns = _hasAny(text, const [
      'severe',
      'crushing',
      'sudden',
      'shortness of breath',
      'difficulty breathing',
      'dizzy',
      'sweating',
      'غثيان',
      'دوخه',
      'تعرق',
      'شديد',
      'حاد',
      'ضيق',
      'تنفس',
    ]);
    if (chestPain && acuteChestSigns) return true;

    final breathingDifficulty = _hasAny(text, const [
          'breathing',
          'breathe',
          'التنفس',
          'اتنفس',
          'نفس',
        ]) &&
        _hasAny(text, const [
          'hard to',
          'difficulty',
          'trouble',
          'shortness',
          'cannot',
          'can t',
          'ضيق',
          'صعوبه',
          'صعب',
          'ما اقدر',
          'لا استطيع',
          'اختناق',
          'اختنق',
          'مخنوق',
          'اكتم',
          'يلهث',
        ]);
    if (breathingDifficulty) return true;

    final generalQuestion = _hasAny(text, const [
      'what is',
      'what causes',
      'why does',
      'can chest pain',
      'ما هو',
      'ما اسباب',
      'ما سبب',
      'هل ألم',
      'هل الم',
      'لماذا',
    ]);
    final mildChestPain = _hasAny(text, const ['mild', 'slight', 'خفيف']);
    final chestPainWithoutRedFlags = _hasAny(text, const [
      'chest pain',
      'pain in my chest',
      'الم في الصدر',
      'الم صدري',
    ]);
    return chestPainWithoutRedFlags && !generalQuestion && !mildChestPain;
  }

  bool _hasAny(String text, List<String> terms) =>
      terms.any((term) => text.contains(normalizeArabic(term)));
}
