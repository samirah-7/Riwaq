import '../../data/specialty_data.dart';
import '../../models/doctor.dart';
import '../../models/assistant_response.dart';
import '../../models/hospital_location.dart';
import 'arabic_text.dart';
import 'health_safety_rules.dart';
import 'hospital_information_service.dart';

class IntentClassifier {
  IntentClassifier({
    HospitalInformationService? hospitalInformation,
    HealthSafetyRules? safetyRules,
  })  : _hospital = hospitalInformation ?? HospitalInformationService(),
        _safetyRules = safetyRules ?? HealthSafetyRules();

  final HospitalInformationService _hospital;
  final HealthSafetyRules _safetyRules;

  AssistantResponse classify(
    String input, {
    String? contextLocationId,
    String? currentLocationId,
    int responseVariant = 0,
  }) {
    final text = normalizeArabic(input);
    if (text.isEmpty) {
      return _clarification(
        AssistantClarificationField.topic,
        'اكتب سؤالك وسأساعدك في الوصول إلى الخدمة المناسبة.',
      );
    }

    final emergency = _safetyRules.emergencyResponse(text);
    if (emergency != null) return emergency;

    if (_hasAny(text, const ['موعد', 'مواعيد', 'حجز', 'appointment'])) {
      return AssistantResponse(
        intent: AssistantIntent.appointmentInquiry,
        message: responseVariant.isEven
            ? 'أقدر أساعدك بمراجعة مواعيدك التجريبية من صفحة «مواعيدي».'
            : 'للاطلاع على المواعيد المسجلة في النموذج، افتح صفحة «مواعيدي».',
        confidence: .92,
        actions: const ['view_appointments'],
      );
    }

    final routeRequest = _isRouteRequest(text);
    final locationQuery = _isLocationQuery(text);
    final navigationRequest = routeRequest || locationQuery;
    final originQuery = _extractOriginQuery(text);
    final originCandidates = originQuery == null
        ? null
        : _hospital.locationsMatching(originQuery);
    if (navigationRequest &&
        originQuery != null &&
        (originCandidates == null || originCandidates.length != 1)) {
      return _clarification(
        AssistantClarificationField.origin,
        'لم أتعرف على نقطة البداية. اختر موقعاً مسجلاً مثل الاستقبال أو المدخل.',
      );
    }
    final origin = originCandidates?.firstOrNull ??
        (routeRequest ? _hospital.locationById(currentLocationId) : null);

    final isFollowUp = _isLocationFollowUp(text);
    final doctor = _hospital.findDoctor(text);
    final specialty = _hospital.findSpecialty(text);
    final destinationQuery = _extractDestinationQuery(text);
    List<HospitalLocation> destinationCandidates;
    if (isFollowUp) {
      final previous = _hospital.locationById(contextLocationId);
      if (previous == null) {
        return _clarification(
          AssistantClarificationField.destination,
          'ما المكان الذي تقصده؟ اذكر اسمه لأحدد لك الوجهة.',
        );
      }
      destinationCandidates = [previous];
    } else {
      destinationCandidates = destinationQuery == null
          ? _hospital.locationsMatching(text)
          : _hospital.locationsMatching(destinationQuery);
      if (destinationCandidates.isEmpty &&
          destinationQuery != null &&
          originQuery == null) {
        destinationCandidates = _hospital.locationsMatching(text);
      }
    }

    if (destinationCandidates.length > 1 && doctor == null) {
      return _clarification(
        AssistantClarificationField.destination,
        'وجدت أكثر من وجهة محتملة. اذكر اسم العيادة أو المرفق المقصود.',
      );
    }
    if (!isFollowUp && destinationQuery == null) {
      final mentionedLocations = _hospital.locationsMentioned(text);
      if (mentionedLocations.length > 1 && doctor == null) {
        return _clarification(
          AssistantClarificationField.destination,
          'ذكرت أكثر من موقع. وضّح أي عيادة أو مرفق تقصد.',
        );
      }
    }

    final destination = doctor == null
        ? destinationCandidates.firstOrNull ??
            (specialty == null
                ? null
                : _hospital.locationById(specialty.locationId))
        : _hospital.locationById(doctor.locationId);

    if (routeRequest && destination == null) {
      return _clarification(
        AssistantClarificationField.destination,
        'ما المكان الذي تريد الوصول إليه؟ اذكر اسم عيادة أو مرفق مسجل.',
      );
    }

    if (routeRequest && origin == null) {
      return _clarification(
        AssistantClarificationField.origin,
        'من أين تريد أن تبدأ؟ اختر نقطة بداية مسجلة مثل الاستقبال أو المدخل.',
      );
    }

    if (doctor != null) {
      return _doctorResponse(
        doctor,
        origin,
        routeRequest,
        originWasSpecified: originQuery != null,
        openMap: navigationRequest,
      );
    }

    if (destination != null && navigationRequest) {
      final department = specialty != null &&
          specialty.locationId == destination.id;
      return _navigationResponse(
        destination,
        origin,
        routeRequest,
        responseVariant,
        originWasSpecified: originQuery != null,
        specialty: department ? specialty : null,
      );
    }

    if (specialty != null) {
      final availableDoctors =
          _hospital.doctorsBySpecialty(specialty.id);
      return AssistantResponse(
        intent: AssistantIntent.specialtySearch,
        message: responseVariant.isEven
            ? 'قد يكون ${specialty.nameAr} نقطة بداية مناسبة. ${availableDoctors.isEmpty ? 'لا توجد أسماء أطباء مسجلة لهذا التخصص في بيانات العرض حالياً.' : 'وجدت ${availableDoctors.length} من الأطباء في بيانات العرض.'} هذه مساعدة للتوجيه فقط وليست تشخيصاً طبياً.'
            : 'التخصص المسجل هو ${specialty.nameAr}. ${availableDoctors.isEmpty ? 'لا توجد أسماء أطباء مسجلة له في بيانات العرض حالياً.' : 'يوجد ${availableDoctors.length} من الأطباء في بيانات العرض.'} يمكنك فتح قائمة الأطباء أو الموقع.',
        confidence: .88,
        specialtyId: specialty.id,
        departmentId: specialty.departmentId,
        destinationId: specialty.locationId,
        doctorIds: availableDoctors.map((item) => item.id).toList(growable: false),
        actions: const ['view_doctors', 'open_map'],
      );
    }

    if (destination != null) {
      return _navigationResponse(
        destination,
        origin,
        false,
        responseVariant,
        originWasSpecified: originQuery != null,
      );
    }

    if (_safetyRules.isHealthRelated(text)) {
      return const AssistantResponse(
        intent: AssistantIntent.healthInformation,
        message:
            'أستطيع تقديم معلومات عامة فقط، ولا أستطيع تشخيص حالتك أو وصف علاج. إذا كانت الأعراض شديدة أو تزداد سوءاً، تواصل مع جهة طبية؛ وللطوارئ اتصل 997.',
        confidence: .7,
      );
    }

    if (_isDoctorRequest(text)) {
      return AssistantResponse(
        intent: AssistantIntent.doctorSearch,
        message: responseVariant.isEven
            ? 'ما التخصص أو اسم الطبيب الذي تبحث عنه؟ سأعرض فقط الأطباء المسجلين في بيانات العرض.'
            : 'اذكر التخصص أو اسم الطبيب، وسأبحث في قائمة الأطباء المتاحة.',
        confidence: .72,
        clarificationNeeded: AssistantClarificationField.topic,
        actions: const ['view_doctors'],
      );
    }

    if (_hasAny(text, const ['مساعده', 'مساعدة', 'ساعدني', 'كيف', 'help'])) {
      return AssistantResponse(
        intent: AssistantIntent.general,
        message: responseVariant.isEven
            ? 'أساعدك في العثور على التخصصات والخدمات والمواعيد التجريبية. ما الخدمة التي تحتاجها؟'
            : 'يمكنني إرشادك إلى عيادة أو مرفق، أو عرض بيانات الأطباء والمواعيد التجريبية.',
        confidence: .7,
        actions: const ['view_doctors', 'view_appointments'],
      );
    }

    if (navigationRequest) {
      return _clarification(
        AssistantClarificationField.destination,
        'ما المكان الذي تريد الوصول إليه؟ اذكر اسم عيادة أو مرفق مسجل.',
      );
    }

    return _clarification(
      AssistantClarificationField.topic,
      'هل تبحث عن مكان أو طبيب أو موعد؟ اذكر ما تقصده لأساعدك.',
    );
  }

  AssistantResponse _navigationResponse(
    HospitalLocation destination,
    HospitalLocation? origin,
    bool routeRequest,
    int variant, {
    bool originWasSpecified = false,
    Specialty? specialty,
  }) {
    final floor = destination.floor == 0
        ? 'الدور الأرضي'
        : 'الدور ${destination.floor == 1 ? 'الأول' : destination.floor}';
    final originName = origin?.nameAr;
    final message = originName != null
        ? 'سأحدد مساراً تجريبياً من $originName إلى ${destination.nameAr} على الخريطة. هذا المسار غير موثق.'
        : routeRequest
            ? 'تجد ${destination.nameAr} في $floor. افتح الخريطة لعرض المسار التجريبي.'
            : variant.isEven
                ? '${destination.nameAr} مسجلة في بيانات الخريطة في $floor. يمكنك فتح الخريطة لتحديدها.'
                : 'تجد ${destination.nameAr} في $floor ضمن بيانات العرض. أستطيع تحديدها على الخريطة.';
    final specialtyId = specialty?.id;
    final departmentId = specialty?.departmentId;
    return AssistantResponse(
      intent: specialtyId == null
          ? AssistantIntent.facilitySearch
          : AssistantIntent.departmentNavigation,
      message: message,
      confidence: .9,
      originId: origin?.id,
      originWasSpecified: originWasSpecified,
      destinationId: destination.id,
      specialtyId: specialtyId,
      departmentId: departmentId,
      actions: const ['open_map'],
    );
  }

  AssistantResponse _doctorResponse(
    Doctor doctor,
    HospitalLocation? origin,
    bool routeRequest, {
    bool originWasSpecified = false,
    bool openMap = false,
  }) {
    final location = _hospital.locationById(doctor.locationId);
    final message = location == null
        ? 'الطبيب مسجل في بيانات العرض، لكن موقعه غير متاح.'
        : routeRequest && origin != null
            ? 'الطبيب مسجل ضمن ${doctor.specialty}. يمكن فتح مسار تجريبي من ${origin.nameAr} إلى ${location.nameAr}.'
            : 'الطبيب مسجل ضمن ${doctor.specialty} في ${location.nameAr}. يمكنك عرض التفاصيل أو فتح الموقع.';
    return AssistantResponse(
      intent: AssistantIntent.doctorSearch,
      message: message,
      confidence: .9,
      originId: origin?.id,
      originWasSpecified: originWasSpecified,
      destinationId: location?.id,
      specialtyId: doctor.specialtyId,
      departmentId: doctor.departmentId,
      doctorIds: [doctor.id],
      actions: [
        'view_details',
        if (openMap && location != null) 'open_map',
      ],
    );
  }

  AssistantResponse _clarification(
    AssistantClarificationField field,
    String message,
  ) =>
      AssistantResponse(
        intent: AssistantIntent.unclear,
        message: message,
        confidence: .4,
        clarificationNeeded: field,
      );

  String? _extractOriginQuery(String text) {
    const markers = [
      'currently at ',
      'starting at ',
      'my current location is ',
      'my location is ',
      'i am at ',
      'i m at ',
      'i am in ',
      'i m in ',
      'from ',
      'انا موجوده في ',
      'انا موجود في ',
      'انا عند ',
      'انا في ',
      'موقعي في ',
      'بدايه من ',
      'من ',
    ];
    var markerStart = -1;
    var markerEnd = -1;
    for (final marker in markers) {
      final index = text.indexOf(marker);
      if (index >= 0 &&
          (markerStart < 0 ||
              index < markerStart ||
              (index == markerStart && marker.length > markerEnd - markerStart))) {
        markerStart = index;
        markerEnd = index + marker.length;
      }
    }
    if (markerStart < 0) return null;

    var segment = text.substring(markerEnd);
    const stops = [
      ' and i want to ',
      ' and i need to ',
      ' and i would like to ',
      ' and want to ',
      ' where ',
      ' how ',
      ' to ',
      ' واريد ',
      ' وابي ',
      ' وابغي ',
      ' ابغى اروح ',
      ' ابي اروح ',
      ' الى ',
      ' الي ',
    ];
    final stopAt = _firstIndexOfAny(segment, stops);
    if (stopAt >= 0) segment = segment.substring(0, stopAt);
    return segment.trim();
  }

  String? _extractDestinationQuery(String text) {
    const markers = [
      'how do i get to ',
      'how can i get to ',
      'how do i reach ',
      'how can i reach ',
      'go to ',
      'get to ',
      'take me to ',
      'navigate to ',
      'directions to ',
      ' to ',
      'towards ',
      'الى ',
      'الي ',
      'اروح ل',
      'اروح ',
      'اذهب ل',
      'اذهب ',
      'اوصل ل',
      'اوصل ',
    ];
    var markerEnd = -1;
    for (final marker in markers) {
      final index = text.lastIndexOf(marker);
      final end = index < 0 ? -1 : index + marker.length;
      if (end > markerEnd) markerEnd = end;
    }
    if (markerEnd < 0 || markerEnd >= text.length) return null;
    var segment = text.substring(markerEnd).trim();
    const originStops = [
      ' from ',
      ' starting at ',
      ' من ',
      ' انا عند ',
      ' انا في ',
    ];
    final originStop = _firstIndexOfAny(segment, originStops);
    if (originStop >= 0) segment = segment.substring(0, originStop);
    return segment.trim();
  }

  int _firstIndexOfAny(String text, List<String> terms) {
    var first = -1;
    for (final term in terms) {
      final index = text.indexOf(term);
      if (index >= 0 && (first < 0 || index < first)) first = index;
    }
    return first;
  }

  bool _isRouteRequest(String text) => _hasAny(text, const [
        'how do i get to',
        'how can i get to',
        'how do i reach',
        'how can i reach',
        'get me to',
        'go to',
        'i want to go',
        'i need to go',
        'take me to',
        'directions to',
        'navigate to',
        'route to',
        'from ',
        ' to ',
        'الى ',
        'الي ',
        'كيف اوصل',
        'كيف اروح',
        'كيف اصل',
        'ابغى اروح',
        'ابي اروح',
        'احتاج اروح',
        'اريد الذهاب',
        'دلني على الطريق',
        'اتجاهات الى',
        'الطريق الى',
      ]);

  bool _isLocationQuery(String text) => _hasAny(text, const [
        'where',
        'location of',
        'where can i find',
        'where is',
        'located',
        'وين',
        'اين',
        'فين',
        'موقع',
        'هل يوجد',
        'هل فيه',
        'مكان',
        'ابحث عن',
        'ادور على',
      ]);

  bool _isLocationFollowUp(String text) {
    final hasPronoun = _hasAny(text, const [
      'there',
      'it',
      'that place',
      'that clinic',
      'that department',
      'there from',
      'وينها',
      'وينه',
      'لها',
      'له',
      'اليها',
      'اليه',
      'هناك',
      'المكان هذا',
    ]);
    return hasPronoun &&
        (_isRouteRequest(text) ||
            _hasAny(text, const ['what floor', 'which floor', 'اي دور']));
  }

  bool _isDoctorRequest(String text) => _hasAny(text, const [
        'doctor',
        'dr ',
        'physician',
        'طبيب',
        'دكتور',
        'دكتوره',
      ]);

  bool _hasAny(String text, List<String> terms) =>
      terms.any((term) => text.contains(normalizeArabic(term)));
}
