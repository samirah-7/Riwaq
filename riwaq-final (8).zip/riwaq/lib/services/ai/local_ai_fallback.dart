import '../../models/assistant_response.dart';
import '../../data/specialty_data.dart';
import '../../l10n/riwaq_text.dart';
import '../../services/riwaq_local_store.dart';
import 'ai_provider.dart';
import 'hospital_information_service.dart';
import 'intent_classifier.dart';

class LocalAiFallback implements AiProvider {
  LocalAiFallback({
    IntentClassifier? classifier,
    HospitalInformationService? hospitalInformation,
  })  : _classifier = classifier ?? IntentClassifier(),
        _hospital = hospitalInformation ?? HospitalInformationService();

  final IntentClassifier _classifier;
  final HospitalInformationService _hospital;
  String? _lastLocationId;
  int _contextTurnsRemaining = 0;
  int _responseVariant = 0;

  @override
  Future<AssistantResponse> respond(AssistantRequest request) async {
    final contextLocationId = _contextTurnsRemaining > 0
        ? _lastLocationId ?? _contextFromHistory(request.history)
        : _contextFromHistory(request.history);
    final response = _classifier.classify(
      request.message,
      contextLocationId: contextLocationId,
      currentLocationId: request.currentLocationId,
      responseVariant: _responseVariant++,
    );
    if (response.destinationId != null) {
      _lastLocationId = response.destinationId;
      _contextTurnsRemaining = 3;
    } else if (_contextTurnsRemaining > 0 &&
        response.intent != AssistantIntent.emergency) {
      _contextTurnsRemaining--;
      if (_contextTurnsRemaining == 0) _lastLocationId = null;
    }
    return _localize(response);
  }

  String? _contextFromHistory(List<AiChatTurn> history) {
    for (final turn in history.reversed) {
      if (turn.role != 'user') continue;
      final earlier = _classifier.classify(turn.content);
      if (earlier.destinationId != null &&
          earlier.intent != AssistantIntent.emergency) {
        return earlier.destinationId;
      }
    }
    return null;
  }

  AssistantResponse _localize(AssistantResponse response) {
    if (RiwaqLocalStore.instance.languageCode != 'en') return response;

    final destination = _hospital.locationById(response.destinationId);
    final origin = _hospital.locationById(response.originId);
    final locationName = destination == null
        ? 'the selected location'
        : riwaqPlaceName(destination.id, destination.nameAr, languageCode: 'en');
    final originName = origin == null
        ? null
        : riwaqPlaceName(origin.id, origin.nameAr, languageCode: 'en');
    final floor = destination == null
        ? ''
        : destination.floor == 0
            ? ' on the ground floor'
            : ' on floor ${destination.floor}';
    final specialty = _hospital.specialtyById(response.specialtyId);
    final specialtyName = specialty == null
        ? 'that specialty'
        : _englishSpecialtyName(specialty);
    final doctors = [
      for (final id in response.doctorIds)
        if (_hospital.doctorById(id) case final doctor?)
          riwaqLocalizedValue(doctor.name, languageCode: 'en'),
    ];
    final message = switch (response.intent) {
      AssistantIntent.emergency =>
        'This may be an emergency. Call Saudi ambulance services at 997 now. I cannot diagnose or prescribe treatment.',
      AssistantIntent.healthInformation =>
        'I can provide general information only, not a diagnosis or treatment. Contact a healthcare professional if symptoms are concerning; call 997 for an emergency.',
      AssistantIntent.appointmentInquiry =>
        'Appointments shown in this prototype are sample data. Open Appointments to review them.',
      AssistantIntent.facilitySearch ||
      AssistantIntent.departmentNavigation =>
        originName == null
            ? '$locationName is listed in the simulated map$floor. Open the map to view it.'
            : 'I can show a simulated route from $originName to $locationName. The route is unverified.',
      AssistantIntent.specialtySearch =>
        '$specialtyName is listed in the sample data. ${doctors.length} doctors are listed for it. This is navigation help, not medical advice.',
      AssistantIntent.doctorSearch => doctors.isNotEmpty
          ? '${doctors.join(', ')} ${doctors.length == 1 ? 'is' : 'are'} listed in the sample data. Open the details or map to view available information.'
          : 'Which specialty or doctor name should I look for? I can only show doctors in the sample data.',
      AssistantIntent.general =>
        'I can help you find a clinic or service, browse sample doctors, or open sample appointments. What do you need?',
      AssistantIntent.unclear => switch (response.clarificationNeeded) {
          AssistantClarificationField.origin =>
            'Where are you starting from? Choose a listed point such as reception or the entrance.',
          AssistantClarificationField.destination =>
            'Which clinic or facility do you mean? Tell me its name so I can identify the destination.',
          AssistantClarificationField.topic || null =>
            'Are you looking for a place, a doctor, or an appointment? Tell me what you mean.',
        },
    };
    return AssistantResponse(
      intent: response.intent,
      message: message,
      confidence: response.confidence,
      originId: response.originId,
      originWasSpecified: response.originWasSpecified,
      specialtyId: response.specialtyId,
      destinationId: response.destinationId,
      departmentId: response.departmentId,
      clarificationNeeded: response.clarificationNeeded,
      doctorIds: response.doctorIds,
      actions: response.actions,
    );
  }

  String _englishSpecialtyName(Specialty specialty) => switch (specialty.id) {
        'OPHTHALMOLOGY' => 'ophthalmology',
        'DENTISTRY' => 'dentistry',
        'DERMATOLOGY' => 'dermatology',
        'CARDIOLOGY' => 'cardiology',
        'ORTHOPEDICS' => 'orthopedics',
        'FAMILY_MEDICINE' => 'family medicine',
        _ => riwaqLocalizedValue(specialty.nameAr, languageCode: 'en'),
      };
}
