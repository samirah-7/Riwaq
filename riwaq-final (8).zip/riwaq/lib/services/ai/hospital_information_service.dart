import '../../data/repositories/doctor_repository.dart';
import '../../data/repositories/location_repository.dart';
import '../../data/specialty_data.dart' as data;
import '../../models/doctor.dart';
import '../../models/hospital_location.dart';
import '../../services/ai/arabic_text.dart';

/// Read-only access to the hospital data used by local assistant providers.
class HospitalInformationService {
  HospitalInformationService({
    DoctorRepository doctorRepository = const DoctorRepository(),
    LocationRepository locationRepository = const LocationRepository(),
  })  : _doctors = doctorRepository,
        _locations = locationRepository;

  final DoctorRepository _doctors;
  final LocationRepository _locations;

  List<Doctor> get doctors => _doctors.getAll();
  List<HospitalLocation> get locations => _locations.getAll();
  List<data.Specialty> get specialties => data.specialties;

  HospitalLocation? locationById(String? id) => _locations.byId(id);

  List<HospitalLocation> locationsMatching(String text) =>
      _locations.findMatchesByText(text);

  List<HospitalLocation> locationsMentioned(String text) =>
      _locations.findMentionedByText(text);

  Doctor? doctorById(String id) => _doctors.byId(id);

  Doctor? findDoctor(String text) => _doctors.findByText(text);

  List<Doctor> doctorsBySpecialty(String specialtyId) =>
      _doctors.bySpecialty(specialtyId);

  data.Specialty? specialtyById(String? id) {
    if (id == null) return null;
    for (final specialty in data.specialties) {
      if (specialty.id == id) return specialty;
    }
    return null;
  }

  data.Specialty? findSpecialty(String input) {
    final text = normalizeArabic(input);
    final matches = <({data.Specialty specialty, int length})>[];
    for (final specialty in data.specialties) {
      for (final keyword in specialty.keywords) {
        final normalized = normalizeArabic(keyword);
        if (_matchesTerm(text, normalized)) {
          matches.add((specialty: specialty, length: normalized.length));
        }
      }
    }
    if (matches.isEmpty) return null;
    matches.sort((a, b) => b.length.compareTo(a.length));
    final bestLength = matches.first.length;
    final best = matches
        .where((match) => match.length == bestLength)
        .map((match) => match.specialty.id)
        .toSet();
    if (best.length != 1) return null;
    return specialtyById(best.single);
  }

  bool _matchesTerm(String text, String term) {
    if (term.isEmpty) return false;
    if (term.contains(' ')) return text.contains(term);
    final words = text.split(' ');
    if (words.contains(term)) return true;
    return RegExp(r'[\u0621-\u064A]').hasMatch(term) &&
        words.any((word) =>
            word.endsWith(term) && word.length - term.length <= 3);
  }
}
