import '../../models/assistant_response.dart';
import 'ai_provider.dart';
import 'local_ai_fallback.dart';

/// Chat-facing service. The shipped provider is local; future providers can be
/// injected without coupling the chat screen to their implementation.
class AiService {
  factory AiService({AiProvider? provider, AiProvider? fallback}) {
    final localProvider = LocalAiFallback();
    return AiService._(
      provider ?? localProvider,
      fallback ?? localProvider,
    );
  }

  AiService._(this._provider, this._fallback);

  final AiProvider _provider;
  final AiProvider _fallback;

  Future<AssistantResponse> respond(
    String message, {
    List<AiChatTurn> history = const [],
    String? currentLocationId,
    String? destinationId,
  }) async {
    final request = AssistantRequest(
      message: message,
      history: history,
      currentLocationId: currentLocationId,
      destinationId: destinationId,
    );
    if (identical(_provider, _fallback)) return _provider.respond(request);
    try {
      return await _provider.respond(request);
    } catch (_) {
      return _fallback.respond(request);
    }
  }
}
