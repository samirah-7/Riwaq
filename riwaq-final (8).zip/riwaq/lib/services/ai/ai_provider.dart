import '../../models/assistant_response.dart';

class AiChatTurn {
  const AiChatTurn({required this.role, required this.content});

  final String role;
  final String content;
}

class AssistantRequest {
  const AssistantRequest({
    required this.message,
    this.history = const [],
    this.currentLocationId,
    this.destinationId,
  });

  final String message;
  final List<AiChatTurn> history;
  final String? currentLocationId;
  final String? destinationId;
}

/// Replace this provider to add a future language-understanding implementation.
abstract interface class AiProvider {
  Future<AssistantResponse> respond(AssistantRequest request);
}
