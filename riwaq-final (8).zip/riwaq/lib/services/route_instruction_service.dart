import '../data/hospital_floor_plan_data.dart';
import '../l10n/riwaq_text.dart';
import '../models/hospital_floor_plan.dart';
import '../models/navigation_instruction.dart';

/// Converts the authored simulated graph path into readable turn instructions.
///
/// Coordinates are conceptual, so this deliberately avoids distances and ETAs.
class RouteInstructionService {
  const RouteInstructionService();

  List<NavigationInstruction> build(HospitalRoute route) {
    final places = route.places;
    if (places.length < 2) return const [];

    final instructions = <NavigationInstruction>[];
    _Direction? previousDirection;
    var lastInstructionIndex = -1;

    for (var index = 1; index < places.length; index++) {
      final from = places[index - 1];
      final to = places[index];
      final arrival = index == places.length - 1;

      if (from.floorId != to.floorId) {
        final mode =
            from.category == FloorPlaceCategory.elevator ? 'المصعد' : 'السلالم';
        final modeEn = from.category == FloorPlaceCategory.elevator
            ? 'the elevator'
            : 'the stairs';
        final floor = hospitalFloorPlans.firstWhere(
          (item) => item.id == to.floorId,
        );
        instructions.add(NavigationInstruction(
          fromIndex: index - 1,
          toIndex: index,
          floorId: to.floorId,
          maneuver: NavigationManeuver.floorTransition,
          textAr: 'انتقل عبر $mode من ${from.nameAr} إلى ${floor.nameAr}.',
          textEn:
              'Take $modeEn from ${_placeNameEn(from)} to ${riwaqFloorName(floor.id, floor.nameAr, languageCode: 'en')}.',
          arrival: arrival,
        ));
        previousDirection = null;
        lastInstructionIndex = instructions.length - 1;
        continue;
      }

      final direction = _direction(from, to);
      final previous = previousDirection;
      final maneuver = previous == null
          ? NavigationManeuver.start
          : previous == direction
              ? NavigationManeuver.straight
              : _turn(previous, direction);
      final text = _instructionText(maneuver, to, arrival);

      final canExtend = maneuver == NavigationManeuver.straight &&
          lastInstructionIndex >= 0 &&
          instructions[lastInstructionIndex].floorId == to.floorId &&
          !instructions[lastInstructionIndex].arrival;
      if (canExtend) {
        final previousInstruction = instructions[lastInstructionIndex];
        instructions[lastInstructionIndex] = NavigationInstruction(
          fromIndex: previousInstruction.fromIndex,
          toIndex: index,
          floorId: to.floorId,
          maneuver: previousInstruction.maneuver,
          textAr: _continuedInstructionText(
            previousInstruction.maneuver,
            to,
            arrival,
          ),
          textEn: _continuedInstructionTextEn(
            previousInstruction.maneuver,
            to,
            arrival,
          ),
          arrival: arrival,
        );
      } else {
        instructions.add(NavigationInstruction(
          fromIndex: index - 1,
          toIndex: index,
          floorId: to.floorId,
          maneuver: maneuver,
          textAr: text,
          textEn: _instructionTextEn(maneuver, to, arrival),
          arrival: arrival,
        ));
        lastInstructionIndex = instructions.length - 1;
      }
      previousDirection = direction;
    }
    return List.unmodifiable(instructions);
  }

  String _instructionText(
    NavigationManeuver maneuver,
    FloorPlanPlace target,
    bool arrival,
  ) {
    if (arrival) {
      return switch (maneuver) {
        NavigationManeuver.turnLeft =>
          'انعطف يساراً ثم وصل إلى ${target.nameAr}.',
        NavigationManeuver.turnRight =>
          'انعطف يميناً ثم وصل إلى ${target.nameAr}.',
        NavigationManeuver.turnAround => 'استدر ثم وصل إلى ${target.nameAr}.',
        _ => 'وصل إلى ${target.nameAr}.',
      };
    }
    return switch (maneuver) {
      NavigationManeuver.start =>
        'ابدأ من موقعك التجريبي باتجاه ${target.nameAr}.',
      NavigationManeuver.straight => 'تابع مباشرة حتى ${target.nameAr}.',
      NavigationManeuver.turnLeft => 'انعطف يساراً باتجاه ${target.nameAr}.',
      NavigationManeuver.turnRight => 'انعطف يميناً باتجاه ${target.nameAr}.',
      NavigationManeuver.turnAround => 'استدر باتجاه ${target.nameAr}.',
      NavigationManeuver.floorTransition => 'انتقل إلى ${target.nameAr}.',
    };
  }

  String _continuedInstructionText(
    NavigationManeuver maneuver,
    FloorPlanPlace target,
    bool arrival,
  ) {
    final prefix = switch (maneuver) {
      NavigationManeuver.start => 'ابدأ من موقعك التجريبي ثم تابع مباشرة',
      NavigationManeuver.turnLeft => 'انعطف يساراً ثم تابع مباشرة',
      NavigationManeuver.turnRight => 'انعطف يميناً ثم تابع مباشرة',
      NavigationManeuver.turnAround => 'استدر ثم تابع مباشرة',
      _ => 'تابع مباشرة',
    };
    return arrival
        ? '$prefix حتى تصل إلى ${target.nameAr}.'
        : '$prefix حتى ${target.nameAr}.';
  }

  String _instructionTextEn(
    NavigationManeuver maneuver,
    FloorPlanPlace target,
    bool arrival,
  ) {
    final name = _placeNameEn(target);
    if (arrival) {
      return switch (maneuver) {
        NavigationManeuver.turnLeft => 'Turn left, then arrive at $name.',
        NavigationManeuver.turnRight => 'Turn right, then arrive at $name.',
        NavigationManeuver.turnAround => 'Turn around, then arrive at $name.',
        _ => 'Arrive at $name.',
      };
    }
    return switch (maneuver) {
      NavigationManeuver.start =>
        'Start from the simulated location toward $name.',
      NavigationManeuver.straight => 'Continue straight to $name.',
      NavigationManeuver.turnLeft => 'Turn left toward $name.',
      NavigationManeuver.turnRight => 'Turn right toward $name.',
      NavigationManeuver.turnAround => 'Turn around toward $name.',
      NavigationManeuver.floorTransition => 'Continue to $name.',
    };
  }

  String _continuedInstructionTextEn(
    NavigationManeuver maneuver,
    FloorPlanPlace target,
    bool arrival,
  ) {
    final prefix = switch (maneuver) {
      NavigationManeuver.start =>
        'Start from the simulated location and continue straight',
      NavigationManeuver.turnLeft => 'Turn left, then continue straight',
      NavigationManeuver.turnRight => 'Turn right, then continue straight',
      NavigationManeuver.turnAround => 'Turn around, then continue straight',
      _ => 'Continue straight',
    };
    final suffix = arrival ? 'until you reach' : 'to';
    return '$prefix $suffix ${_placeNameEn(target)}.';
  }

  String _placeNameEn(FloorPlanPlace place) => riwaqPlaceName(
        place.mapLocationId ?? place.id,
        place.nameAr,
        languageCode: 'en',
      );

  _Direction _direction(FloorPlanPlace from, FloorPlanPlace to) {
    final dx = to.x - from.x;
    final dy = to.y - from.y;
    if (dx.abs() >= dy.abs()) {
      return dx >= 0 ? _Direction.east : _Direction.west;
    }
    return dy >= 0 ? _Direction.south : _Direction.north;
  }

  NavigationManeuver _turn(_Direction from, _Direction to) {
    final vectors = {
      _Direction.east: const (x: 1.0, y: 0.0),
      _Direction.south: const (x: 0.0, y: 1.0),
      _Direction.west: const (x: -1.0, y: 0.0),
      _Direction.north: const (x: 0.0, y: -1.0),
    };
    final a = vectors[from]!;
    final b = vectors[to]!;
    final cross = a.x * b.y - a.y * b.x;
    final dot = a.x * b.x + a.y * b.y;
    if (dot < 0) return NavigationManeuver.turnAround;
    return cross > 0
        ? NavigationManeuver.turnRight
        : NavigationManeuver.turnLeft;
  }
}

enum _Direction { north, east, south, west }
