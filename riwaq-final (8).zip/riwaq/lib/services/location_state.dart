import 'package:flutter/foundation.dart';
import '../models/indoor_localization.dart';

enum RiwaqLocationSource { simulated, visualMarker, gpsApproximate }

/// Shared virtual-map integration contract. IDs refer only to registered demo locations.
class RiwaqLocationState extends ChangeNotifier {
  RiwaqLocationState._();
  static final RiwaqLocationState instance = RiwaqLocationState._();

  String? currentLocationId;
  String? destinationLocationId;
  String buildingId = 'VIRTUAL_BUILDING';
  int? currentFloor;
  int? destinationFloor;
  IndoorLocationPrediction? currentPrediction;
  RiwaqLocationSource currentLocationSource = RiwaqLocationSource.simulated;
  double? approximateGpsAccuracyMeters;

  void setCurrent(
      {required String locationId,
      required int floor,
      String building = 'VIRTUAL_BUILDING',
      IndoorLocationPrediction? prediction,
      RiwaqLocationSource source = RiwaqLocationSource.simulated}) {
    currentLocationId = locationId;
    currentFloor = floor;
    buildingId = building;
    currentPrediction = prediction;
    currentLocationSource = source;
    approximateGpsAccuracyMeters = null;
    notifyListeners();
  }

  /// Records an outdoor-only GPS fix without guessing its matching indoor node.
  void setApproximateGps({required double accuracyMeters}) {
    currentLocationSource = RiwaqLocationSource.gpsApproximate;
    approximateGpsAccuracyMeters = accuracyMeters;
    notifyListeners();
  }

  void setDestination({required String locationId, required int floor}) {
    destinationLocationId = locationId;
    destinationFloor = floor;
    notifyListeners();
  }
}
