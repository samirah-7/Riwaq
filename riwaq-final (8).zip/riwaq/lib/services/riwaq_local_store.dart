import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RiwaqLocalStore extends ChangeNotifier {
  RiwaqLocalStore._();

  static final RiwaqLocalStore instance = RiwaqLocalStore._();

  static const _savedKey = 'riwaq.savedLocations';
  static const _readNotificationsKey = 'riwaq.readNotifications';
  static const _dismissedNotificationsKey = 'riwaq.dismissedNotifications';
  static const _notificationsEnabledKey = 'riwaq.notificationsEnabled';
  static const _appointmentRemindersKey = 'riwaq.appointmentReminders';
  static const _profileNameKey = 'riwaq.profileName';
  static const _profilePhoneKey = 'riwaq.profilePhone';
  static const _allowStairsKey = 'riwaq.map.allowStairs';
  static const _allowElevatorsKey = 'riwaq.map.allowElevators';
  static const _languageKey = 'riwaq.language';
  static const _darkModeKey = 'riwaq.darkMode';

  SharedPreferences? _preferences;
  @visibleForTesting
  Future<bool> Function(String key, bool value)?
      mobilityPreferenceWriteOverride;
  final Set<String> savedLocationIds = {};
  final Set<String> readNotificationIds = {};
  final Set<String> dismissedNotificationIds = {};
  bool notificationsEnabled = true;
  bool appointmentRemindersEnabled = true;
  bool allowStairs = true;
  bool allowElevators = true;
  String languageCode = 'ar';
  bool darkMode = false;
  String profileName = 'زائر رِواق';
  String profilePhone = '';

  Future<void> initialize() async {
    _preferences = await SharedPreferences.getInstance();
    savedLocationIds
      ..clear()
      ..addAll(_preferences?.getStringList(_savedKey) ?? const []);
    readNotificationIds
      ..clear()
      ..addAll(_preferences?.getStringList(_readNotificationsKey) ?? const []);
    dismissedNotificationIds
      ..clear()
      ..addAll(
          _preferences?.getStringList(_dismissedNotificationsKey) ?? const []);
    notificationsEnabled =
        _preferences?.getBool(_notificationsEnabledKey) ?? true;
    appointmentRemindersEnabled =
        _preferences?.getBool(_appointmentRemindersKey) ?? true;
    allowStairs = _preferences?.getBool(_allowStairsKey) ?? true;
    allowElevators = _preferences?.getBool(_allowElevatorsKey) ?? true;
    languageCode = _preferences?.getString(_languageKey) == 'en' ? 'en' : 'ar';
    darkMode = _preferences?.getBool(_darkModeKey) ?? false;
    profileName = _preferences?.getString(_profileNameKey) ?? 'زائر رِواق';
    profilePhone = _preferences?.getString(_profilePhoneKey) ?? '';
    notifyListeners();
  }

  bool isSaved(String locationId) => savedLocationIds.contains(locationId);

  Future<void> toggleSaved(String locationId) async {
    if (!savedLocationIds.add(locationId)) savedLocationIds.remove(locationId);
    notifyListeners();
    await _preferences?.setStringList(_savedKey, savedLocationIds.toList());
  }

  Future<void> markNotificationRead(String notificationId) async {
    if (!readNotificationIds.add(notificationId)) return;
    notifyListeners();
    await _preferences?.setStringList(
        _readNotificationsKey, readNotificationIds.toList());
  }

  Future<void> markNotificationsRead(Iterable<String> notificationIds) async {
    readNotificationIds.addAll(notificationIds);
    notifyListeners();
    await _preferences?.setStringList(
        _readNotificationsKey, readNotificationIds.toList());
  }

  Future<void> dismissNotifications(Iterable<String> notificationIds) async {
    dismissedNotificationIds.addAll(notificationIds);
    notifyListeners();
    await _preferences?.setStringList(
        _dismissedNotificationsKey, dismissedNotificationIds.toList());
  }

  Future<void> setNotificationsEnabled(bool value) async {
    notificationsEnabled = value;
    notifyListeners();
    await _preferences?.setBool(_notificationsEnabledKey, value);
  }

  Future<void> setAppointmentRemindersEnabled(bool value) async {
    appointmentRemindersEnabled = value;
    notifyListeners();
    await _preferences?.setBool(_appointmentRemindersKey, value);
  }

  Future<bool> _saveMobilityPreference(String key, bool value) async {
    try {
      final override = mobilityPreferenceWriteOverride;
      if (override != null) return await override(key, value);
      final preferences = _preferences;
      if (preferences == null) return false;
      return await preferences.setBool(key, value);
    } catch (_) {
      return false;
    }
  }

  Future<bool> setAllowStairs(bool value) async {
    allowStairs = value;
    notifyListeners();
    return _saveMobilityPreference(_allowStairsKey, value);
  }

  Future<bool> setAllowElevators(bool value) async {
    allowElevators = value;
    notifyListeners();
    return _saveMobilityPreference(_allowElevatorsKey, value);
  }

  Future<void> setLanguageCode(String value) async {
    languageCode = value == 'en' ? 'en' : 'ar';
    notifyListeners();
    await _preferences?.setString(_languageKey, languageCode);
  }

  Future<void> setDarkMode(bool value) async {
    darkMode = value;
    notifyListeners();
    await _preferences?.setBool(_darkModeKey, value);
  }

  Future<bool> resetMobilityPreferences() async {
    allowStairs = true;
    allowElevators = true;
    notifyListeners();
    final results = await Future.wait([
      _saveMobilityPreference(_allowStairsKey, true),
      _saveMobilityPreference(_allowElevatorsKey, true),
    ]);
    return results.every((saved) => saved);
  }

  Future<void> saveProfile(
      {required String name, required String phone}) async {
    profileName = name.trim();
    profilePhone = phone.trim();
    notifyListeners();
    await _preferences?.setString(_profileNameKey, profileName);
    await _preferences?.setString(_profilePhoneKey, profilePhone);
  }
}
