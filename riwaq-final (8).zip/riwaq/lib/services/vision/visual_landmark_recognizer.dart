import 'dart:math' as math;
import 'package:flutter/services.dart';
import 'package:image/image.dart' as image_lib;

import '../../data/landmark_reference_data.dart';
import '../../models/visual_landmark.dart';

/// Lightweight appearance matching for approved virtual-scene reference photos.
/// It is deliberately disabled as a locator until references are registered.
class VisualLandmarkRecognizer {
  VisualLandmarkRecognizer({
    this.references = visualLandmarkReferences,
    AssetBundle? assetBundle,
  }) : _assetBundle = assetBundle ?? rootBundle;

  final List<VisualLandmarkReference> references;
  final AssetBundle _assetBundle;

  static const minimumConfidence = .86;
  static const minimumSeparation = .04;

  Future<VisualRecognitionResult> recognizeBytes(Uint8List bytes) async {
    final frame = image_lib.decodeImage(bytes);
    if (frame == null) {
      return const VisualRecognitionResult(
          status: VisualRecognitionStatus.invalidImage);
    }

    final frameDescriptor = describe(frame);
    if (references.isEmpty) {
      return const VisualRecognitionResult(
          status: VisualRecognitionStatus.noReferenceData);
    }

    final bestPerLocation = <String, double>{};
    for (final reference in references) {
      try {
        final data = await _assetBundle.load(reference.assetPath);
        final refBytes =
            data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
        final referenceImage = image_lib.decodeImage(refBytes);
        if (referenceImage == null) continue;
        final confidence =
            similarity(frameDescriptor, describe(referenceImage));
        final previous = bestPerLocation[reference.locationId] ?? 0;
        if (confidence > previous) {
          bestPerLocation[reference.locationId] = confidence;
        }
      } catch (_) {
        // Missing or corrupt references cannot establish a location.
      }
    }
    if (bestPerLocation.isEmpty) {
      return const VisualRecognitionResult(
          status: VisualRecognitionStatus.noReferenceData);
    }
    final scores = bestPerLocation.entries
        .map((entry) => (locationId: entry.key, confidence: entry.value))
        .toList();
    scores.sort((a, b) => b.confidence.compareTo(a.confidence));
    final best = scores.first;
    final separation =
        scores.length == 1 ? 1.0 : best.confidence - scores[1].confidence;
    if (best.confidence < minimumConfidence || separation < minimumSeparation) {
      return VisualRecognitionResult(
        status: VisualRecognitionStatus.noReliableMatch,
        confidence: best.confidence,
      );
    }
    return VisualRecognitionResult(
      status: VisualRecognitionStatus.matched,
      locationId: best.locationId,
      confidence: best.confidence,
    );
  }

  /// Produces a normalized 16×16 luminance pattern plus per-channel color histogram.
  static List<double> describe(image_lib.Image source) {
    final sample = image_lib.copyResize(source, width: 16, height: 16);
    final luminances = <double>[];
    final histograms = List.generate(3, (_) => List<double>.filled(8, 0));
    for (final pixel in sample) {
      final r = pixel.r.toDouble() / 255;
      final g = pixel.g.toDouble() / 255;
      final b = pixel.b.toDouble() / 255;
      luminances.add(.299 * r + .587 * g + .114 * b);
      histograms[0][math.min(7, (r * 8).floor())]++;
      histograms[1][math.min(7, (g * 8).floor())]++;
      histograms[2][math.min(7, (b * 8).floor())]++;
    }
    final mean = luminances.reduce((a, b) => a + b) / luminances.length;
    final variance =
        luminances.map((v) => (v - mean) * (v - mean)).reduce((a, b) => a + b) /
            luminances.length;
    final deviation = math.sqrt(variance) + .05;
    final normalizedPattern =
        luminances.map((v) => ((v - mean) / deviation).clamp(-2, 2) / 4 + .5);
    final colorFeatures = histograms.expand(
        (histogram) => histogram.map((value) => value / luminances.length));
    return [...normalizedPattern, ...colorFeatures];
  }

  /// Returns a similarity score in [0, 1]; it is not a calibrated probability.
  static double similarity(List<double> left, List<double> right) {
    if (left.length != 280 || right.length != 280) return 0;
    final spatialDistance =
        List.generate(256, (i) => (left[i] - right[i]).abs())
                .reduce((a, b) => a + b) /
            256;
    final colorDistance =
        List.generate(24, (i) => (left[256 + i] - right[256 + i]).abs())
                .reduce((a, b) => a + b) /
            6;
    return (1 - (.75 * spatialDistance + .25 * colorDistance)).clamp(0.0, 1.0);
  }
}
