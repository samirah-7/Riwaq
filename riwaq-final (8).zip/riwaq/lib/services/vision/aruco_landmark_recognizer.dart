import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../../data/aruco_landmarks.dart';
import '../../data/repositories/location_repository.dart';
import '../location_state.dart';

enum ArucoRecognitionStatus {
  recognized,
  noMarker,
  unknownMarker,
  lowQuality,
  unsupported,
  error,
}

class ArucoMarkerObservation {
  const ArucoMarkerObservation({
    required this.markerId,
    required this.qualityScore,
    required this.areaRatio,
    required this.shortestEdgePx,
    required this.accepted,
  });

  final int markerId;
  final double qualityScore;
  final double areaRatio;
  final double shortestEdgePx;
  final bool accepted;

  factory ArucoMarkerObservation.fromPlatform(Object? value) {
    if (value is! Map) {
      throw const FormatException('Invalid ArUco observation.');
    }
    final markerId = value['markerId'];
    if (markerId is! num) {
      throw const FormatException('ArUco observation has no marker ID.');
    }
    return ArucoMarkerObservation(
      markerId: markerId.toInt(),
      qualityScore: _asDouble(value['qualityScore']),
      areaRatio: _asDouble(value['areaRatio']),
      shortestEdgePx: _asDouble(value['shortestEdgePx']),
      accepted: value['accepted'] == true,
    );
  }

  static double _asDouble(Object? value) => value is num ? value.toDouble() : 0;
}

class ArucoRecognitionResult {
  const ArucoRecognitionResult({
    required this.status,
    this.markerId,
    this.locationId,
    this.qualityScore,
    this.areaRatio,
    this.shortestEdgePx,
    this.message,
  });

  final ArucoRecognitionStatus status;
  final int? markerId;
  final String? locationId;
  final double? qualityScore;
  final double? areaRatio;
  final double? shortestEdgePx;
  final String? message;
}

class ArucoLandmarkRecognizer {
  ArucoLandmarkRecognizer({MethodChannel? channel})
      : _channel = channel ?? const MethodChannel('riwaq/aruco');

  static const minimumQualityScore = 0.55;
  static const minimumAreaRatio = 0.02;
  static const minimumShortestEdgePx = 80.0;

  final MethodChannel _channel;

  Future<ArucoRecognitionResult> recognizeBytes(Uint8List imageBytes) async {
    if (kIsWeb) {
      return const ArucoRecognitionResult(
        status: ArucoRecognitionStatus.unsupported,
      );
    }
    try {
      final values = await _channel.invokeListMethod<Object?>(
        'detectArucoMarkers',
        {'imageBytes': imageBytes},
      );
      final observations = (values ?? const <Object?>[])
          .map(ArucoMarkerObservation.fromPlatform)
          .toList(growable: false);
      return evaluate(observations);
    } on MissingPluginException {
      return const ArucoRecognitionResult(
        status: ArucoRecognitionStatus.unsupported,
      );
    } on PlatformException catch (exception) {
      return ArucoRecognitionResult(
        status: ArucoRecognitionStatus.error,
        message: exception.message,
      );
    } on FormatException catch (exception) {
      return ArucoRecognitionResult(
        status: ArucoRecognitionStatus.error,
        message: exception.message,
      );
    }
  }

  Future<Uint8List?> generateMarkerPng(int markerId) async {
    if (kIsWeb || locationIdForArucoMarker(markerId) == null) return null;
    try {
      return await _channel.invokeMethod<Uint8List>(
        'generateArucoMarker',
        {'markerId': markerId, 'sidePixels': 360},
      );
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  static ArucoRecognitionResult evaluate(
    List<ArucoMarkerObservation> observations,
  ) {
    if (observations.isEmpty) {
      return const ArucoRecognitionResult(
        status: ArucoRecognitionStatus.noMarker,
      );
    }

    final ranked = [...observations]
      ..sort((a, b) => b.qualityScore.compareTo(a.qualityScore));
    final known = ranked
        .where((observation) =>
            locationIdForArucoMarker(observation.markerId) != null)
        .toList(growable: false);
    if (known.isEmpty) {
      final marker = ranked.first;
      return ArucoRecognitionResult(
        status: ArucoRecognitionStatus.unknownMarker,
        markerId: marker.markerId,
        qualityScore: marker.qualityScore,
        areaRatio: marker.areaRatio,
        shortestEdgePx: marker.shortestEdgePx,
      );
    }

    final acceptable = known.where(_meetsQualityThresholds).toList();
    if (acceptable.isNotEmpty) {
      final marker = acceptable.first;
      return ArucoRecognitionResult(
        status: ArucoRecognitionStatus.recognized,
        markerId: marker.markerId,
        locationId: locationIdForArucoMarker(marker.markerId),
        qualityScore: marker.qualityScore,
        areaRatio: marker.areaRatio,
        shortestEdgePx: marker.shortestEdgePx,
      );
    }

    final marker = known.first;
    return ArucoRecognitionResult(
      status: ArucoRecognitionStatus.lowQuality,
      markerId: marker.markerId,
      qualityScore: marker.qualityScore,
      areaRatio: marker.areaRatio,
      shortestEdgePx: marker.shortestEdgePx,
    );
  }

  static bool _meetsQualityThresholds(ArucoMarkerObservation marker) =>
      marker.accepted &&
      marker.qualityScore >= minimumQualityScore &&
      marker.areaRatio >= minimumAreaRatio &&
      marker.shortestEdgePx >= minimumShortestEdgePx;
}

bool applyArucoRecognitionToLocation({
  required ArucoRecognitionResult result,
  required LocationRepository repository,
  RiwaqLocationState? locationState,
}) {
  if (result.status != ArucoRecognitionStatus.recognized ||
      result.locationId == null) {
    return false;
  }
  final location = repository.byId(result.locationId);
  if (location == null) return false;
  (locationState ?? RiwaqLocationState.instance).setCurrent(
    locationId: location.id,
    floor: location.floor,
    building: location.buildingId,
    source: RiwaqLocationSource.visualMarker,
  );
  return true;
}
