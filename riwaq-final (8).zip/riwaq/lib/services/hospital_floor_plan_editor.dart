import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/hospital_floor_plan_data.dart';
import '../models/hospital_floor_plan.dart';

/// Local-only import/export for conceptual floor plans.
///
/// Imported content is always kept in the simulated, unverified state. Floor
/// metadata and artwork stay owned by the app; staff edit places and route
/// edges in the exported JSON document.
class HospitalFloorPlanEditor {
  HospitalFloorPlanEditor._();

  static const _storageKey = 'riwaq.simulatedFloorPlans.v1';
  static const _schemaVersion = 1;

  static Future<void> restore() async {
    final preferences = await SharedPreferences.getInstance();
    final saved = preferences.getString(_storageKey);
    if (saved == null) return;
    try {
      final restored = _restoreAndMigrate(saved, base: hospitalFloorPlans);
      hospitalFloorPlans = restored;
      final migratedJson = exportJson(floors: restored);
      if (migratedJson != saved) {
        // The in-memory recovery must not depend on writing the upgraded copy.
        await preferences.setString(_storageKey, migratedJson);
      }
    } on FormatException {
      // A stale or unsupported local prototype save must never block startup.
      // Keep the already-initialized bundled plans and best-effort remove the
      // bad save so it does not fail in the same way on every launch.
      try {
        await preferences.remove(_storageKey);
      } catch (_) {
        // Storage cleanup is secondary to opening with bundled data.
      }
    }
  }

  /// Restores a local snapshot against the current bundled registry.
  ///
  /// Floor and place IDs are the only safe identity mapping available. Floors
  /// that no longer exist are ignored, matching places keep their saved edits,
  /// and new bundled places are added. References to removed nodes are pruned.
  /// If none of the saved floors can be matched, the document is unrecoverable.
  static List<HospitalFloorPlan> _restoreAndMigrate(
    String jsonText, {
    required List<HospitalFloorPlan> base,
  }) {
    final decoded = jsonDecode(jsonText);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('The document must be a JSON object.');
    }
    if (decoded['schemaVersion'] != _schemaVersion) {
      throw const FormatException('Unsupported schemaVersion.');
    }
    if (decoded['dataStatus'] != 'SIMULATED_UNVERIFIED') {
      throw const FormatException('dataStatus must be SIMULATED_UNVERIFIED.');
    }
    final rawFloors = decoded['floors'];
    if (rawFloors is! List || rawFloors.isEmpty) {
      throw const FormatException('floors must be a non-empty array.');
    }

    final baseById = {for (final floor in base) floor.id: floor};
    final savedFloors = <String, Map<String, dynamic>>{};
    var matchedFloorCount = 0;
    for (final rawFloor in rawFloors) {
      final floorJson = _object(rawFloor, 'Each floor must be an object.');
      final floorId = _requiredString(floorJson, 'id');
      if (savedFloors.containsKey(floorId)) {
        throw FormatException('Floor "$floorId" appears more than once.');
      }
      savedFloors[floorId] = floorJson;
      if (baseById.containsKey(floorId)) matchedFloorCount++;
    }
    if (matchedFloorCount == 0) {
      throw const FormatException(
          'The saved plans do not match any bundled floor.');
    }

    final replacements = <String, HospitalFloorPlan>{};
    for (final template in base) {
      final floorJson = savedFloors[template.id];
      if (floorJson == null) continue;
      final rawPlaces = floorJson['places'];
      final rawEdges = floorJson['edges'];
      if (rawPlaces is! List || rawEdges is! List) {
        throw FormatException(
            'Floor "${template.id}" must include places and edges arrays.');
      }

      final savedPlaces = <String, FloorPlanPlace>{};
      for (final rawPlace in rawPlaces) {
        final place = _parsePlace(rawPlace, expectedFloorId: template.id);
        if (savedPlaces.containsKey(place.id)) {
          throw FormatException(
              'Place "${place.id}" appears more than once on "${template.id}".');
        }
        savedPlaces[place.id] = place;
      }

      final placesById = <String, FloorPlanPlace>{
        for (final place in template.places)
          place.id: savedPlaces[place.id] ?? place,
      };
      for (final place in savedPlaces.values) {
        placesById.putIfAbsent(place.id, () => place);
      }
      final floorPlaceIds = placesById.keys.toSet();
      final places = [
        for (final place in placesById.values)
          FloorPlanPlace(
            id: place.id,
            floorId: template.id,
            nameAr: place.nameAr,
            category: place.category,
            descriptionAr: place.descriptionAr,
            x: place.x,
            y: place.y,
            mapLocationId: place.mapLocationId,
            connections: [
              for (final targetId in place.connections)
                if (floorPlaceIds.contains(targetId)) targetId,
            ],
            bounds: place.bounds,
            zone: place.zone,
            verticalConnectionId: place.verticalConnectionId,
            keywords: place.keywords,
          ),
      ];

      final savedEdges = <FloorPlanConnection>[];
      for (final rawEdge in rawEdges) {
        final edge = _parseEdge(rawEdge);
        final from = placesById[edge.fromId];
        final to = placesById[edge.toId];
        // A removed node or a node moved to another floor invalidates only
        // this edge, not the rest of an otherwise recoverable local plan.
        if (from == null || to == null || from.floorId != template.id) {
          continue;
        }
        savedEdges.add(edge);
      }
      replacements[template.id] = HospitalFloorPlan(
        id: template.id,
        level: template.level,
        nameAr: template.nameAr,
        assetPath: template.assetPath,
        corridors: template.corridors,
        isSimulated: true,
        places: places,
        connections: savedEdges,
      );
    }

    final result = List<HospitalFloorPlan>.unmodifiable([
      for (final floor in base) replacements[floor.id] ?? floor,
    ]);
    _validateRegistry(result);
    return result;
  }

  static String exportJson({List<HospitalFloorPlan>? floors}) {
    final selected = floors ?? hospitalFloorPlans;
    return const JsonEncoder.withIndent('  ').convert({
      'schemaVersion': _schemaVersion,
      'dataStatus': 'SIMULATED_UNVERIFIED',
      'notice':
          'Conceptual prototype data only. Locations and route edges are simulated and unverified; never use for real-world wayfinding.',
      'floors': [
        for (final floor in selected)
          {
            'id': floor.id,
            'places': [
              for (final place in floor.places)
                {
                  'id': place.id,
                  'floorId': place.floorId,
                  'nameAr': place.nameAr,
                  'category': place.category.name,
                  'descriptionAr': place.descriptionAr,
                  'x': place.x,
                  'y': place.y,
                  'mapLocationId': place.mapLocationId,
                  'zone': place.zone.name,
                  'verticalConnectionId': place.verticalConnectionId,
                  'keywords': place.keywords,
                  'pathLinks': place.connections,
                  if (place.bounds != null)
                    'bounds': {
                      'left': place.bounds!.left,
                      'top': place.bounds!.top,
                      'width': place.bounds!.width,
                      'height': place.bounds!.height,
                    },
                },
            ],
            'edges': [
              for (final edge in floor.connections)
                {
                  'fromId': edge.fromId,
                  'toId': edge.toId,
                  'type': edge.type.name,
                },
            ],
          },
      ],
    });
  }

  /// Validates the entire proposed registry without changing current data.
  static List<HospitalFloorPlan> decodeAndValidate(
    String jsonText, {
    List<HospitalFloorPlan>? base,
  }) {
    final source = base ?? hospitalFloorPlans;
    final decoded = jsonDecode(jsonText);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('The document must be a JSON object.');
    }
    if (decoded['schemaVersion'] != _schemaVersion) {
      throw const FormatException('Unsupported schemaVersion.');
    }
    if (decoded['dataStatus'] != 'SIMULATED_UNVERIFIED') {
      throw const FormatException('dataStatus must be SIMULATED_UNVERIFIED.');
    }
    final rawFloors = decoded['floors'];
    if (rawFloors is! List || rawFloors.isEmpty) {
      throw const FormatException('floors must be a non-empty array.');
    }

    final floorsById = {for (final floor in source) floor.id: floor};
    final replacements = <String, HospitalFloorPlan>{};
    for (final rawFloor in rawFloors) {
      final floorJson = _object(rawFloor, 'Each floor must be an object.');
      final floorId = _requiredString(floorJson, 'id');
      final template = floorsById[floorId];
      if (template == null) {
        throw FormatException('Unknown floor ID "$floorId".');
      }
      if (replacements.containsKey(floorId)) {
        throw FormatException('Floor "$floorId" appears more than once.');
      }
      final rawPlaces = floorJson['places'];
      final rawEdges = floorJson['edges'];
      if (rawPlaces is! List || rawEdges is! List) {
        throw FormatException(
            'Floor "$floorId" must include places and edges arrays.');
      }
      replacements[floorId] = HospitalFloorPlan(
        id: template.id,
        level: template.level,
        nameAr: template.nameAr,
        assetPath: template.assetPath,
        corridors: template.corridors,
        isSimulated: true,
        places: [
          for (final rawPlace in rawPlaces)
            _parsePlace(rawPlace, expectedFloorId: floorId),
        ],
        connections: [
          for (final rawEdge in rawEdges) _parseEdge(rawEdge),
        ],
      );
    }

    final result = List<HospitalFloorPlan>.unmodifiable([
      for (final floor in source) replacements[floor.id] ?? floor,
    ]);
    _validateRegistry(result);
    return result;
  }

  /// Persists only after all IDs, coordinates and graph edges are validated.
  static Future<void> importAndSave(String jsonText) async {
    final validated = decodeAndValidate(jsonText);
    await saveValidated(validated);
  }

  /// Persists a registry previously returned by [decodeAndValidate].
  static Future<void> saveValidated(List<HospitalFloorPlan> validated) async {
    _validateRegistry(validated);
    final safeValidated = List<HospitalFloorPlan>.unmodifiable(validated);
    final encoded = exportJson(floors: safeValidated);
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setString(_storageKey, encoded);
    if (!saved) {
      throw StateError('Could not save the simulated floor-plan data locally.');
    }
    hospitalFloorPlans = safeValidated;
  }

  static Future<void> resetToDefaults() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_storageKey);
    // The default source registry is initialized before this editor is used.
    hospitalFloorPlans = defaultHospitalFloorPlans;
  }

  static FloorPlanPlace _parsePlace(
    Object? raw, {
    required String expectedFloorId,
  }) {
    final json = _object(raw, 'Each place must be an object.');
    final id = _requiredString(json, 'id');
    final floorId = _requiredString(json, 'floorId');
    if (floorId != expectedFloorId) {
      throw FormatException(
          'Place "$id" must belong to its containing floor "$expectedFloorId".');
    }
    final category = _enumValue(FloorPlaceCategory.values, json['category'],
        'category for place "$id"');
    final zone = _enumValue(PlanZone.values, json['zone'], 'zone for "$id"');
    final x = _number(json['x'], 'x for "$id"');
    final y = _number(json['y'], 'y for "$id"');
    if (x < 0 || x > 1 || y < 0 || y > 1) {
      throw FormatException('Place "$id" coordinates must be between 0 and 1.');
    }
    final rawKeywords = json['keywords'] ?? const [];
    final rawPathLinks = json['pathLinks'] ?? const [];
    if (rawKeywords is! List || rawPathLinks is! List) {
      throw FormatException('keywords and pathLinks for "$id" must be arrays.');
    }
    final rawBounds = json['bounds'];
    PlanRect? bounds;
    if (rawBounds != null) {
      final boundsJson =
          _object(rawBounds, 'bounds for "$id" must be an object.');
      final left = _number(boundsJson['left'], 'bounds.left for "$id"');
      final top = _number(boundsJson['top'], 'bounds.top for "$id"');
      final width = _number(boundsJson['width'], 'bounds.width for "$id"');
      final height = _number(boundsJson['height'], 'bounds.height for "$id"');
      if (width <= 0 ||
          height <= 0 ||
          left < 0 ||
          top < 0 ||
          left + width > 1 ||
          top + height > 1) {
        throw FormatException(
            'bounds for "$id" must fit inside 0–1 map space.');
      }
      bounds = PlanRect(left, top, width, height);
    }
    return FloorPlanPlace(
      id: id,
      floorId: floorId,
      nameAr: _requiredString(json, 'nameAr'),
      category: category,
      descriptionAr: _requiredString(json, 'descriptionAr'),
      x: x,
      y: y,
      mapLocationId: _optionalString(json, 'mapLocationId'),
      connections: [
        for (final item in rawPathLinks)
          _stringItem(item, 'pathLinks for "$id"'),
      ],
      bounds: bounds,
      zone: zone,
      verticalConnectionId: _optionalString(json, 'verticalConnectionId'),
      keywords: [
        for (final item in rawKeywords) _stringItem(item, 'keywords for "$id"'),
      ],
    );
  }

  static FloorPlanConnection _parseEdge(Object? raw) {
    final json = _object(raw, 'Each edge must be an object.');
    return FloorPlanConnection(
      fromId: _requiredString(json, 'fromId'),
      toId: _requiredString(json, 'toId'),
      type:
          _enumValue(FloorPlanConnectionType.values, json['type'], 'edge type'),
    );
  }

  static void _validateRegistry(List<HospitalFloorPlan> floors) {
    final floorById = {for (final floor in floors) floor.id: floor};
    final places = <String, FloorPlanPlace>{};
    final mapLocationIds = <String>{};
    for (final floor in floors) {
      for (final place in floor.places) {
        if (place.id.trim().isEmpty) {
          throw const FormatException('Every place needs a non-empty node ID.');
        }
        if (places.containsKey(place.id)) {
          throw FormatException('Duplicate node ID "${place.id}".');
        }
        places[place.id] = place;
        final mapId = place.mapLocationId;
        if (mapId != null && !mapLocationIds.add(mapId)) {
          throw FormatException('Duplicate mapLocationId "$mapId".');
        }
      }
    }

    for (final floor in floors) {
      for (final place in floor.places) {
        for (final targetId in place.connections) {
          final target = places[targetId];
          if (target == null) {
            throw FormatException(
                'Path link from "${place.id}" references missing node "$targetId".');
          }
          if (target.floorId != place.floorId) {
            throw FormatException(
                'Path link from "${place.id}" to "$targetId" crosses floors.');
          }
        }
      }
      final seenEdges = <String>{};
      for (final edge in floor.connections) {
        final from = places[edge.fromId];
        final to = places[edge.toId];
        if (from == null || to == null) {
          throw FormatException(
              'Edge "${edge.fromId}" → "${edge.toId}" references a missing node ID.');
        }
        if (from.floorId != floor.id) {
          throw FormatException(
              'Edge "${edge.fromId}" → "${edge.toId}" must be listed on its starting floor "${from.floorId}".');
        }
        if (edge.fromId == edge.toId) {
          throw const FormatException('An edge cannot link a node to itself.');
        }
        final orderedIds = [edge.fromId, edge.toId]..sort();
        if (!seenEdges.add(orderedIds.join('|'))) {
          throw FormatException(
              'Duplicate edge "${edge.fromId}" → "${edge.toId}".');
        }
        final crossesFloor = from.floorId != to.floorId;
        if (edge.type == FloorPlanConnectionType.vertical) {
          final fromLevel = floorById[from.floorId]?.level;
          final toLevel = floorById[to.floorId]?.level;
          final matchingVerticalNodes =
              (from.category == FloorPlaceCategory.elevator &&
                      to.category == FloorPlaceCategory.elevator) ||
                  (from.category == FloorPlaceCategory.stairs &&
                      to.category == FloorPlaceCategory.stairs);
          if (!crossesFloor ||
              fromLevel == null ||
              toLevel == null ||
              (fromLevel - toLevel).abs() != 1 ||
              !matchingVerticalNodes) {
            throw FormatException(
                'Vertical edge "${edge.fromId}" → "${edge.toId}" must join matching stairs or elevators on adjacent floors.');
          }
        } else if (crossesFloor) {
          throw FormatException(
              'Non-vertical edge "${edge.fromId}" → "${edge.toId}" cannot cross floors.');
        } else if (edge.type == FloorPlanConnectionType.corridor &&
            (from.category != FloorPlaceCategory.corridor ||
                to.category != FloorPlaceCategory.corridor)) {
          throw const FormatException(
              'Corridor edges must join two corridor nodes.');
        }
      }
    }
  }

  static Map<String, dynamic> _object(Object? value, String message) {
    if (value is Map<String, dynamic>) return value;
    throw FormatException(message);
  }

  static String _requiredString(Map<String, dynamic> json, String key) {
    final value = json[key];
    if (value is String && value.trim().isNotEmpty) return value.trim();
    throw FormatException('"$key" is required and must be a non-empty string.');
  }

  static String? _optionalString(Map<String, dynamic> json, String key) {
    final value = json[key];
    if (value == null) return null;
    if (value is String) return value.trim().isEmpty ? null : value.trim();
    throw FormatException('"$key" must be a string or null.');
  }

  static String _stringItem(Object? value, String field) {
    if (value is String && value.trim().isNotEmpty) return value.trim();
    throw FormatException('$field may only contain non-empty strings.');
  }

  static double _number(Object? value, String field) {
    if (value is num && value.isFinite) return value.toDouble();
    throw FormatException('$field must be a finite number.');
  }

  static T _enumValue<T extends Enum>(
      List<T> values, Object? value, String field) {
    for (final option in values) {
      if (option.name == value) return option;
    }
    throw FormatException('Unknown $field "$value".');
  }
}
