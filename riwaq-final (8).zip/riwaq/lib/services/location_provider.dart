import '../data/hospital_floor_plan_data.dart';
import '../data/localization_landmarks.dart';
import '../models/indoor_localization.dart';
import 'location_state.dart';

/// Interface for future indoor-location sources.
abstract interface class LocationProvider {
  String? get currentLocationId;
  bool get isSimulated;

  void setCurrentLocation(String locationId);
}

/// Demo provider that only accepts nodes present in the shared floor data.
class DemoLocationProvider implements LocationProvider {
  DemoLocationProvider({RiwaqLocationState? state})
      : _state = state ?? RiwaqLocationState.instance;

  final RiwaqLocationState _state;

  @override
  String? get currentLocationId => _state.currentLocationId;

  @override
  bool get isSimulated => true;

  @override
  void setCurrentLocation(String locationId) {
    for (final floor in hospitalFloorPlans) {
      // Route-step simulation also needs to place the marker at corridor nodes.
      for (final place in floor.places) {
        if (place.id == locationId || place.mapLocationId == locationId) {
          _state.setCurrent(
            locationId: place.mapLocationId ?? place.id,
            floor: floor.level,
          );
          return;
        }
      }
    }
    throw ArgumentError.value(
      locationId,
      'locationId',
      'Not a navigation point in the floor-plan data.',
    );
  }
}

abstract interface class IndoorLocalizationProvider {
  Future<IndoorLocationPrediction?> requestLocation();
}

/// GPS cannot identify a hospital room. No platform permission is requested
/// while an indoor-positioning source has not been configured and validated.
class UnavailableIndoorLocationProvider implements IndoorLocalizationProvider {
  @override
  Future<IndoorLocationPrediction?> requestLocation() async => null;
}

/// Future recognition adapters submit predictions here; this class neither
/// captures camera frames nor trains/runs a computer-vision model.
class PredictionLocalizationProvider implements IndoorLocalizationProvider {
  IndoorLocationPrediction? _prediction;

  bool receive(IndoorLocationPrediction prediction, {DateTime? now}) {
    final currentTime = now ?? DateTime.now();
    final age = currentTime.difference(prediction.timestamp);
    final place = findHospitalPlace(prediction.locationId);
    if (place == null ||
        place.floorId != prediction.floorId ||
        !prediction.confidence.isFinite ||
        prediction.confidence < .85 ||
        prediction.confidence > 1 ||
        age.isNegative ||
        age > const Duration(seconds: 30)) {
      return false;
    }
    if (prediction.landmarkId != null &&
        !localizationLandmarks.any((l) =>
            l.id == prediction.landmarkId &&
            l.locationId == place.id &&
            l.floorId == place.floorId)) {
      return false;
    }
    _prediction = prediction;
    return true;
  }

  @override
  Future<IndoorLocationPrediction?> requestLocation() async {
    final prediction = _prediction;
    if (prediction == null ||
        DateTime.now().difference(prediction.timestamp) >
            const Duration(seconds: 30)) {
      return null;
    }
    return prediction;
  }
}
