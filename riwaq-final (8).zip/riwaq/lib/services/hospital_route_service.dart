import '../data/hospital_floor_plan_data.dart';
import '../models/hospital_floor_plan.dart';

/// Finds routes through explicitly authored conceptual graph edges.
///
/// The returned path is useful for UI and integration testing only. It is not
/// suitable for real-world wayfinding until surveyed floor plans are supplied.
class HospitalRouteService {
  HospitalRouteService({List<HospitalFloorPlan>? floors})
      : _floors = floors ?? hospitalFloorPlans;

  final List<HospitalFloorPlan> _floors;

  HospitalRoute? findRoute({
    required String startLocationId,
    required String destinationLocationId,
    MobilityRoutePreferences preferences = const MobilityRoutePreferences(),
  }) =>
      findRouteResult(
        startLocationId: startLocationId,
        destinationLocationId: destinationLocationId,
        preferences: preferences,
      ).route;

  HospitalRouteSearchResult findRouteResult({
    required String startLocationId,
    required String destinationLocationId,
    MobilityRoutePreferences preferences = const MobilityRoutePreferences(),
  }) {
    final floorByPlaceId = <String, String>{};
    for (final floor in _floors) {
      for (final place in floor.places) {
        final firstFloorId = floorByPlaceId[place.id];
        if (firstFloorId != null) {
          throw StateError(
            "Duplicate place ID '${place.id}' found on floors "
            "'$firstFloorId' and '${floor.id}'.",
          );
        }
        floorByPlaceId[place.id] = floor.id;
      }
    }

    final places = [
      for (final floor in _floors) ...floor.places,
    ];
    final start = _resolvePlace(places, startLocationId);
    final destination = _resolvePlace(places, destinationLocationId);
    if (start == null || destination == null) {
      return const HospitalRouteSearchResult(
        failureReason: RouteFailureReason.unknownLocation,
      );
    }
    final route = _findPath(
      places: places,
      start: start,
      destination: destination,
      startLocationId: startLocationId,
      destinationLocationId: destinationLocationId,
      preferences: preferences,
    );
    if (route != null) return HospitalRouteSearchResult(route: route);

    final unrestrictedRoute = _findPath(
      places: places,
      start: start,
      destination: destination,
      startLocationId: startLocationId,
      destinationLocationId: destinationLocationId,
      preferences: const MobilityRoutePreferences(),
    );
    return HospitalRouteSearchResult(
      failureReason: unrestrictedRoute == null
          ? RouteFailureReason.noConnectedPath
          : RouteFailureReason.excludedByMobilityPreferences,
    );
  }

  HospitalRoute? _findPath({
    required List<FloorPlanPlace> places,
    required FloorPlanPlace start,
    required FloorPlanPlace destination,
    required String startLocationId,
    required String destinationLocationId,
    required MobilityRoutePreferences preferences,
  }) {
    final placesById = {for (final place in places) place.id: place};
    if (start.id == destination.id) {
      return HospitalRoute(
        startLocationId: startLocationId,
        destinationLocationId: destinationLocationId,
        places: [start],
      );
    }

    final adjacency = <String, Set<String>>{
      for (final place in places) place.id: <String>{},
    };
    final floorsById = {for (final floor in _floors) floor.id: floor};
    for (final floor in _floors) {
      for (final edge in floor.connections) {
        final from = placesById[edge.fromId];
        final to = placesById[edge.toId];
        if (from == null || to == null) {
          throw StateError(
              'Route edge ${edge.fromId} → ${edge.toId} references an unknown place.');
        }
        final crossesFloor = from.floorId != to.floorId;
        if (edge.type == FloorPlanConnectionType.vertical) {
          final fromLevel = floorsById[from.floorId]?.level;
          final toLevel = floorsById[to.floorId]?.level;
          final supportedPair = (from.category == FloorPlaceCategory.elevator &&
                  to.category == FloorPlaceCategory.elevator) ||
              (from.category == FloorPlaceCategory.stairs &&
                  to.category == FloorPlaceCategory.stairs);
          if (!crossesFloor ||
              fromLevel == null ||
              toLevel == null ||
              (fromLevel - toLevel).abs() != 1 ||
              !supportedPair) {
            throw StateError(
                'Invalid vertical route edge ${edge.fromId} → ${edge.toId}.');
          }
        } else if (crossesFloor) {
          throw StateError(
              'Non-vertical route edge ${edge.fromId} → ${edge.toId} crosses floors.');
        } else if (edge.type == FloorPlanConnectionType.corridor &&
            (from.category != FloorPlaceCategory.corridor ||
                to.category != FloorPlaceCategory.corridor)) {
          throw StateError(
              'Corridor edge ${edge.fromId} → ${edge.toId} must join corridor nodes.');
        }
        if (!_allowsPlace(from, preferences) ||
            !_allowsPlace(to, preferences)) {
          continue;
        }
        adjacency[from.id]!.add(to.id);
        adjacency[to.id]!.add(from.id);
      }
    }

    final parents = <String, String?>{start.id: null};
    final costs = <String, double>{start.id: 0};
    final queue = <String>[start.id];
    final visited = <String>{};
    while (queue.isNotEmpty) {
      queue.sort((a, b) => costs[a]!.compareTo(costs[b]!));
      final currentId = queue.removeAt(0);
      if (!visited.add(currentId)) continue;
      if (currentId == destination.id) break;
      for (final neighborId in adjacency[currentId]!) {
        final from = placesById[currentId]!;
        final to = placesById[neighborId]!;
        // Relative design cost, never presented as metres or travel time.
        final edgeCost = from.floorId == to.floorId
            ? (from.x - to.x).abs() + (from.y - to.y).abs()
            : (to.category == FloorPlaceCategory.elevator ? .2 : .9);
        final cost = costs[currentId]! + edgeCost;
        if (cost >= (costs[neighborId] ?? double.infinity)) continue;
        costs[neighborId] = cost;
        parents[neighborId] = currentId;
        queue.add(neighborId);
      }
    }
    if (!parents.containsKey(destination.id)) return null;

    final routePlaces = <FloorPlanPlace>[];
    String? cursor = destination.id;
    while (cursor != null) {
      routePlaces.add(placesById[cursor]!);
      cursor = parents[cursor];
    }
    return HospitalRoute(
      startLocationId: startLocationId,
      destinationLocationId: destinationLocationId,
      places: routePlaces.reversed.toList(growable: false),
      isSimulated: true,
    );
  }

  bool _allowsPlace(
    FloorPlanPlace place,
    MobilityRoutePreferences preferences,
  ) {
    if (place.category == FloorPlaceCategory.stairs &&
        !preferences.allowStairs) {
      return false;
    }
    if (place.category == FloorPlaceCategory.elevator &&
        !preferences.allowElevators) {
      return false;
    }
    return true;
  }

  FloorPlanPlace? _resolvePlace(List<FloorPlanPlace> places, String id) {
    for (final place in places) {
      if (place.id == id || place.mapLocationId == id) return place;
    }
    return null;
  }
}
