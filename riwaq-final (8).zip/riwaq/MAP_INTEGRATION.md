# Virtual map and visual landmark integration

The assistant, map, and visual recognition flow use `RiwaqLocationState.instance` from `lib/services/location_state.dart` and registered records from `lib/data/location_data.dart`.

## Map contract

- `currentLocationId`: the selected demo point, or a future trusted location estimate.
- `destinationLocationId`: selected by assistant or appointment navigation.
- `buildingId`: `VIRTUAL_BUILDING` for this prototype.
- `currentFloor` and `destinationFloor`: values from the registered location record.
- `currentPrediction`: optional provider, score and timestamp metadata for a
  future validated estimate; null for the entrance and movable demo starts.

The architectural source is `hospital_floor_plan_data.dart`; `location_data.dart`
derives the legacy destination registry from it. 2D rendering, corridor routing,
and procedural GLB generation share these identities and positions. See
`PHASE_2_REPORT.md` for regeneration instructions and the complete Phase 2 scope.

On first opening the unified map, the demo location starts at `MAIN_ENTRANCE`. The demo selector accepts stable place IDs from the floor-plan graph and updates the shared current location. Destinations from the assistant, doctors, and saved-location flows continue to use the registered location IDs.

The map displays the three floor images from `assets/floor_plans/riwaq_conceptual_floor_plans.pdf`. The PDF is explicitly stamped **CONCEPTUAL — NOT VERIFIED**; its dimensions are approximate and it is not an approved or surveyed architectural drawing. The accompanying normalized coordinates and hand-entered graph edges are likewise illustrative test data.

`HospitalRouteService` searches only the explicit graph edges in the floor data. Corridor segments, room-door links, and each matching elevator/stair connection between adjacent floors are represented as separate edges; vertical links are not inferred from facility categories. The app draws simulated routes over the plan image and labels them as such. This feature is for local testing and hackathon prototyping only—not real hospital visitor guidance.

Do not remove the in-app simulated/unverified warning or describe these coordinates, facilities, routes, entrances, exits, elevators, or stairs as verified. A future verified-navigation project must replace this conceptual source with an approved or surveyed plan and validate every location and traversable connection.

## Visual reference data needed

There are currently no approved hospital reference photos or trained model in
the project. `assets/images/` contains brand artwork, not a localization dataset,
and `visualLandmarkReferences` is intentionally empty. The experimental camera
flow captures and processes an image, but it refuses to set the current location
until registered references exist.

Reserved landmark IDs and floor mappings are in `localization_landmarks.dart`.
They are capture targets, not proof that a landmark has been surveyed.
`IndoorLocalizationProvider` separates recognition from map state;
`PredictionLocalizationProvider` accepts a location/floor, confidence, timestamp,
provider ID and optional landmark ID and rejects invalid/stale estimates.
The default provider performs no localization and requests no GPS permission.

The current experimental matcher creates a small normalized luminance pattern and RGB histogram from each captured image and compares them with registered images. The reported similarity is heuristic, not a calibrated probability and not validated for reliable indoor localization.

To enable a location match, the virtual-map team must provide, for each registered `location_id`:

1. At least 10–20 labeled photos of the exact virtual scene landmark, from varied viewpoints, distances, and lighting.
2. Confirmation that each photo belongs to the same approved virtual location and floor in `location_data.dart`.
3. A holdout set of separate camera captures for evaluating false matches and confidence thresholds.

Add approved assets beneath `assets/landmarks/<LOCATION_ID>/`, register each path in `lib/data/landmark_reference_data.dart`, then test threshold and ambiguity behavior against held-out images. Do not treat matching as production-ready until that evaluation succeeds. The implementation rejects invalid images, missing reference data, low similarity, and ambiguous results without changing the shared current location.
